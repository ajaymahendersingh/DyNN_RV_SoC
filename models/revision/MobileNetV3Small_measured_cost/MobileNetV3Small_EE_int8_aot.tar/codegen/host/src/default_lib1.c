// tvm target: c -keys=cpu 
#define TVM_EXPORTS
#include "tvm/runtime/c_runtime_api.h"
#include "tvm/runtime/c_backend_api.h"
#include <math.h>
#include <stdbool.h>
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_cast_fixed_point_multiply_add_nn_conv2d_subtract_add_fixed_point_multiply__ad3cbdcd07b87e28_(int8_t* p0, int8_t* p1, int8_t* T_cast, uint8_t* global_const_workspace_126_var, uint8_t* global_workspace_127_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_cast_subtract_fixed_point_multiply_add_cast_subtract_fixed_point_multiply__ed64f25d07613c12_(int8_t* p0, int8_t* p1, int8_t* T_cast, uint8_t* global_const_workspace_54_var, uint8_t* global_workspace_55_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_cast_subtract_fixed_point_multiply_add_nn_conv2d_subtract_add_fixed_point__7462b0c1d1f4a4f5_(int8_t* p0, int8_t* p1, int8_t* T_cast, uint8_t* global_const_workspace_162_var, uint8_t* global_workspace_163_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_cast_subtract_fixed_point_multiply_add_nn_conv2d_subtract_add_fixed_point__7462b0c1d1f4a4f5__1(int8_t* p0, int8_t* p1, int8_t* T_cast, uint8_t* global_const_workspace_198_var, uint8_t* global_workspace_199_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_cast_subtract_fixed_point_multiply_add_nn_conv2d_subtract_add_fixed_point__7462b0c1d1f4a4f5__2(int8_t* p0, int8_t* p1, int8_t* T_cast, uint8_t* global_const_workspace_214_var, uint8_t* global_workspace_215_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_cast_subtract_fixed_point_multiply_nn_conv2d_subtract_add_fixed_point_mult_6a0898f32fb5072b_(int8_t* p0, int8_t* p1, int8_t* T_cast, uint8_t* global_const_workspace_110_var, uint8_t* global_workspace_111_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_divide_round_add_clip_cast_nn_pad(float* p0, int8_t* T_pad, uint8_t* global_const_workspace_2_var, uint8_t* global_workspace_3_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_mean(int32_t* p0, int32_t* T_divide, uint8_t* global_const_workspace_10_var, uint8_t* global_workspace_11_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_mean_1(int32_t* p0, int32_t* T_divide, uint8_t* global_const_workspace_42_var, uint8_t* global_workspace_43_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_mean_10(int32_t* p0, int32_t* T_divide, uint8_t* global_const_workspace_234_var, uint8_t* global_workspace_235_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_mean_2(int32_t* p0, int32_t* T_divide, uint8_t* global_const_workspace_62_var, uint8_t* global_workspace_63_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_mean_3(int32_t* p0, int32_t* T_divide, uint8_t* global_const_workspace_82_var, uint8_t* global_workspace_83_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_mean_4(int32_t* p0, int32_t* T_divide, uint8_t* global_const_workspace_100_var, uint8_t* global_workspace_101_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_mean_5(int32_t* p0, int32_t* T_divide, uint8_t* global_const_workspace_134_var, uint8_t* global_workspace_135_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_mean_6(int32_t* p0, int32_t* T_divide, uint8_t* global_const_workspace_152_var, uint8_t* global_workspace_153_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_mean_7(int32_t* p0, int32_t* T_divide, uint8_t* global_const_workspace_170_var, uint8_t* global_workspace_171_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_mean_8(int32_t* p0, int32_t* T_divide, uint8_t* global_const_workspace_188_var, uint8_t* global_workspace_189_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_mean_9(int32_t* p0, int32_t* T_divide, uint8_t* global_const_workspace_218_var, uint8_t* global_workspace_219_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_contrib_dense_pack_subtract_add_fixed_point_multiply_add_clip_cast(int8_t* p0, int8_t* T_cast, uint8_t* global_const_workspace_46_var, uint8_t* global_workspace_47_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_contrib_dense_pack_subtract_add_fixed_point_multiply_add_clip_cast_1(int8_t* p0, int8_t* T_cast, uint8_t* global_const_workspace_48_var, uint8_t* global_workspace_49_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_contrib_dense_pack_subtract_add_fixed_point_multiply_add_clip_cast_2(int8_t* p0, int8_t* T_cast, uint8_t* global_const_workspace_86_var, uint8_t* global_workspace_87_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_contrib_dense_pack_subtract_add_fixed_point_multiply_add_clip_cast_3(int8_t* p0, int8_t* T_cast, uint8_t* global_const_workspace_88_var, uint8_t* global_workspace_89_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_contrib_dense_pack_subtract_add_fixed_point_multiply_add_clip_cast_4(int8_t* p0, int8_t* T_cast, uint8_t* global_const_workspace_238_var, uint8_t* global_workspace_239_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_contrib_dense_pack_subtract_add_fixed_point_multiply_add_clip_cast_5(int8_t* p0, int8_t* T_cast, uint8_t* global_const_workspace_240_var, uint8_t* global_workspace_241_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_contrib_dense_pack_subtract_add_fixed_point_multiply_add_clip_subtract__fa059688879ad8de_(int8_t* p0, float* T_multiply, uint8_t* global_const_workspace_50_var, uint8_t* global_workspace_51_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_contrib_dense_pack_subtract_add_fixed_point_multiply_add_clip_subtract__fa059688879ad8de__1(int8_t* p0, float* T_multiply, uint8_t* global_const_workspace_90_var, uint8_t* global_workspace_91_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_contrib_dense_pack_subtract_add_fixed_point_multiply_add_clip_subtract__fa059688879ad8de__2(int8_t* p0, float* T_multiply, uint8_t* global_const_workspace_222_var, uint8_t* global_workspace_223_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_contrib_dense_pack_subtract_add_fixed_point_multiply_add_clip_subtract__fa059688879ad8de__3(int8_t* p0, float* T_multiply, uint8_t* global_const_workspace_242_var, uint8_t* global_workspace_243_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_add_fixed_point_multiply_per_axis_add_clip_cast(int8_t* p0, int8_t* T_cast, uint8_t* global_const_workspace_228_var, uint8_t* global_workspace_229_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_add_fixed_point_multiply_per_axis_add_clip_subtract_cast_multipl_a0b6f984222e477_(int8_t* p0, int8_t* T_cast, uint8_t* global_const_workspace_112_var, uint8_t* global_workspace_113_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_add_fixed_point_multiply_per_axis_add_clip_subtract_multiply_fix_52d6a4719dd81c1d_(int8_t* p0, int32_t* T_subtract, uint8_t* global_const_workspace_140_var, uint8_t* global_workspace_141_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip(int8_t* p0, int32_t* compute, uint8_t* global_const_workspace_8_var, uint8_t* global_workspace_9_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_1(int8_t* p0, int32_t* compute, uint8_t* global_const_workspace_40_var, uint8_t* global_workspace_41_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_2(int8_t* p0, int32_t* compute, uint8_t* global_const_workspace_80_var, uint8_t* global_workspace_81_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_3(int8_t* p0, int32_t* compute, uint8_t* global_const_workspace_232_var, uint8_t* global_workspace_233_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_cast(int8_t* p0, int8_t* T_cast, uint8_t* global_const_workspace_14_var, uint8_t* global_workspace_15_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_cast_1(int8_t* p0, int8_t* T_cast, uint8_t* global_const_workspace_20_var, uint8_t* global_workspace_21_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_cast_10(int8_t* p0, int8_t* T_cast, uint8_t* global_const_workspace_76_var, uint8_t* global_workspace_77_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_cast_11(int8_t* p0, int8_t* T_cast, uint8_t* global_const_workspace_104_var, uint8_t* global_workspace_105_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_cast_12(int8_t* p0, int8_t* T_cast, uint8_t* global_const_workspace_120_var, uint8_t* global_workspace_121_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_cast_13(int8_t* p0, int8_t* T_cast, uint8_t* global_const_workspace_144_var, uint8_t* global_workspace_145_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_cast_14(int8_t* p0, int8_t* T_cast, uint8_t* global_const_workspace_156_var, uint8_t* global_workspace_157_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_cast_15(int8_t* p0, int8_t* T_cast, uint8_t* global_const_workspace_174_var, uint8_t* global_workspace_175_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_cast_16(int8_t* p0, int8_t* T_cast, uint8_t* global_const_workspace_180_var, uint8_t* global_workspace_181_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_cast_17(int8_t* p0, int8_t* T_cast, uint8_t* global_const_workspace_192_var, uint8_t* global_workspace_193_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_cast_18(int8_t* p0, int8_t* T_cast, uint8_t* global_const_workspace_208_var, uint8_t* global_workspace_209_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_cast_2(int8_t* p0, int8_t* T_cast, uint8_t* global_const_workspace_22_var, uint8_t* global_workspace_23_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_cast_3(int8_t* p0, int8_t* T_cast, uint8_t* global_const_workspace_26_var, uint8_t* global_workspace_27_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_cast_4(int8_t* p0, int8_t* T_cast, uint8_t* global_const_workspace_28_var, uint8_t* global_workspace_29_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_cast_5(int8_t* p0, int8_t* T_cast, uint8_t* global_const_workspace_30_var, uint8_t* global_workspace_31_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_cast_6(int8_t* p0, int8_t* T_cast, uint8_t* global_const_workspace_34_var, uint8_t* global_workspace_35_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_cast_7(int8_t* p0, int8_t* T_cast, uint8_t* global_const_workspace_36_var, uint8_t* global_workspace_37_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_cast_8(int8_t* p0, int8_t* T_cast, uint8_t* global_const_workspace_66_var, uint8_t* global_workspace_67_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_cast_9(int8_t* p0, int8_t* T_cast, uint8_t* global_const_workspace_72_var, uint8_t* global_workspace_73_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_subtract_cas_c93f40e30d1c190e_(int8_t* p0, int8_t* T_cast, uint8_t* global_const_workspace_4_var, uint8_t* global_workspace_5_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_subtract_cas_c93f40e30d1c190e__1(int8_t* p0, int8_t* T_cast, uint8_t* global_const_workspace_56_var, uint8_t* global_workspace_57_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_subtract_cas_c93f40e30d1c190e__10(int8_t* p0, int32_t* T_cast, uint8_t* global_const_workspace_168_var, uint8_t* global_workspace_169_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_subtract_cas_c93f40e30d1c190e__11(int8_t* p0, int8_t* T_cast, uint8_t* global_const_workspace_182_var, uint8_t* global_workspace_183_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_subtract_cas_c93f40e30d1c190e__12(int8_t* p0, int32_t* T_cast, uint8_t* global_const_workspace_186_var, uint8_t* global_workspace_187_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_subtract_cas_c93f40e30d1c190e__13(int8_t* p0, int8_t* T_cast, uint8_t* global_const_workspace_200_var, uint8_t* global_workspace_201_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_subtract_cas_c93f40e30d1c190e__14(int8_t* p0, int32_t* T_cast, uint8_t* global_const_workspace_204_var, uint8_t* global_workspace_205_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_subtract_cas_c93f40e30d1c190e__15(int8_t* p0, int32_t* T_cast, uint8_t* global_const_workspace_216_var, uint8_t* global_workspace_217_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_subtract_cas_c93f40e30d1c190e__2(int8_t* p0, int32_t* T_cast, uint8_t* global_const_workspace_60_var, uint8_t* global_workspace_61_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_subtract_cas_c93f40e30d1c190e__3(int8_t* p0, int8_t* T_cast, uint8_t* global_const_workspace_94_var, uint8_t* global_workspace_95_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_subtract_cas_c93f40e30d1c190e__4(int8_t* p0, int32_t* T_cast, uint8_t* global_const_workspace_98_var, uint8_t* global_workspace_99_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_subtract_cas_c93f40e30d1c190e__5(int8_t* p0, int8_t* T_cast, uint8_t* global_const_workspace_128_var, uint8_t* global_workspace_129_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_subtract_cas_c93f40e30d1c190e__6(int8_t* p0, int32_t* T_cast, uint8_t* global_const_workspace_132_var, uint8_t* global_workspace_133_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_subtract_cas_c93f40e30d1c190e__7(int8_t* p0, int8_t* T_cast, uint8_t* global_const_workspace_146_var, uint8_t* global_workspace_147_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_subtract_cas_c93f40e30d1c190e__8(int8_t* p0, int32_t* T_cast, uint8_t* global_const_workspace_150_var, uint8_t* global_workspace_151_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_subtract_cas_c93f40e30d1c190e__9(int8_t* p0, int8_t* T_cast, uint8_t* global_const_workspace_164_var, uint8_t* global_workspace_165_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_subtract_mul_add8c47b972ae6c2_(int8_t* p0, int32_t* T_subtract, uint8_t* global_const_workspace_16_var, uint8_t* global_workspace_17_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_subtract_mul_add8c47b972ae6c2__1(int8_t* p0, int32_t* T_subtract, uint8_t* global_const_workspace_68_var, uint8_t* global_workspace_69_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_subtract_mul_add8c47b972ae6c2__2(int8_t* p0, int32_t* T_subtract, uint8_t* global_const_workspace_106_var, uint8_t* global_workspace_107_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_subtract_mul_add8c47b972ae6c2__3(int8_t* p0, int32_t* T_subtract, uint8_t* global_const_workspace_122_var, uint8_t* global_workspace_123_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_subtract_mul_add8c47b972ae6c2__4(int8_t* p0, int32_t* T_subtract, uint8_t* global_const_workspace_158_var, uint8_t* global_workspace_159_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_subtract_mul_add8c47b972ae6c2__5(int8_t* p0, int32_t* T_subtract, uint8_t* global_const_workspace_176_var, uint8_t* global_workspace_177_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_subtract_mul_add8c47b972ae6c2__6(int8_t* p0, int32_t* T_subtract, uint8_t* global_const_workspace_194_var, uint8_t* global_workspace_195_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_subtract_mul_add8c47b972ae6c2__7(int8_t* p0, int32_t* T_subtract, uint8_t* global_const_workspace_210_var, uint8_t* global_workspace_211_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_clip_cast_clip(int8_t* p0, int8_t* compute, uint8_t* global_const_workspace_138_var, uint8_t* global_workspace_139_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_clip_cast_multiply_ad_b57e37aeb09540e8_(int8_t* p0, int32_t* T_cast, uint8_t* global_const_workspace_116_var, uint8_t* global_workspace_117_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_pad(int8_t* p0, int8_t* T_pad, uint8_t* global_const_workspace_6_var, uint8_t* global_workspace_7_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_pad_1(int8_t* p0, int8_t* T_pad, uint8_t* global_const_workspace_24_var, uint8_t* global_workspace_25_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_pad_10(int8_t* p0, int8_t* T_pad, uint8_t* global_const_workspace_148_var, uint8_t* global_workspace_149_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_pad_11(int8_t* p0, int8_t* T_pad, uint8_t* global_const_workspace_166_var, uint8_t* global_workspace_167_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_pad_12(int8_t* p0, int8_t* T_pad, uint8_t* global_const_workspace_184_var, uint8_t* global_workspace_185_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_pad_13(int8_t* p0, int8_t* T_pad, uint8_t* global_const_workspace_202_var, uint8_t* global_workspace_203_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_pad_14(int8_t* p0, int8_t* T_pad, uint8_t* global_const_workspace_226_var, uint8_t* global_workspace_227_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_pad_15(int8_t* p0, int8_t* T_pad, uint8_t* global_const_workspace_230_var, uint8_t* global_workspace_231_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_pad_2(int8_t* p0, int8_t* T_pad, uint8_t* global_const_workspace_32_var, uint8_t* global_workspace_33_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_pad_3(int8_t* p0, int8_t* T_pad, uint8_t* global_const_workspace_38_var, uint8_t* global_workspace_39_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_pad_4(int8_t* p0, int8_t* T_pad, uint8_t* global_const_workspace_58_var, uint8_t* global_workspace_59_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_pad_5(int8_t* p0, int8_t* T_pad, uint8_t* global_const_workspace_74_var, uint8_t* global_workspace_75_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_pad_6(int8_t* p0, int8_t* T_pad, uint8_t* global_const_workspace_78_var, uint8_t* global_workspace_79_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_pad_7(int8_t* p0, int8_t* T_pad, uint8_t* global_const_workspace_96_var, uint8_t* global_workspace_97_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_pad_8(int8_t* p0, int8_t* T_pad, uint8_t* global_const_workspace_114_var, uint8_t* global_workspace_115_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_pad_9(int8_t* p0, int8_t* T_pad, uint8_t* global_const_workspace_130_var, uint8_t* global_workspace_131_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_softmax_divide_round_add_clip_cast_subtract_cast_multiply(float* p0, float* T_multiply, uint8_t* global_const_workspace_52_var, uint8_t* global_workspace_53_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_softmax_divide_round_add_clip_cast_subtract_cast_multiply_1(float* p0, float* T_multiply, uint8_t* global_const_workspace_92_var, uint8_t* global_workspace_93_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_softmax_divide_round_add_clip_cast_subtract_cast_multiply_2(float* p0, float* T_multiply, uint8_t* global_const_workspace_224_var, uint8_t* global_workspace_225_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_softmax_divide_round_add_clip_cast_subtract_cast_multiply_3(float* p0, float* T_multiply, uint8_t* global_const_workspace_244_var, uint8_t* global_workspace_245_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_subtract_fixed_point_multiply_add_clip_cast(int32_t* p0, int8_t* T_cast, uint8_t* global_const_workspace_12_var, uint8_t* global_workspace_13_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_subtract_fixed_point_multiply_add_clip_cast_1(int32_t* p0, int8_t* T_cast, uint8_t* global_const_workspace_64_var, uint8_t* global_workspace_65_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_subtract_fixed_point_multiply_add_clip_cast_2(int32_t* p0, int8_t* T_cast, uint8_t* global_const_workspace_102_var, uint8_t* global_workspace_103_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_subtract_fixed_point_multiply_add_clip_cast_3(int32_t* p0, int8_t* T_cast, uint8_t* global_const_workspace_118_var, uint8_t* global_workspace_119_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_subtract_fixed_point_multiply_add_clip_cast_4(int32_t* p0, int8_t* T_cast, uint8_t* global_const_workspace_136_var, uint8_t* global_workspace_137_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_subtract_fixed_point_multiply_add_clip_cast_5(int32_t* p0, int8_t* T_cast, uint8_t* global_const_workspace_154_var, uint8_t* global_workspace_155_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_subtract_fixed_point_multiply_add_clip_cast_6(int32_t* p0, int8_t* T_cast, uint8_t* global_const_workspace_172_var, uint8_t* global_workspace_173_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_subtract_fixed_point_multiply_add_clip_cast_7(int32_t* p0, int8_t* T_cast, uint8_t* global_const_workspace_190_var, uint8_t* global_workspace_191_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_subtract_fixed_point_multiply_add_clip_cast_8(int32_t* p0, int8_t* T_cast, uint8_t* global_const_workspace_206_var, uint8_t* global_workspace_207_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_subtract_fixed_point_multiply_add_clip_cast_reshape(int32_t* p0, int8_t* T_reshape, uint8_t* global_const_workspace_44_var, uint8_t* global_workspace_45_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_subtract_fixed_point_multiply_add_clip_cast_reshape_1(int32_t* p0, int8_t* T_reshape, uint8_t* global_const_workspace_84_var, uint8_t* global_workspace_85_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_subtract_fixed_point_multiply_add_clip_cast_reshape_2(int32_t* p0, int8_t* T_reshape, uint8_t* global_const_workspace_220_var, uint8_t* global_workspace_221_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_subtract_fixed_point_multiply_add_clip_cast_reshape_3(int32_t* p0, int8_t* T_reshape, uint8_t* global_const_workspace_236_var, uint8_t* global_workspace_237_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_subtract_multiply_fixed_point_multiply_add_clip_cast(int32_t* p0, int32_t* p1, int8_t* T_cast, uint8_t* global_const_workspace_18_var, uint8_t* global_workspace_19_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_subtract_multiply_fixed_point_multiply_add_clip_cast_1(int32_t* p0, int32_t* p1, int8_t* T_cast, uint8_t* global_const_workspace_70_var, uint8_t* global_workspace_71_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_subtract_multiply_fixed_point_multiply_add_clip_cast_2(int32_t* p0, int32_t* p1, int8_t* T_cast, uint8_t* global_const_workspace_108_var, uint8_t* global_workspace_109_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_subtract_multiply_fixed_point_multiply_add_clip_cast_3(int32_t* p0, int32_t* p1, int8_t* T_cast, uint8_t* global_const_workspace_124_var, uint8_t* global_workspace_125_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_subtract_multiply_fixed_point_multiply_add_clip_cast_4(int32_t* p0, int32_t* p1, int8_t* T_cast, uint8_t* global_const_workspace_142_var, uint8_t* global_workspace_143_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_subtract_multiply_fixed_point_multiply_add_clip_cast_5(int32_t* p0, int32_t* p1, int8_t* T_cast, uint8_t* global_const_workspace_160_var, uint8_t* global_workspace_161_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_subtract_multiply_fixed_point_multiply_add_clip_cast_6(int32_t* p0, int32_t* p1, int8_t* T_cast, uint8_t* global_const_workspace_178_var, uint8_t* global_workspace_179_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_subtract_multiply_fixed_point_multiply_add_clip_cast_7(int32_t* p0, int32_t* p1, int8_t* T_cast, uint8_t* global_const_workspace_196_var, uint8_t* global_workspace_197_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_subtract_multiply_fixed_point_multiply_add_clip_cast_8(int32_t* p0, int32_t* p1, int8_t* T_cast, uint8_t* global_const_workspace_212_var, uint8_t* global_workspace_213_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default___tvm_main__(float* serving_default_input_0_buffer_var, float* StatefulPartitionedCall_1_buffer_var, float* StatefulPartitionedCall_2_buffer_var, float* StatefulPartitionedCall_0_buffer_var, float* StatefulPartitionedCall_3_buffer_var, uint8_t* global_const_workspace_0_var, uint8_t* global_workspace_1_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL float roundf(float);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL float roundf(float);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL float roundf(float);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL float roundf(float);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL float roundf(float);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL float roundf(float);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL float roundf(float);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL float roundf(float);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL float roundf(float);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL float roundf(float);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL float roundf(float);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL float roundf(float);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL float roundf(float);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL float roundf(float);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL float roundf(float);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL float roundf(float);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL float roundf(float);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL float roundf(float);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL float roundf(float);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL float expf(float);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL float roundf(float);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL float expf(float);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL float roundf(float);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL float expf(float);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL float roundf(float);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL float expf(float);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL float roundf(float);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_cast_fixed_point_multiply_add_nn_conv2d_subtract_add_fixed_point_multiply__ad3cbdcd07b87e28_(int8_t* p0, int8_t* p1, int8_t* T_cast, uint8_t* global_const_workspace_126_var, uint8_t* global_workspace_127_var) {
  void* fused_cast_fixed_point_multiply_add_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_constant_let = (&(global_const_workspace_126_var[784224]));
  void* fused_cast_fixed_point_multiply_add_nn_conv2d_subtract_add_constant_2_let = (&(global_const_workspace_126_var[779040]));
  void* fused_cast_fixed_point_multiply_add_nn_conv2d_subtract_add_constant_1_let = (&(global_const_workspace_126_var[779168]));
  void* fused_cast_fixed_point_multiply_add_nn_conv2d_subtract_add_constant_let = (&(global_const_workspace_126_var[779296]));
  void* fused_cast_fixed_point_multiply_add_nn_conv2d_constant_let = (&(global_const_workspace_126_var[779424]));
  void* fused_cast_fixed_point_multiply_add_nn_conv2d_subtract_constant_let = (&(global_const_workspace_126_var[778912]));
  void* fused_cast_fixed_point_multiply_add_constant_let = (&(global_const_workspace_126_var[533472]));
  void* pad_temp_let = (&(global_workspace_127_var[15360]));
  for (int32_t i0_i1_fused = 0; i0_i1_fused < 4; ++i0_i1_fused) {
    for (int32_t i2 = 0; i2 < 4; ++i2) {
      for (int32_t i3 = 0; i3 < 192; ++i3) {
        int32_t cse_var_1 = (((i0_i1_fused * 768) + (i2 * 192)) + i3);
        ((int8_t*)pad_temp_let)[cse_var_1] = p1[cse_var_1];
      }
    }
  }
  for (int32_t ax0_ax1_fused_ax2_fused = 0; ax0_ax1_fused_ax2_fused < 16; ++ax0_ax1_fused_ax2_fused) {
    void* conv2d_nhwc_let = (&(global_workspace_127_var[53248]));
    for (int32_t ax3 = 0; ax3 < 32; ++ax3) {
      int32_t cse_var_2 = ((ax0_ax1_fused_ax2_fused * 32) + ax3);
      ((int32_t*)conv2d_nhwc_let)[0] = 0;
      for (int32_t rc = 0; rc < 192; ++rc) {
        ((int32_t*)conv2d_nhwc_let)[0] = (((int32_t*)conv2d_nhwc_let)[0] + (((int32_t)((int8_t*)pad_temp_let)[((ax0_ax1_fused_ax2_fused * 192) + rc)]) * ((int32_t)((int8_t*)fused_cast_fixed_point_multiply_add_constant_let)[((rc * 32) + ax3)])));
      }
      int32_t v_ = ((int32_t)(((((int64_t)((((int32_t*)conv2d_nhwc_let)[0] + ((int32_t*)fused_cast_fixed_point_multiply_add_nn_conv2d_subtract_constant_let)[ax3]) - ((int32_t*)fused_cast_fixed_point_multiply_add_nn_conv2d_constant_let)[ax3])) * ((int64_t)((int32_t*)fused_cast_fixed_point_multiply_add_nn_conv2d_subtract_add_constant_let)[ax3])) + ((int64_t)1 << ((int64_t)((((int32_t*)fused_cast_fixed_point_multiply_add_nn_conv2d_subtract_add_constant_2_let)[ax3] + 31) - 1)))) >> ((int64_t)(((int32_t*)fused_cast_fixed_point_multiply_add_nn_conv2d_subtract_add_constant_2_let)[ax3] + 31)))) + 37;
      int32_t v__1 = (v_) < (127) ? (v_) : (127);
      int32_t v__2 = ((int32_t)(((((int64_t)((((int32_t*)conv2d_nhwc_let)[0] + ((int32_t*)fused_cast_fixed_point_multiply_add_nn_conv2d_subtract_constant_let)[ax3]) - ((int32_t*)fused_cast_fixed_point_multiply_add_nn_conv2d_constant_let)[ax3])) * ((int64_t)((int32_t*)fused_cast_fixed_point_multiply_add_nn_conv2d_subtract_add_constant_let)[ax3])) + ((int64_t)1 << ((int64_t)((((int32_t*)fused_cast_fixed_point_multiply_add_nn_conv2d_subtract_add_constant_2_let)[ax3] + 31) - 1)))) >> ((int64_t)(((int32_t*)fused_cast_fixed_point_multiply_add_nn_conv2d_subtract_add_constant_2_let)[ax3] + 31)))) + 37;
      int32_t v__3 = (v__2) < (127) ? (v__2) : (127);
      int32_t v__4 = (((int32_t)(((((0 != 0) ? (((int64_t)((int32_t)p0[cse_var_2])) << ((int64_t)0)) : ((int64_t)((int32_t)p0[cse_var_2]))) * (int64_t)1531116282) + ((int64_t)1 << ((int64_t)((0 + 31) - 1)))) >> ((int64_t)(0 + 31)))) + ((int32_t)(((((0 != 0) ? (((int64_t)(((v__1) > (-128) ? (v__1) : (-128)) - ((int32_t*)fused_cast_fixed_point_multiply_add_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_constant_let)[0])) << ((int64_t)0)) : ((int64_t)(((v__3) > (-128) ? (v__3) : (-128)) - ((int32_t*)fused_cast_fixed_point_multiply_add_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_constant_let)[0]))) * (int64_t)1713759410) + ((int64_t)1 << ((int64_t)((0 + 31) - 1)))) >> ((int64_t)(0 + 31))))) + 24;
      int32_t v__5 = (v__4) < (127) ? (v__4) : (127);
      T_cast[cse_var_2] = ((int8_t)((v__5) > (-128) ? (v__5) : (-128)));
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_cast_subtract_fixed_point_multiply_add_cast_subtract_fixed_point_multiply__ed64f25d07613c12_(int8_t* p0, int8_t* p1, int8_t* T_cast, uint8_t* global_const_workspace_54_var, uint8_t* global_workspace_55_var) {
  void* fused_cast_subtract_fixed_point_multiply_add_cast_constant_let = (&(global_const_workspace_54_var[784208]));
  void* fused_cast_constant_let = (&(global_const_workspace_54_var[784304]));
  for (int32_t ax0_ax1_fused = 0; ax0_ax1_fused < 8; ++ax0_ax1_fused) {
    for (int32_t ax2 = 0; ax2 < 8; ++ax2) {
      for (int32_t ax3_outer = 0; ax3_outer < 2; ++ax3_outer) {
        for (int32_t ax3_inner = 0; ax3_inner < 16; ++ax3_inner) {
          if (((ax3_outer * 2) + (ax3_inner >> 3)) < 3) {
            int32_t cse_var_1 = ((((ax0_ax1_fused * 192) + (ax2 * 24)) + (ax3_outer * 16)) + ax3_inner);
            int32_t v_ = (((int32_t)(((((0 != 0) ? (((int64_t)(((int32_t)p0[cse_var_1]) - ((int32_t*)fused_cast_constant_let)[0])) << ((int64_t)0)) : ((int64_t)(((int32_t)p0[cse_var_1]) - ((int32_t*)fused_cast_constant_let)[0]))) * (int64_t)1824104132) + ((int64_t)1 << ((int64_t)((0 + 31) - 1)))) >> ((int64_t)(0 + 31)))) + ((int32_t)(((((0 != 0) ? (((int64_t)(((int32_t)p1[cse_var_1]) - ((int32_t*)fused_cast_subtract_fixed_point_multiply_add_cast_constant_let)[0])) << ((int64_t)0)) : ((int64_t)(((int32_t)p1[cse_var_1]) - ((int32_t*)fused_cast_subtract_fixed_point_multiply_add_cast_constant_let)[0]))) * (int64_t)1617122022) + ((int64_t)1 << ((int64_t)((0 + 31) - 1)))) >> ((int64_t)(0 + 31))))) + 9;
            int32_t v__1 = (v_) < (127) ? (v_) : (127);
            T_cast[cse_var_1] = ((int8_t)((v__1) > (-128) ? (v__1) : (-128)));
          }
        }
      }
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_cast_subtract_fixed_point_multiply_add_nn_conv2d_subtract_add_fixed_point__7462b0c1d1f4a4f5_(int8_t* p0, int8_t* p1, int8_t* T_cast, uint8_t* global_const_workspace_162_var, uint8_t* global_workspace_163_var) {
  void* fused_cast_subtract_fixed_point_multiply_add_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_constant_let = (&(global_const_workspace_162_var[784192]));
  void* fused_cast_subtract_fixed_point_multiply_add_nn_conv2d_subtract_add_constant_2_let = (&(global_const_workspace_162_var[774160]));
  void* fused_cast_subtract_fixed_point_multiply_add_nn_conv2d_subtract_add_constant_1_let = (&(global_const_workspace_162_var[774320]));
  void* fused_cast_subtract_fixed_point_multiply_add_nn_conv2d_subtract_add_constant_let = (&(global_const_workspace_162_var[774480]));
  void* fused_cast_subtract_fixed_point_multiply_add_nn_conv2d_constant_let = (&(global_const_workspace_162_var[774640]));
  void* fused_cast_subtract_fixed_point_multiply_add_nn_conv2d_subtract_constant_let = (&(global_const_workspace_162_var[774000]));
  void* fused_cast_constant_2_let = (&(global_const_workspace_162_var[784272]));
  void* fused_cast_subtract_fixed_point_multiply_add_constant_let = (&(global_const_workspace_162_var[560016]));
  void* pad_temp_let = (&(global_workspace_163_var[9600]));
  for (int32_t i0_i1_fused = 0; i0_i1_fused < 4; ++i0_i1_fused) {
    for (int32_t i2 = 0; i2 < 4; ++i2) {
      for (int32_t i3 = 0; i3 < 120; ++i3) {
        int32_t cse_var_1 = (((i0_i1_fused * 480) + (i2 * 120)) + i3);
        ((int8_t*)pad_temp_let)[cse_var_1] = p1[cse_var_1];
      }
    }
  }
  for (int32_t ax0_ax1_fused_ax2_fused = 0; ax0_ax1_fused_ax2_fused < 16; ++ax0_ax1_fused_ax2_fused) {
    void* conv2d_nhwc_let = (&(global_workspace_163_var[52736]));
    for (int32_t ax3 = 0; ax3 < 40; ++ax3) {
      int32_t cse_var_2 = ((ax0_ax1_fused_ax2_fused * 40) + ax3);
      ((int32_t*)conv2d_nhwc_let)[0] = 0;
      for (int32_t rc = 0; rc < 120; ++rc) {
        ((int32_t*)conv2d_nhwc_let)[0] = (((int32_t*)conv2d_nhwc_let)[0] + (((int32_t)((int8_t*)pad_temp_let)[((ax0_ax1_fused_ax2_fused * 120) + rc)]) * ((int32_t)((int8_t*)fused_cast_subtract_fixed_point_multiply_add_constant_let)[((rc * 40) + ax3)])));
      }
      int32_t v_ = ((int32_t)(((((int64_t)((((int32_t*)conv2d_nhwc_let)[0] + ((int32_t*)fused_cast_subtract_fixed_point_multiply_add_nn_conv2d_subtract_constant_let)[ax3]) - ((int32_t*)fused_cast_subtract_fixed_point_multiply_add_nn_conv2d_constant_let)[ax3])) * ((int64_t)((int32_t*)fused_cast_subtract_fixed_point_multiply_add_nn_conv2d_subtract_add_constant_let)[ax3])) + ((int64_t)1 << ((int64_t)((((int32_t*)fused_cast_subtract_fixed_point_multiply_add_nn_conv2d_subtract_add_constant_2_let)[ax3] + 31) - 1)))) >> ((int64_t)(((int32_t*)fused_cast_subtract_fixed_point_multiply_add_nn_conv2d_subtract_add_constant_2_let)[ax3] + 31)))) - 14;
      int32_t v__1 = (v_) < (127) ? (v_) : (127);
      int32_t v__2 = ((int32_t)(((((int64_t)((((int32_t*)conv2d_nhwc_let)[0] + ((int32_t*)fused_cast_subtract_fixed_point_multiply_add_nn_conv2d_subtract_constant_let)[ax3]) - ((int32_t*)fused_cast_subtract_fixed_point_multiply_add_nn_conv2d_constant_let)[ax3])) * ((int64_t)((int32_t*)fused_cast_subtract_fixed_point_multiply_add_nn_conv2d_subtract_add_constant_let)[ax3])) + ((int64_t)1 << ((int64_t)((((int32_t*)fused_cast_subtract_fixed_point_multiply_add_nn_conv2d_subtract_add_constant_2_let)[ax3] + 31) - 1)))) >> ((int64_t)(((int32_t*)fused_cast_subtract_fixed_point_multiply_add_nn_conv2d_subtract_add_constant_2_let)[ax3] + 31)))) - 14;
      int32_t v__3 = (v__2) < (127) ? (v__2) : (127);
      int32_t v__4 = (((int32_t)(((((0 != 0) ? (((int64_t)(((int32_t)p0[cse_var_2]) - ((int32_t*)fused_cast_constant_2_let)[0])) << ((int64_t)0)) : ((int64_t)(((int32_t)p0[cse_var_2]) - ((int32_t*)fused_cast_constant_2_let)[0]))) * (int64_t)1601486657) + ((int64_t)1 << ((int64_t)((0 + 31) - 1)))) >> ((int64_t)(0 + 31)))) + ((int32_t)(((((0 != 0) ? (((int64_t)(((v__1) > (-128) ? (v__1) : (-128)) - ((int32_t*)fused_cast_subtract_fixed_point_multiply_add_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_constant_let)[0])) << ((int64_t)0)) : ((int64_t)(((v__3) > (-128) ? (v__3) : (-128)) - ((int32_t*)fused_cast_subtract_fixed_point_multiply_add_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_constant_let)[0]))) * (int64_t)2124099591) + ((int64_t)1 << ((int64_t)((0 + 31) - 1)))) >> ((int64_t)(0 + 31))))) - 20;
      int32_t v__5 = (v__4) < (127) ? (v__4) : (127);
      T_cast[cse_var_2] = ((int8_t)((v__5) > (-128) ? (v__5) : (-128)));
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_cast_subtract_fixed_point_multiply_add_nn_conv2d_subtract_add_fixed_point__7462b0c1d1f4a4f5__1(int8_t* p0, int8_t* p1, int8_t* T_cast, uint8_t* global_const_workspace_198_var, uint8_t* global_workspace_199_var) {
  void* fused_cast_subtract_fixed_point_multiply_add_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_constant_1_let = (&(global_const_workspace_198_var[784176]));
  void* fused_cast_subtract_fixed_point_multiply_add_nn_conv2d_subtract_add_constant_5_let = (&(global_const_workspace_198_var[766768]));
  void* fused_cast_subtract_fixed_point_multiply_add_nn_conv2d_subtract_add_constant_4_let = (&(global_const_workspace_198_var[767056]));
  void* fused_cast_subtract_fixed_point_multiply_add_nn_conv2d_subtract_add_constant_3_let = (&(global_const_workspace_198_var[767344]));
  void* fused_cast_subtract_fixed_point_multiply_add_nn_conv2d_constant_1_let = (&(global_const_workspace_198_var[767920]));
  void* fused_cast_subtract_fixed_point_multiply_add_nn_conv2d_subtract_constant_1_let = (&(global_const_workspace_198_var[765616]));
  void* fused_cast_constant_3_let = (&(global_const_workspace_198_var[784256]));
  void* fused_cast_subtract_fixed_point_multiply_add_constant_1_let = (&(global_const_workspace_198_var[317952]));
  void* pad_temp_let = (&(global_workspace_199_var[10368]));
  for (int32_t i0_i1_fused = 0; i0_i1_fused < 2; ++i0_i1_fused) {
    for (int32_t i2 = 0; i2 < 2; ++i2) {
      for (int32_t i3 = 0; i3 < 432; ++i3) {
        int32_t cse_var_1 = (((i0_i1_fused * 864) + (i2 * 432)) + i3);
        ((int8_t*)pad_temp_let)[cse_var_1] = p1[cse_var_1];
      }
    }
  }
  for (int32_t ax0_ax1_fused_ax2_fused = 0; ax0_ax1_fused_ax2_fused < 4; ++ax0_ax1_fused_ax2_fused) {
    void* conv2d_nhwc_let = (&(global_workspace_199_var[54176]));
    for (int32_t ax3 = 0; ax3 < 72; ++ax3) {
      int32_t cse_var_2 = ((ax0_ax1_fused_ax2_fused * 72) + ax3);
      ((int32_t*)conv2d_nhwc_let)[0] = 0;
      for (int32_t rc = 0; rc < 432; ++rc) {
        ((int32_t*)conv2d_nhwc_let)[0] = (((int32_t*)conv2d_nhwc_let)[0] + (((int32_t)((int8_t*)pad_temp_let)[((ax0_ax1_fused_ax2_fused * 432) + rc)]) * ((int32_t)((int8_t*)fused_cast_subtract_fixed_point_multiply_add_constant_1_let)[((rc * 72) + ax3)])));
      }
      int32_t v_ = ((int32_t)(((((int64_t)((((int32_t*)conv2d_nhwc_let)[0] + ((int32_t*)fused_cast_subtract_fixed_point_multiply_add_nn_conv2d_subtract_constant_1_let)[ax3]) - ((int32_t*)fused_cast_subtract_fixed_point_multiply_add_nn_conv2d_constant_1_let)[ax3])) * ((int64_t)((int32_t*)fused_cast_subtract_fixed_point_multiply_add_nn_conv2d_subtract_add_constant_3_let)[ax3])) + ((int64_t)1 << ((int64_t)((((int32_t*)fused_cast_subtract_fixed_point_multiply_add_nn_conv2d_subtract_add_constant_5_let)[ax3] + 31) - 1)))) >> ((int64_t)(((int32_t*)fused_cast_subtract_fixed_point_multiply_add_nn_conv2d_subtract_add_constant_5_let)[ax3] + 31)))) + 30;
      int32_t v__1 = (v_) < (127) ? (v_) : (127);
      int32_t v__2 = ((int32_t)(((((int64_t)((((int32_t*)conv2d_nhwc_let)[0] + ((int32_t*)fused_cast_subtract_fixed_point_multiply_add_nn_conv2d_subtract_constant_1_let)[ax3]) - ((int32_t*)fused_cast_subtract_fixed_point_multiply_add_nn_conv2d_constant_1_let)[ax3])) * ((int64_t)((int32_t*)fused_cast_subtract_fixed_point_multiply_add_nn_conv2d_subtract_add_constant_3_let)[ax3])) + ((int64_t)1 << ((int64_t)((((int32_t*)fused_cast_subtract_fixed_point_multiply_add_nn_conv2d_subtract_add_constant_5_let)[ax3] + 31) - 1)))) >> ((int64_t)(((int32_t*)fused_cast_subtract_fixed_point_multiply_add_nn_conv2d_subtract_add_constant_5_let)[ax3] + 31)))) + 30;
      int32_t v__3 = (v__2) < (127) ? (v__2) : (127);
      int32_t v__4 = (((int32_t)(((((0 != 0) ? (((int64_t)(((int32_t)p0[cse_var_2]) - ((int32_t*)fused_cast_constant_3_let)[0])) << ((int64_t)0)) : ((int64_t)(((int32_t)p0[cse_var_2]) - ((int32_t*)fused_cast_constant_3_let)[0]))) * (int64_t)1996538816) + ((int64_t)1 << ((int64_t)((1 + 31) - 1)))) >> ((int64_t)(1 + 31)))) + ((int32_t)(((((0 != 0) ? (((int64_t)(((v__1) > (-128) ? (v__1) : (-128)) - ((int32_t*)fused_cast_subtract_fixed_point_multiply_add_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_constant_1_let)[0])) << ((int64_t)0)) : ((int64_t)(((v__3) > (-128) ? (v__3) : (-128)) - ((int32_t*)fused_cast_subtract_fixed_point_multiply_add_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_constant_1_let)[0]))) * (int64_t)1881217306) + ((int64_t)1 << ((int64_t)((0 + 31) - 1)))) >> ((int64_t)(0 + 31))))) + 14;
      int32_t v__5 = (v__4) < (127) ? (v__4) : (127);
      T_cast[cse_var_2] = ((int8_t)((v__5) > (-128) ? (v__5) : (-128)));
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_cast_subtract_fixed_point_multiply_add_nn_conv2d_subtract_add_fixed_point__7462b0c1d1f4a4f5__2(int8_t* p0, int8_t* p1, int8_t* T_cast, uint8_t* global_const_workspace_214_var, uint8_t* global_workspace_215_var) {
  void* fused_cast_subtract_fixed_point_multiply_add_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_constant_2_let = (&(global_const_workspace_214_var[784160]));
  void* fused_cast_subtract_fixed_point_multiply_add_nn_conv2d_subtract_add_constant_8_let = (&(global_const_workspace_214_var[765904]));
  void* fused_cast_subtract_fixed_point_multiply_add_nn_conv2d_subtract_add_constant_7_let = (&(global_const_workspace_214_var[766192]));
  void* fused_cast_subtract_fixed_point_multiply_add_nn_conv2d_subtract_add_constant_6_let = (&(global_const_workspace_214_var[766480]));
  void* fused_cast_subtract_fixed_point_multiply_add_nn_conv2d_constant_2_let = (&(global_const_workspace_214_var[767632]));
  void* fused_cast_subtract_fixed_point_multiply_add_nn_conv2d_subtract_constant_2_let = (&(global_const_workspace_214_var[765328]));
  void* fused_cast_constant_4_let = (&(global_const_workspace_214_var[784240]));
  void* fused_cast_subtract_fixed_point_multiply_add_constant_2_let = (&(global_const_workspace_214_var[286848]));
  void* pad_temp_let = (&(global_workspace_215_var[10368]));
  for (int32_t i0_i1_fused = 0; i0_i1_fused < 2; ++i0_i1_fused) {
    for (int32_t i2 = 0; i2 < 2; ++i2) {
      for (int32_t i3 = 0; i3 < 432; ++i3) {
        int32_t cse_var_1 = (((i0_i1_fused * 864) + (i2 * 432)) + i3);
        ((int8_t*)pad_temp_let)[cse_var_1] = p1[cse_var_1];
      }
    }
  }
  for (int32_t ax0_ax1_fused_ax2_fused = 0; ax0_ax1_fused_ax2_fused < 4; ++ax0_ax1_fused_ax2_fused) {
    void* conv2d_nhwc_let = (&(global_workspace_215_var[54176]));
    for (int32_t ax3 = 0; ax3 < 72; ++ax3) {
      int32_t cse_var_2 = ((ax0_ax1_fused_ax2_fused * 72) + ax3);
      ((int32_t*)conv2d_nhwc_let)[0] = 0;
      for (int32_t rc = 0; rc < 432; ++rc) {
        ((int32_t*)conv2d_nhwc_let)[0] = (((int32_t*)conv2d_nhwc_let)[0] + (((int32_t)((int8_t*)pad_temp_let)[((ax0_ax1_fused_ax2_fused * 432) + rc)]) * ((int32_t)((int8_t*)fused_cast_subtract_fixed_point_multiply_add_constant_2_let)[((rc * 72) + ax3)])));
      }
      int32_t v_ = ((int32_t)(((((int64_t)((((int32_t*)conv2d_nhwc_let)[0] + ((int32_t*)fused_cast_subtract_fixed_point_multiply_add_nn_conv2d_subtract_constant_2_let)[ax3]) - ((int32_t*)fused_cast_subtract_fixed_point_multiply_add_nn_conv2d_constant_2_let)[ax3])) * ((int64_t)((int32_t*)fused_cast_subtract_fixed_point_multiply_add_nn_conv2d_subtract_add_constant_6_let)[ax3])) + ((int64_t)1 << ((int64_t)((((int32_t*)fused_cast_subtract_fixed_point_multiply_add_nn_conv2d_subtract_add_constant_8_let)[ax3] + 31) - 1)))) >> ((int64_t)(((int32_t*)fused_cast_subtract_fixed_point_multiply_add_nn_conv2d_subtract_add_constant_8_let)[ax3] + 31)))) + 25;
      int32_t v__1 = (v_) < (127) ? (v_) : (127);
      int32_t v__2 = ((int32_t)(((((int64_t)((((int32_t*)conv2d_nhwc_let)[0] + ((int32_t*)fused_cast_subtract_fixed_point_multiply_add_nn_conv2d_subtract_constant_2_let)[ax3]) - ((int32_t*)fused_cast_subtract_fixed_point_multiply_add_nn_conv2d_constant_2_let)[ax3])) * ((int64_t)((int32_t*)fused_cast_subtract_fixed_point_multiply_add_nn_conv2d_subtract_add_constant_6_let)[ax3])) + ((int64_t)1 << ((int64_t)((((int32_t*)fused_cast_subtract_fixed_point_multiply_add_nn_conv2d_subtract_add_constant_8_let)[ax3] + 31) - 1)))) >> ((int64_t)(((int32_t*)fused_cast_subtract_fixed_point_multiply_add_nn_conv2d_subtract_add_constant_8_let)[ax3] + 31)))) + 25;
      int32_t v__3 = (v__2) < (127) ? (v__2) : (127);
      int32_t v__4 = (((int32_t)(((((0 != 0) ? (((int64_t)(((int32_t)p0[cse_var_2]) - ((int32_t*)fused_cast_constant_4_let)[0])) << ((int64_t)0)) : ((int64_t)(((int32_t)p0[cse_var_2]) - ((int32_t*)fused_cast_constant_4_let)[0]))) * (int64_t)1275096805) + ((int64_t)1 << ((int64_t)((2 + 31) - 1)))) >> ((int64_t)(2 + 31)))) + ((int32_t)(((((0 != 0) ? (((int64_t)(((v__1) > (-128) ? (v__1) : (-128)) - ((int32_t*)fused_cast_subtract_fixed_point_multiply_add_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_constant_2_let)[0])) << ((int64_t)0)) : ((int64_t)(((v__3) > (-128) ? (v__3) : (-128)) - ((int32_t*)fused_cast_subtract_fixed_point_multiply_add_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_constant_2_let)[0]))) * (int64_t)1915484708) + ((int64_t)1 << ((int64_t)((0 + 31) - 1)))) >> ((int64_t)(0 + 31))))) + 29;
      int32_t v__5 = (v__4) < (127) ? (v__4) : (127);
      T_cast[cse_var_2] = ((int8_t)((v__5) > (-128) ? (v__5) : (-128)));
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_cast_subtract_fixed_point_multiply_nn_conv2d_subtract_add_fixed_point_mult_6a0898f32fb5072b_(int8_t* p0, int8_t* p1, int8_t* T_cast, uint8_t* global_const_workspace_110_var, uint8_t* global_workspace_111_var) {
  void* fused_cast_subtract_fixed_point_multiply_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_constant_let = (&(global_const_workspace_110_var[784144]));
  void* fused_cast_subtract_fixed_point_multiply_nn_conv2d_subtract_add_constant_2_let = (&(global_const_workspace_110_var[778400]));
  void* fused_cast_subtract_fixed_point_multiply_nn_conv2d_subtract_add_constant_1_let = (&(global_const_workspace_110_var[778528]));
  void* fused_cast_subtract_fixed_point_multiply_nn_conv2d_subtract_add_constant_let = (&(global_const_workspace_110_var[778656]));
  void* fused_cast_subtract_fixed_point_multiply_nn_conv2d_constant_let = (&(global_const_workspace_110_var[778784]));
  void* fused_cast_subtract_fixed_point_multiply_nn_conv2d_subtract_constant_let = (&(global_const_workspace_110_var[778272]));
  void* fused_cast_constant_1_let = (&(global_const_workspace_110_var[784288]));
  void* fused_cast_subtract_fixed_point_multiply_constant_let = (&(global_const_workspace_110_var[527328]));
  void* pad_temp_let = (&(global_workspace_111_var[15360]));
  for (int32_t i0_i1_fused = 0; i0_i1_fused < 4; ++i0_i1_fused) {
    for (int32_t i2 = 0; i2 < 4; ++i2) {
      for (int32_t i3 = 0; i3 < 192; ++i3) {
        int32_t cse_var_1 = (((i0_i1_fused * 768) + (i2 * 192)) + i3);
        ((int8_t*)pad_temp_let)[cse_var_1] = p1[cse_var_1];
      }
    }
  }
  for (int32_t ax0_ax1_fused_ax2_fused = 0; ax0_ax1_fused_ax2_fused < 16; ++ax0_ax1_fused_ax2_fused) {
    void* conv2d_nhwc_let = (&(global_workspace_111_var[53248]));
    for (int32_t ax3 = 0; ax3 < 32; ++ax3) {
      int32_t cse_var_2 = ((ax0_ax1_fused_ax2_fused * 32) + ax3);
      ((int32_t*)conv2d_nhwc_let)[0] = 0;
      for (int32_t rc = 0; rc < 192; ++rc) {
        ((int32_t*)conv2d_nhwc_let)[0] = (((int32_t*)conv2d_nhwc_let)[0] + (((int32_t)((int8_t*)pad_temp_let)[((ax0_ax1_fused_ax2_fused * 192) + rc)]) * ((int32_t)((int8_t*)fused_cast_subtract_fixed_point_multiply_constant_let)[((rc * 32) + ax3)])));
      }
      int32_t v_ = ((int32_t)(((((int64_t)((((int32_t*)conv2d_nhwc_let)[0] + ((int32_t*)fused_cast_subtract_fixed_point_multiply_nn_conv2d_subtract_constant_let)[ax3]) - ((int32_t*)fused_cast_subtract_fixed_point_multiply_nn_conv2d_constant_let)[ax3])) * ((int64_t)((int32_t*)fused_cast_subtract_fixed_point_multiply_nn_conv2d_subtract_add_constant_let)[ax3])) + ((int64_t)1 << ((int64_t)((((int32_t*)fused_cast_subtract_fixed_point_multiply_nn_conv2d_subtract_add_constant_2_let)[ax3] + 31) - 1)))) >> ((int64_t)(((int32_t*)fused_cast_subtract_fixed_point_multiply_nn_conv2d_subtract_add_constant_2_let)[ax3] + 31)))) + 7;
      int32_t v__1 = (v_) < (127) ? (v_) : (127);
      int32_t v__2 = ((int32_t)(((((int64_t)((((int32_t*)conv2d_nhwc_let)[0] + ((int32_t*)fused_cast_subtract_fixed_point_multiply_nn_conv2d_subtract_constant_let)[ax3]) - ((int32_t*)fused_cast_subtract_fixed_point_multiply_nn_conv2d_constant_let)[ax3])) * ((int64_t)((int32_t*)fused_cast_subtract_fixed_point_multiply_nn_conv2d_subtract_add_constant_let)[ax3])) + ((int64_t)1 << ((int64_t)((((int32_t*)fused_cast_subtract_fixed_point_multiply_nn_conv2d_subtract_add_constant_2_let)[ax3] + 31) - 1)))) >> ((int64_t)(((int32_t*)fused_cast_subtract_fixed_point_multiply_nn_conv2d_subtract_add_constant_2_let)[ax3] + 31)))) + 7;
      int32_t v__3 = (v__2) < (127) ? (v__2) : (127);
      int32_t v__4 = ((int32_t)(((((0 != 0) ? (((int64_t)(((int32_t)p0[cse_var_2]) - ((int32_t*)fused_cast_constant_1_let)[0])) << ((int64_t)0)) : ((int64_t)(((int32_t)p0[cse_var_2]) - ((int32_t*)fused_cast_constant_1_let)[0]))) * (int64_t)1580484798) + ((int64_t)1 << ((int64_t)((0 + 31) - 1)))) >> ((int64_t)(0 + 31)))) + ((int32_t)(((((1 != 0) ? (((int64_t)(((v__1) > (-128) ? (v__1) : (-128)) - ((int32_t*)fused_cast_subtract_fixed_point_multiply_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_constant_let)[0])) << ((int64_t)1)) : ((int64_t)(((v__3) > (-128) ? (v__3) : (-128)) - ((int32_t*)fused_cast_subtract_fixed_point_multiply_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_constant_let)[0]))) * (int64_t)1131365474) + ((int64_t)1 << ((int64_t)((0 + 31) - 1)))) >> ((int64_t)(0 + 31))));
      int32_t v__5 = (v__4) < (127) ? (v__4) : (127);
      T_cast[cse_var_2] = ((int8_t)((v__5) > (-128) ? (v__5) : (-128)));
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_divide_round_add_clip_cast_nn_pad(float* p0, int8_t* T_pad, uint8_t* global_const_workspace_2_var, uint8_t* global_workspace_3_var) {
  for (int32_t ax0_ax1_fused = 0; ax0_ax1_fused < 65; ++ax0_ax1_fused) {
    for (int32_t ax2 = 0; ax2 < 65; ++ax2) {
      for (int32_t ax3_inner = 0; ax3_inner < 3; ++ax3_inner) {
        int32_t cse_var_1 = (ax2 * 3);
        float v_ = roundf((p0[(((ax0_ax1_fused * 192) + cse_var_1) + ax3_inner)] * 2.550000e+02f)) + -1.280000e+02f;
        float v__1 = (v_) < (1.270000e+02f) ? (v_) : (1.270000e+02f);
        T_pad[(((ax0_ax1_fused * 195) + cse_var_1) + ax3_inner)] = (((ax0_ax1_fused < 64) && (ax2 < 64)) ? ((int8_t)((v__1) > (-1.280000e+02f) ? (v__1) : (-1.280000e+02f))) : (int8_t)-128);
      }
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_mean(int32_t* p0, int32_t* T_divide, uint8_t* global_const_workspace_10_var, uint8_t* global_workspace_11_var) {
  void* p0_red_let = (&(global_workspace_11_var[16448]));
  for (int32_t ax0_ax1_fused_ax2_fused_ax3_fused = 0; ax0_ax1_fused_ax2_fused_ax3_fused < 16; ++ax0_ax1_fused_ax2_fused_ax3_fused) {
    ((int32_t*)p0_red_let)[ax0_ax1_fused_ax2_fused_ax3_fused] = 0;
    for (int32_t k1 = 0; k1 < 16; ++k1) {
      for (int32_t k2 = 0; k2 < 16; ++k2) {
        ((int32_t*)p0_red_let)[ax0_ax1_fused_ax2_fused_ax3_fused] = (((int32_t*)p0_red_let)[ax0_ax1_fused_ax2_fused_ax3_fused] + p0[(((k1 * 256) + (k2 * 16)) + ax0_ax1_fused_ax2_fused_ax3_fused)]);
      }
    }
  }
  for (int32_t ax3_inner = 0; ax3_inner < 16; ++ax3_inner) {
    T_divide[ax3_inner] = (((int32_t*)p0_red_let)[ax3_inner] / 256);
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_mean_1(int32_t* p0, int32_t* T_divide, uint8_t* global_const_workspace_42_var, uint8_t* global_workspace_43_var) {
  void* p0_red_let = (&(global_workspace_43_var[34528]));
  for (int32_t ax0_ax1_fused = 0; ax0_ax1_fused < 32; ++ax0_ax1_fused) {
    ((int32_t*)p0_red_let)[ax0_ax1_fused] = 0;
    for (int32_t k1 = 0; k1 < 8; ++k1) {
      for (int32_t k2 = 0; k2 < 8; ++k2) {
        ((int32_t*)p0_red_let)[ax0_ax1_fused] = (((int32_t*)p0_red_let)[ax0_ax1_fused] + p0[(((k1 * 256) + (k2 * 32)) + ax0_ax1_fused)]);
      }
    }
  }
  for (int32_t ax1_outer = 0; ax1_outer < 2; ++ax1_outer) {
    for (int32_t ax1_inner = 0; ax1_inner < 16; ++ax1_inner) {
      int32_t cse_var_1 = ((ax1_outer * 16) + ax1_inner);
      T_divide[cse_var_1] = (((int32_t*)p0_red_let)[cse_var_1] / 64);
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_mean_10(int32_t* p0, int32_t* T_divide, uint8_t* global_const_workspace_234_var, uint8_t* global_workspace_235_var) {
  void* p0_red_let = (&(global_workspace_235_var[2176]));
  for (int32_t ax0_ax1_fused = 0; ax0_ax1_fused < 16; ++ax0_ax1_fused) {
    ((int32_t*)p0_red_let)[ax0_ax1_fused] = 0;
    for (int32_t k1 = 0; k1 < 4; ++k1) {
      for (int32_t k2 = 0; k2 < 4; ++k2) {
        ((int32_t*)p0_red_let)[ax0_ax1_fused] = (((int32_t*)p0_red_let)[ax0_ax1_fused] + p0[(((k1 * 64) + (k2 * 16)) + ax0_ax1_fused)]);
      }
    }
  }
  for (int32_t ax1_inner = 0; ax1_inner < 16; ++ax1_inner) {
    T_divide[ax1_inner] = (((int32_t*)p0_red_let)[ax1_inner] / 16);
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_mean_2(int32_t* p0, int32_t* T_divide, uint8_t* global_const_workspace_62_var, uint8_t* global_workspace_63_var) {
  void* p0_red_let = (&(global_workspace_63_var[6528]));
  for (int32_t ax0_ax1_fused_ax2_fused_ax3_fused = 0; ax0_ax1_fused_ax2_fused_ax3_fused < 96; ++ax0_ax1_fused_ax2_fused_ax3_fused) {
    ((int32_t*)p0_red_let)[ax0_ax1_fused_ax2_fused_ax3_fused] = 0;
    for (int32_t k1 = 0; k1 < 4; ++k1) {
      for (int32_t k2 = 0; k2 < 4; ++k2) {
        ((int32_t*)p0_red_let)[ax0_ax1_fused_ax2_fused_ax3_fused] = (((int32_t*)p0_red_let)[ax0_ax1_fused_ax2_fused_ax3_fused] + p0[(((k1 * 384) + (k2 * 96)) + ax0_ax1_fused_ax2_fused_ax3_fused)]);
      }
    }
  }
  for (int32_t ax3_outer = 0; ax3_outer < 6; ++ax3_outer) {
    for (int32_t ax3_inner = 0; ax3_inner < 16; ++ax3_inner) {
      int32_t cse_var_1 = ((ax3_outer * 16) + ax3_inner);
      T_divide[cse_var_1] = (((int32_t*)p0_red_let)[cse_var_1] / 16);
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_mean_3(int32_t* p0, int32_t* T_divide, uint8_t* global_const_workspace_82_var, uint8_t* global_workspace_83_var) {
  void* p0_red_let = (&(global_workspace_83_var[53312]));
  for (int32_t ax0_ax1_fused = 0; ax0_ax1_fused < 16; ++ax0_ax1_fused) {
    ((int32_t*)p0_red_let)[ax0_ax1_fused] = 0;
    for (int32_t k1 = 0; k1 < 4; ++k1) {
      for (int32_t k2 = 0; k2 < 4; ++k2) {
        ((int32_t*)p0_red_let)[ax0_ax1_fused] = (((int32_t*)p0_red_let)[ax0_ax1_fused] + p0[(((k1 * 64) + (k2 * 16)) + ax0_ax1_fused)]);
      }
    }
  }
  for (int32_t ax1_inner = 0; ax1_inner < 16; ++ax1_inner) {
    T_divide[ax1_inner] = (((int32_t*)p0_red_let)[ax1_inner] / 16);
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_mean_4(int32_t* p0, int32_t* T_divide, uint8_t* global_const_workspace_100_var, uint8_t* global_workspace_101_var) {
  void* p0_red_let = (&(global_workspace_101_var[12288]));
  for (int32_t ax0_ax1_fused_ax2_fused_ax3_fused = 0; ax0_ax1_fused_ax2_fused_ax3_fused < 192; ++ax0_ax1_fused_ax2_fused_ax3_fused) {
    ((int32_t*)p0_red_let)[ax0_ax1_fused_ax2_fused_ax3_fused] = 0;
    for (int32_t k1 = 0; k1 < 4; ++k1) {
      for (int32_t k2 = 0; k2 < 4; ++k2) {
        ((int32_t*)p0_red_let)[ax0_ax1_fused_ax2_fused_ax3_fused] = (((int32_t*)p0_red_let)[ax0_ax1_fused_ax2_fused_ax3_fused] + p0[(((k1 * 768) + (k2 * 192)) + ax0_ax1_fused_ax2_fused_ax3_fused)]);
      }
    }
  }
  for (int32_t ax3_outer = 0; ax3_outer < 12; ++ax3_outer) {
    for (int32_t ax3_inner = 0; ax3_inner < 16; ++ax3_inner) {
      int32_t cse_var_1 = ((ax3_outer * 16) + ax3_inner);
      T_divide[cse_var_1] = (((int32_t*)p0_red_let)[cse_var_1] / 16);
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_mean_5(int32_t* p0, int32_t* T_divide, uint8_t* global_const_workspace_134_var, uint8_t* global_workspace_135_var) {
  void* p0_red_let = (&(global_workspace_135_var[53120]));
  for (int32_t ax0_ax1_fused_ax2_fused_ax3_fused = 0; ax0_ax1_fused_ax2_fused_ax3_fused < 96; ++ax0_ax1_fused_ax2_fused_ax3_fused) {
    ((int32_t*)p0_red_let)[ax0_ax1_fused_ax2_fused_ax3_fused] = 0;
    for (int32_t k1 = 0; k1 < 4; ++k1) {
      for (int32_t k2 = 0; k2 < 4; ++k2) {
        ((int32_t*)p0_red_let)[ax0_ax1_fused_ax2_fused_ax3_fused] = (((int32_t*)p0_red_let)[ax0_ax1_fused_ax2_fused_ax3_fused] + p0[(((k1 * 384) + (k2 * 96)) + ax0_ax1_fused_ax2_fused_ax3_fused)]);
      }
    }
  }
  for (int32_t ax3_outer = 0; ax3_outer < 6; ++ax3_outer) {
    for (int32_t ax3_inner = 0; ax3_inner < 16; ++ax3_inner) {
      int32_t cse_var_1 = ((ax3_outer * 16) + ax3_inner);
      T_divide[cse_var_1] = (((int32_t*)p0_red_let)[cse_var_1] / 16);
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_mean_6(int32_t* p0, int32_t* T_divide, uint8_t* global_const_workspace_152_var, uint8_t* global_workspace_153_var) {
  void* p0_red_let = (&(global_workspace_153_var[53216]));
  for (int32_t ax0_ax1_fused_ax2_fused_ax3_fused = 0; ax0_ax1_fused_ax2_fused_ax3_fused < 120; ++ax0_ax1_fused_ax2_fused_ax3_fused) {
    ((int32_t*)p0_red_let)[ax0_ax1_fused_ax2_fused_ax3_fused] = 0;
    for (int32_t k1 = 0; k1 < 4; ++k1) {
      for (int32_t k2 = 0; k2 < 4; ++k2) {
        ((int32_t*)p0_red_let)[ax0_ax1_fused_ax2_fused_ax3_fused] = (((int32_t*)p0_red_let)[ax0_ax1_fused_ax2_fused_ax3_fused] + p0[(((k1 * 480) + (k2 * 120)) + ax0_ax1_fused_ax2_fused_ax3_fused)]);
      }
    }
  }
  for (int32_t ax3_outer = 0; ax3_outer < 8; ++ax3_outer) {
    for (int32_t ax3_inner = 0; ax3_inner < 16; ++ax3_inner) {
      if (((ax3_outer * 2) + (ax3_inner >> 3)) < 15) {
        int32_t cse_var_1 = ((ax3_outer * 16) + ax3_inner);
        T_divide[cse_var_1] = (((int32_t*)p0_red_let)[cse_var_1] / 16);
      }
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_mean_7(int32_t* p0, int32_t* T_divide, uint8_t* global_const_workspace_170_var, uint8_t* global_workspace_171_var) {
  void* p0_red_let = (&(global_workspace_171_var[4800]));
  for (int32_t ax0_ax1_fused_ax2_fused_ax3_fused = 0; ax0_ax1_fused_ax2_fused_ax3_fused < 240; ++ax0_ax1_fused_ax2_fused_ax3_fused) {
    ((int32_t*)p0_red_let)[ax0_ax1_fused_ax2_fused_ax3_fused] = 0;
    for (int32_t k1 = 0; k1 < 2; ++k1) {
      for (int32_t k2 = 0; k2 < 2; ++k2) {
        ((int32_t*)p0_red_let)[ax0_ax1_fused_ax2_fused_ax3_fused] = (((int32_t*)p0_red_let)[ax0_ax1_fused_ax2_fused_ax3_fused] + p0[(((k1 * 480) + (k2 * 240)) + ax0_ax1_fused_ax2_fused_ax3_fused)]);
      }
    }
  }
  for (int32_t ax3_outer = 0; ax3_outer < 15; ++ax3_outer) {
    for (int32_t ax3_inner = 0; ax3_inner < 16; ++ax3_inner) {
      int32_t cse_var_1 = ((ax3_outer * 16) + ax3_inner);
      T_divide[cse_var_1] = (((int32_t*)p0_red_let)[cse_var_1] / 4);
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_mean_8(int32_t* p0, int32_t* T_divide, uint8_t* global_const_workspace_188_var, uint8_t* global_workspace_189_var) {
  void* p0_red_let = (&(global_workspace_189_var[6912]));
  for (int32_t ax0_ax1_fused_ax2_fused_ax3_fused = 0; ax0_ax1_fused_ax2_fused_ax3_fused < 432; ++ax0_ax1_fused_ax2_fused_ax3_fused) {
    ((int32_t*)p0_red_let)[ax0_ax1_fused_ax2_fused_ax3_fused] = 0;
    for (int32_t k1 = 0; k1 < 2; ++k1) {
      for (int32_t k2 = 0; k2 < 2; ++k2) {
        ((int32_t*)p0_red_let)[ax0_ax1_fused_ax2_fused_ax3_fused] = (((int32_t*)p0_red_let)[ax0_ax1_fused_ax2_fused_ax3_fused] + p0[(((k1 * 864) + (k2 * 432)) + ax0_ax1_fused_ax2_fused_ax3_fused)]);
      }
    }
  }
  for (int32_t ax3_outer = 0; ax3_outer < 27; ++ax3_outer) {
    for (int32_t ax3_inner = 0; ax3_inner < 16; ++ax3_inner) {
      int32_t cse_var_1 = ((ax3_outer * 16) + ax3_inner);
      T_divide[cse_var_1] = (((int32_t*)p0_red_let)[cse_var_1] / 4);
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_mean_9(int32_t* p0, int32_t* T_divide, uint8_t* global_const_workspace_218_var, uint8_t* global_workspace_219_var) {
  void* p0_red_let = (&(global_workspace_219_var[6912]));
  for (int32_t ax0_ax1_fused = 0; ax0_ax1_fused < 432; ++ax0_ax1_fused) {
    ((int32_t*)p0_red_let)[ax0_ax1_fused] = 0;
    for (int32_t k1 = 0; k1 < 2; ++k1) {
      for (int32_t k2 = 0; k2 < 2; ++k2) {
        ((int32_t*)p0_red_let)[ax0_ax1_fused] = (((int32_t*)p0_red_let)[ax0_ax1_fused] + p0[(((k1 * 864) + (k2 * 432)) + ax0_ax1_fused)]);
      }
    }
  }
  for (int32_t ax1_outer = 0; ax1_outer < 27; ++ax1_outer) {
    for (int32_t ax1_inner = 0; ax1_inner < 16; ++ax1_inner) {
      int32_t cse_var_1 = ((ax1_outer * 16) + ax1_inner);
      T_divide[cse_var_1] = (((int32_t*)p0_red_let)[cse_var_1] / 4);
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_contrib_dense_pack_subtract_add_fixed_point_multiply_add_clip_cast(int8_t* p0, int8_t* T_cast, uint8_t* global_const_workspace_46_var, uint8_t* global_workspace_47_var) {
  void* fused_nn_contrib_dense_pack_constant_let = (&(global_const_workspace_46_var[733728]));
  void* fused_nn_contrib_dense_pack_subtract_constant_let = (&(global_const_workspace_46_var[732192]));
  void* fused_constant_14_let = (&(global_const_workspace_46_var[578352]));
  for (int32_t ax1_outer_ax0_outer_fused = 0; ax1_outer_ax0_outer_fused < 4; ++ax1_outer_ax0_outer_fused) {
    void* compute_let = (&(global_workspace_47_var[34528]));
    void* compute_global_let = (&(global_workspace_47_var[34688]));
    for (int32_t y_inner_outer_x_inner_outer_fused = 0; y_inner_outer_x_inner_outer_fused < 4; ++y_inner_outer_x_inner_outer_fused) {
      for (int32_t x_c_init = 0; x_c_init < 8; ++x_c_init) {
        ((int32_t*)compute_global_let)[x_c_init] = 0;
      }
      for (int32_t k_outer = 0; k_outer < 32; ++k_outer) {
        for (int32_t x_c = 0; x_c < 8; ++x_c) {
          ((int32_t*)compute_global_let)[x_c] = (((int32_t*)compute_global_let)[x_c] + (((int32_t)p0[k_outer]) * ((int32_t)((int8_t*)fused_constant_14_let)[((((ax1_outer_ax0_outer_fused * 1024) + (y_inner_outer_x_inner_outer_fused * 256)) + (k_outer * 8)) + x_c)])));
        }
      }
      for (int32_t x_inner_inner = 0; x_inner_inner < 8; ++x_inner_inner) {
        ((int32_t*)compute_let)[((y_inner_outer_x_inner_outer_fused * 8) + x_inner_inner)] = ((int32_t*)compute_global_let)[x_inner_inner];
      }
    }
    for (int32_t ax1_inner_outer = 0; ax1_inner_outer < 4; ++ax1_inner_outer) {
      for (int32_t ax1_inner_inner = 0; ax1_inner_inner < 8; ++ax1_inner_inner) {
        int32_t cse_var_2 = (ax1_inner_outer * 8);
        int32_t cse_var_1 = (((ax1_outer_ax0_outer_fused * 32) + cse_var_2) + ax1_inner_inner);
        int32_t v_ = ((int32_t)(((((0 != 0) ? (((int64_t)((((int32_t*)compute_let)[(cse_var_2 + ax1_inner_inner)] + ((int32_t*)fused_nn_contrib_dense_pack_subtract_constant_let)[cse_var_1]) - ((int32_t*)fused_nn_contrib_dense_pack_constant_let)[cse_var_1])) << ((int64_t)0)) : ((int64_t)((((int32_t*)compute_let)[(cse_var_2 + ax1_inner_inner)] + ((int32_t*)fused_nn_contrib_dense_pack_subtract_constant_let)[cse_var_1]) - ((int32_t*)fused_nn_contrib_dense_pack_constant_let)[cse_var_1]))) * (int64_t)1435028005) + ((int64_t)1 << ((int64_t)((7 + 31) - 1)))) >> ((int64_t)(7 + 31)))) - 128;
        int32_t v__1 = (v_) < (127) ? (v_) : (127);
        T_cast[cse_var_1] = ((int8_t)((v__1) > (-128) ? (v__1) : (-128)));
      }
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_contrib_dense_pack_subtract_add_fixed_point_multiply_add_clip_cast_1(int8_t* p0, int8_t* T_cast, uint8_t* global_const_workspace_48_var, uint8_t* global_workspace_49_var) {
  void* fused_nn_contrib_dense_pack_constant_1_let = (&(global_const_workspace_48_var[770768]));
  void* fused_nn_contrib_dense_pack_subtract_constant_1_let = (&(global_const_workspace_48_var[770000]));
  void* fused_constant_15_let = (&(global_const_workspace_48_var[499936]));
  for (int32_t ax1_outer_ax0_outer_fused = 0; ax1_outer_ax0_outer_fused < 4; ++ax1_outer_ax0_outer_fused) {
    void* compute_let = (&(global_workspace_49_var[34592]));
    void* compute_global_let = (&(global_workspace_49_var[34656]));
    for (int32_t y_inner_outer_x_inner_outer_fused = 0; y_inner_outer_x_inner_outer_fused < 2; ++y_inner_outer_x_inner_outer_fused) {
      for (int32_t x_c_init = 0; x_c_init < 8; ++x_c_init) {
        ((int32_t*)compute_global_let)[x_c_init] = 0;
      }
      for (int32_t k_outer = 0; k_outer < 128; ++k_outer) {
        for (int32_t x_c = 0; x_c < 8; ++x_c) {
          ((int32_t*)compute_global_let)[x_c] = (((int32_t*)compute_global_let)[x_c] + (((int32_t)p0[k_outer]) * ((int32_t)((int8_t*)fused_constant_15_let)[((((ax1_outer_ax0_outer_fused * 2048) + (y_inner_outer_x_inner_outer_fused * 1024)) + (k_outer * 8)) + x_c)])));
        }
      }
      for (int32_t x_inner_inner = 0; x_inner_inner < 8; ++x_inner_inner) {
        ((int32_t*)compute_let)[((y_inner_outer_x_inner_outer_fused * 8) + x_inner_inner)] = ((int32_t*)compute_global_let)[x_inner_inner];
      }
    }
    for (int32_t ax1_inner_outer = 0; ax1_inner_outer < 2; ++ax1_inner_outer) {
      for (int32_t ax1_inner_inner = 0; ax1_inner_inner < 8; ++ax1_inner_inner) {
        int32_t cse_var_2 = (ax1_inner_outer * 8);
        int32_t cse_var_1 = (((ax1_outer_ax0_outer_fused * 16) + cse_var_2) + ax1_inner_inner);
        int32_t v_ = ((int32_t)(((((0 != 0) ? (((int64_t)((((int32_t*)compute_let)[(cse_var_2 + ax1_inner_inner)] + ((int32_t*)fused_nn_contrib_dense_pack_subtract_constant_1_let)[cse_var_1]) - ((int32_t*)fused_nn_contrib_dense_pack_constant_1_let)[cse_var_1])) << ((int64_t)0)) : ((int64_t)((((int32_t*)compute_let)[(cse_var_2 + ax1_inner_inner)] + ((int32_t*)fused_nn_contrib_dense_pack_subtract_constant_1_let)[cse_var_1]) - ((int32_t*)fused_nn_contrib_dense_pack_constant_1_let)[cse_var_1]))) * (int64_t)1644877280) + ((int64_t)1 << ((int64_t)((8 + 31) - 1)))) >> ((int64_t)(8 + 31)))) - 128;
        int32_t v__1 = (v_) < (127) ? (v_) : (127);
        T_cast[cse_var_1] = ((int8_t)((v__1) > (-128) ? (v__1) : (-128)));
      }
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_contrib_dense_pack_subtract_add_fixed_point_multiply_add_clip_cast_2(int8_t* p0, int8_t* T_cast, uint8_t* global_const_workspace_86_var, uint8_t* global_workspace_87_var) {
  void* fused_nn_contrib_dense_pack_constant_3_let = (&(global_const_workspace_86_var[733216]));
  void* fused_nn_contrib_dense_pack_subtract_constant_3_let = (&(global_const_workspace_86_var[731680]));
  void* fused_constant_26_let = (&(global_const_workspace_86_var[625712]));
  for (int32_t ax1_outer_ax0_outer_fused = 0; ax1_outer_ax0_outer_fused < 4; ++ax1_outer_ax0_outer_fused) {
    void* compute_let = (&(global_workspace_87_var[53376]));
    void* compute_global_let = (&(global_workspace_87_var[53504]));
    for (int32_t y_inner_outer_x_inner_outer_fused = 0; y_inner_outer_x_inner_outer_fused < 4; ++y_inner_outer_x_inner_outer_fused) {
      for (int32_t x_c_init = 0; x_c_init < 8; ++x_c_init) {
        ((int32_t*)compute_global_let)[x_c_init] = 0;
      }
      for (int32_t k_outer = 0; k_outer < 16; ++k_outer) {
        for (int32_t x_c = 0; x_c < 8; ++x_c) {
          ((int32_t*)compute_global_let)[x_c] = (((int32_t*)compute_global_let)[x_c] + (((int32_t)p0[k_outer]) * ((int32_t)((int8_t*)fused_constant_26_let)[((((ax1_outer_ax0_outer_fused * 512) + (y_inner_outer_x_inner_outer_fused * 128)) + (k_outer * 8)) + x_c)])));
        }
      }
      for (int32_t x_inner_inner = 0; x_inner_inner < 8; ++x_inner_inner) {
        ((int32_t*)compute_let)[((y_inner_outer_x_inner_outer_fused * 8) + x_inner_inner)] = ((int32_t*)compute_global_let)[x_inner_inner];
      }
    }
    for (int32_t ax1_inner_outer = 0; ax1_inner_outer < 4; ++ax1_inner_outer) {
      for (int32_t ax1_inner_inner = 0; ax1_inner_inner < 8; ++ax1_inner_inner) {
        int32_t cse_var_2 = (ax1_inner_outer * 8);
        int32_t cse_var_1 = (((ax1_outer_ax0_outer_fused * 32) + cse_var_2) + ax1_inner_inner);
        int32_t v_ = ((int32_t)(((((0 != 0) ? (((int64_t)((((int32_t*)compute_let)[(cse_var_2 + ax1_inner_inner)] + ((int32_t*)fused_nn_contrib_dense_pack_subtract_constant_3_let)[cse_var_1]) - ((int32_t*)fused_nn_contrib_dense_pack_constant_3_let)[cse_var_1])) << ((int64_t)0)) : ((int64_t)((((int32_t*)compute_let)[(cse_var_2 + ax1_inner_inner)] + ((int32_t*)fused_nn_contrib_dense_pack_subtract_constant_3_let)[cse_var_1]) - ((int32_t*)fused_nn_contrib_dense_pack_constant_3_let)[cse_var_1]))) * (int64_t)1470765431) + ((int64_t)1 << ((int64_t)((7 + 31) - 1)))) >> ((int64_t)(7 + 31)))) - 128;
        int32_t v__1 = (v_) < (127) ? (v_) : (127);
        T_cast[cse_var_1] = ((int8_t)((v__1) > (-128) ? (v__1) : (-128)));
      }
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_contrib_dense_pack_subtract_add_fixed_point_multiply_add_clip_cast_3(int8_t* p0, int8_t* T_cast, uint8_t* global_const_workspace_88_var, uint8_t* global_workspace_89_var) {
  void* fused_nn_contrib_dense_pack_constant_4_let = (&(global_const_workspace_88_var[770512]));
  void* fused_nn_contrib_dense_pack_subtract_constant_4_let = (&(global_const_workspace_88_var[769744]));
  void* fused_constant_27_let = (&(global_const_workspace_88_var[491744]));
  for (int32_t ax1_outer_ax0_outer_fused = 0; ax1_outer_ax0_outer_fused < 4; ++ax1_outer_ax0_outer_fused) {
    void* compute_let = (&(global_workspace_89_var[53440]));
    void* compute_global_let = (&(global_workspace_89_var[53504]));
    for (int32_t y_inner_outer_x_inner_outer_fused = 0; y_inner_outer_x_inner_outer_fused < 2; ++y_inner_outer_x_inner_outer_fused) {
      for (int32_t x_c_init = 0; x_c_init < 8; ++x_c_init) {
        ((int32_t*)compute_global_let)[x_c_init] = 0;
      }
      for (int32_t k_outer = 0; k_outer < 128; ++k_outer) {
        for (int32_t x_c = 0; x_c < 8; ++x_c) {
          ((int32_t*)compute_global_let)[x_c] = (((int32_t*)compute_global_let)[x_c] + (((int32_t)p0[k_outer]) * ((int32_t)((int8_t*)fused_constant_27_let)[((((ax1_outer_ax0_outer_fused * 2048) + (y_inner_outer_x_inner_outer_fused * 1024)) + (k_outer * 8)) + x_c)])));
        }
      }
      for (int32_t x_inner_inner = 0; x_inner_inner < 8; ++x_inner_inner) {
        ((int32_t*)compute_let)[((y_inner_outer_x_inner_outer_fused * 8) + x_inner_inner)] = ((int32_t*)compute_global_let)[x_inner_inner];
      }
    }
    for (int32_t ax1_inner_outer = 0; ax1_inner_outer < 2; ++ax1_inner_outer) {
      for (int32_t ax1_inner_inner = 0; ax1_inner_inner < 8; ++ax1_inner_inner) {
        int32_t cse_var_2 = (ax1_inner_outer * 8);
        int32_t cse_var_1 = (((ax1_outer_ax0_outer_fused * 16) + cse_var_2) + ax1_inner_inner);
        int32_t v_ = ((int32_t)(((((0 != 0) ? (((int64_t)((((int32_t*)compute_let)[(cse_var_2 + ax1_inner_inner)] + ((int32_t*)fused_nn_contrib_dense_pack_subtract_constant_4_let)[cse_var_1]) - ((int32_t*)fused_nn_contrib_dense_pack_constant_4_let)[cse_var_1])) << ((int64_t)0)) : ((int64_t)((((int32_t*)compute_let)[(cse_var_2 + ax1_inner_inner)] + ((int32_t*)fused_nn_contrib_dense_pack_subtract_constant_4_let)[cse_var_1]) - ((int32_t*)fused_nn_contrib_dense_pack_constant_4_let)[cse_var_1]))) * (int64_t)1365053110) + ((int64_t)1 << ((int64_t)((8 + 31) - 1)))) >> ((int64_t)(8 + 31)))) - 128;
        int32_t v__1 = (v_) < (127) ? (v_) : (127);
        T_cast[cse_var_1] = ((int8_t)((v__1) > (-128) ? (v__1) : (-128)));
      }
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_contrib_dense_pack_subtract_add_fixed_point_multiply_add_clip_cast_4(int8_t* p0, int8_t* T_cast, uint8_t* global_const_workspace_238_var, uint8_t* global_workspace_239_var) {
  void* fused_nn_contrib_dense_pack_constant_7_let = (&(global_const_workspace_238_var[732704]));
  void* fused_nn_contrib_dense_pack_subtract_constant_7_let = (&(global_const_workspace_238_var[731168]));
  void* fused_constant_72_let = (&(global_const_workspace_238_var[623664]));
  for (int32_t ax1_outer_ax0_outer_fused = 0; ax1_outer_ax0_outer_fused < 4; ++ax1_outer_ax0_outer_fused) {
    void* compute_let = (&(global_workspace_239_var[128]));
    void* compute_global_let = (&(global_workspace_239_var[256]));
    for (int32_t y_inner_outer_x_inner_outer_fused = 0; y_inner_outer_x_inner_outer_fused < 4; ++y_inner_outer_x_inner_outer_fused) {
      for (int32_t x_c_init = 0; x_c_init < 8; ++x_c_init) {
        ((int32_t*)compute_global_let)[x_c_init] = 0;
      }
      for (int32_t k_outer = 0; k_outer < 16; ++k_outer) {
        for (int32_t x_c = 0; x_c < 8; ++x_c) {
          ((int32_t*)compute_global_let)[x_c] = (((int32_t*)compute_global_let)[x_c] + (((int32_t)p0[k_outer]) * ((int32_t)((int8_t*)fused_constant_72_let)[((((ax1_outer_ax0_outer_fused * 512) + (y_inner_outer_x_inner_outer_fused * 128)) + (k_outer * 8)) + x_c)])));
        }
      }
      for (int32_t x_inner_inner = 0; x_inner_inner < 8; ++x_inner_inner) {
        ((int32_t*)compute_let)[((y_inner_outer_x_inner_outer_fused * 8) + x_inner_inner)] = ((int32_t*)compute_global_let)[x_inner_inner];
      }
    }
    for (int32_t ax1_inner_outer = 0; ax1_inner_outer < 4; ++ax1_inner_outer) {
      for (int32_t ax1_inner_inner = 0; ax1_inner_inner < 8; ++ax1_inner_inner) {
        int32_t cse_var_2 = (ax1_inner_outer * 8);
        int32_t cse_var_1 = (((ax1_outer_ax0_outer_fused * 32) + cse_var_2) + ax1_inner_inner);
        int32_t v_ = ((int32_t)(((((0 != 0) ? (((int64_t)((((int32_t*)compute_let)[(cse_var_2 + ax1_inner_inner)] + ((int32_t*)fused_nn_contrib_dense_pack_subtract_constant_7_let)[cse_var_1]) - ((int32_t*)fused_nn_contrib_dense_pack_constant_7_let)[cse_var_1])) << ((int64_t)0)) : ((int64_t)((((int32_t*)compute_let)[(cse_var_2 + ax1_inner_inner)] + ((int32_t*)fused_nn_contrib_dense_pack_subtract_constant_7_let)[cse_var_1]) - ((int32_t*)fused_nn_contrib_dense_pack_constant_7_let)[cse_var_1]))) * (int64_t)1773209777) + ((int64_t)1 << ((int64_t)((7 + 31) - 1)))) >> ((int64_t)(7 + 31)))) - 128;
        int32_t v__1 = (v_) < (127) ? (v_) : (127);
        T_cast[cse_var_1] = ((int8_t)((v__1) > (-128) ? (v__1) : (-128)));
      }
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_contrib_dense_pack_subtract_add_fixed_point_multiply_add_clip_cast_5(int8_t* p0, int8_t* T_cast, uint8_t* global_const_workspace_240_var, uint8_t* global_workspace_241_var) {
  void* fused_nn_contrib_dense_pack_constant_8_let = (&(global_const_workspace_240_var[770256]));
  void* fused_nn_contrib_dense_pack_subtract_constant_8_let = (&(global_const_workspace_240_var[769488]));
  void* fused_constant_73_let = (&(global_const_workspace_240_var[483552]));
  for (int32_t ax1_outer_ax0_outer_fused = 0; ax1_outer_ax0_outer_fused < 4; ++ax1_outer_ax0_outer_fused) {
    void* compute_let = (&(global_workspace_241_var[192]));
    void* compute_global_let = (&(global_workspace_241_var[256]));
    for (int32_t y_inner_outer_x_inner_outer_fused = 0; y_inner_outer_x_inner_outer_fused < 2; ++y_inner_outer_x_inner_outer_fused) {
      for (int32_t x_c_init = 0; x_c_init < 8; ++x_c_init) {
        ((int32_t*)compute_global_let)[x_c_init] = 0;
      }
      for (int32_t k_outer = 0; k_outer < 128; ++k_outer) {
        for (int32_t x_c = 0; x_c < 8; ++x_c) {
          ((int32_t*)compute_global_let)[x_c] = (((int32_t*)compute_global_let)[x_c] + (((int32_t)p0[k_outer]) * ((int32_t)((int8_t*)fused_constant_73_let)[((((ax1_outer_ax0_outer_fused * 2048) + (y_inner_outer_x_inner_outer_fused * 1024)) + (k_outer * 8)) + x_c)])));
        }
      }
      for (int32_t x_inner_inner = 0; x_inner_inner < 8; ++x_inner_inner) {
        ((int32_t*)compute_let)[((y_inner_outer_x_inner_outer_fused * 8) + x_inner_inner)] = ((int32_t*)compute_global_let)[x_inner_inner];
      }
    }
    for (int32_t ax1_inner_outer = 0; ax1_inner_outer < 2; ++ax1_inner_outer) {
      for (int32_t ax1_inner_inner = 0; ax1_inner_inner < 8; ++ax1_inner_inner) {
        int32_t cse_var_2 = (ax1_inner_outer * 8);
        int32_t cse_var_1 = (((ax1_outer_ax0_outer_fused * 16) + cse_var_2) + ax1_inner_inner);
        int32_t v_ = ((int32_t)(((((0 != 0) ? (((int64_t)((((int32_t*)compute_let)[(cse_var_2 + ax1_inner_inner)] + ((int32_t*)fused_nn_contrib_dense_pack_subtract_constant_8_let)[cse_var_1]) - ((int32_t*)fused_nn_contrib_dense_pack_constant_8_let)[cse_var_1])) << ((int64_t)0)) : ((int64_t)((((int32_t*)compute_let)[(cse_var_2 + ax1_inner_inner)] + ((int32_t*)fused_nn_contrib_dense_pack_subtract_constant_8_let)[cse_var_1]) - ((int32_t*)fused_nn_contrib_dense_pack_constant_8_let)[cse_var_1]))) * (int64_t)1890478069) + ((int64_t)1 << ((int64_t)((8 + 31) - 1)))) >> ((int64_t)(8 + 31)))) - 128;
        int32_t v__1 = (v_) < (127) ? (v_) : (127);
        T_cast[cse_var_1] = ((int8_t)((v__1) > (-128) ? (v__1) : (-128)));
      }
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_contrib_dense_pack_subtract_add_fixed_point_multiply_add_clip_subtract__fa059688879ad8de_(int8_t* p0, float* T_multiply, uint8_t* global_const_workspace_50_var, uint8_t* global_workspace_51_var) {
  void* fused_nn_contrib_dense_pack_constant_2_let = (&(global_const_workspace_50_var[783728]));
  void* fused_nn_contrib_dense_pack_subtract_constant_2_let = (&(global_const_workspace_50_var[783536]));
  void* fused_constant_16_let = (&(global_const_workspace_50_var[730528]));
  for (int32_t ax1_outer_ax0_outer_fused = 0; ax1_outer_ax0_outer_fused < 2; ++ax1_outer_ax0_outer_fused) {
    void* compute_global_let = (&(global_workspace_51_var[34632]));
    for (int32_t x_c_init = 0; x_c_init < 5; ++x_c_init) {
      ((int32_t*)compute_global_let)[x_c_init] = 0;
    }
    for (int32_t k_outer = 0; k_outer < 64; ++k_outer) {
      for (int32_t x_c = 0; x_c < 5; ++x_c) {
        ((int32_t*)compute_global_let)[x_c] = (((int32_t*)compute_global_let)[x_c] + (((int32_t)p0[k_outer]) * ((int32_t)((int8_t*)fused_constant_16_let)[(((ax1_outer_ax0_outer_fused * 320) + (k_outer * 5)) + x_c)])));
      }
    }
    for (int32_t ax1_inner_inner = 0; ax1_inner_inner < 5; ++ax1_inner_inner) {
      int32_t cse_var_1 = ((ax1_outer_ax0_outer_fused * 5) + ax1_inner_inner);
      int32_t v_ = ((int32_t)(((((0 != 0) ? (((int64_t)((((int32_t*)compute_global_let)[ax1_inner_inner] + ((int32_t*)fused_nn_contrib_dense_pack_subtract_constant_2_let)[cse_var_1]) - ((int32_t*)fused_nn_contrib_dense_pack_constant_2_let)[cse_var_1])) << ((int64_t)0)) : ((int64_t)((((int32_t*)compute_global_let)[ax1_inner_inner] + ((int32_t*)fused_nn_contrib_dense_pack_subtract_constant_2_let)[cse_var_1]) - ((int32_t*)fused_nn_contrib_dense_pack_constant_2_let)[cse_var_1]))) * (int64_t)1847482266) + ((int64_t)1 << ((int64_t)((9 + 31) - 1)))) >> ((int64_t)(9 + 31)))) - 4;
      int32_t v__1 = (v_) < (127) ? (v_) : (127);
      T_multiply[cse_var_1] = (((float)(((v__1) > (-128) ? (v__1) : (-128)) + 4)) * 9.133627e-02f);
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_contrib_dense_pack_subtract_add_fixed_point_multiply_add_clip_subtract__fa059688879ad8de__1(int8_t* p0, float* T_multiply, uint8_t* global_const_workspace_90_var, uint8_t* global_workspace_91_var) {
  void* fused_nn_contrib_dense_pack_constant_5_let = (&(global_const_workspace_90_var[783680]));
  void* fused_nn_contrib_dense_pack_subtract_constant_5_let = (&(global_const_workspace_90_var[783488]));
  void* fused_constant_28_let = (&(global_const_workspace_90_var[729888]));
  for (int32_t ax1_outer_ax0_outer_fused = 0; ax1_outer_ax0_outer_fused < 2; ++ax1_outer_ax0_outer_fused) {
    void* compute_global_let = (&(global_workspace_91_var[53480]));
    for (int32_t x_c_init = 0; x_c_init < 5; ++x_c_init) {
      ((int32_t*)compute_global_let)[x_c_init] = 0;
    }
    for (int32_t k_outer = 0; k_outer < 64; ++k_outer) {
      for (int32_t x_c = 0; x_c < 5; ++x_c) {
        ((int32_t*)compute_global_let)[x_c] = (((int32_t*)compute_global_let)[x_c] + (((int32_t)p0[k_outer]) * ((int32_t)((int8_t*)fused_constant_28_let)[(((ax1_outer_ax0_outer_fused * 320) + (k_outer * 5)) + x_c)])));
      }
    }
    for (int32_t ax1_inner_inner = 0; ax1_inner_inner < 5; ++ax1_inner_inner) {
      int32_t cse_var_1 = ((ax1_outer_ax0_outer_fused * 5) + ax1_inner_inner);
      int32_t v_ = ((int32_t)(((((0 != 0) ? (((int64_t)((((int32_t*)compute_global_let)[ax1_inner_inner] + ((int32_t*)fused_nn_contrib_dense_pack_subtract_constant_5_let)[cse_var_1]) - ((int32_t*)fused_nn_contrib_dense_pack_constant_5_let)[cse_var_1])) << ((int64_t)0)) : ((int64_t)((((int32_t*)compute_global_let)[ax1_inner_inner] + ((int32_t*)fused_nn_contrib_dense_pack_subtract_constant_5_let)[cse_var_1]) - ((int32_t*)fused_nn_contrib_dense_pack_constant_5_let)[cse_var_1]))) * (int64_t)1254011349) + ((int64_t)1 << ((int64_t)((8 + 31) - 1)))) >> ((int64_t)(8 + 31)))) - 16;
      int32_t v__1 = (v_) < (127) ? (v_) : (127);
      T_multiply[cse_var_1] = (((float)(((v__1) > (-128) ? (v__1) : (-128)) + 16)) * 1.266111e-01f);
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_contrib_dense_pack_subtract_add_fixed_point_multiply_add_clip_subtract__fa059688879ad8de__2(int8_t* p0, float* T_multiply, uint8_t* global_const_workspace_222_var, uint8_t* global_workspace_223_var) {
  void* fused_nn_contrib_dense_pack_constant_6_let = (&(global_const_workspace_222_var[783632]));
  void* fused_nn_contrib_dense_pack_subtract_constant_6_let = (&(global_const_workspace_222_var[783440]));
  void* fused_constant_68_let = (&(global_const_workspace_222_var[574032]));
  for (int32_t ax1_outer_ax0_outer_fused = 0; ax1_outer_ax0_outer_fused < 2; ++ax1_outer_ax0_outer_fused) {
    void* compute_global_let = (&(global_workspace_223_var[53208]));
    for (int32_t x_c_init = 0; x_c_init < 5; ++x_c_init) {
      ((int32_t*)compute_global_let)[x_c_init] = 0;
    }
    for (int32_t k_outer = 0; k_outer < 432; ++k_outer) {
      for (int32_t x_c = 0; x_c < 5; ++x_c) {
        ((int32_t*)compute_global_let)[x_c] = (((int32_t*)compute_global_let)[x_c] + (((int32_t)p0[k_outer]) * ((int32_t)((int8_t*)fused_constant_68_let)[(((ax1_outer_ax0_outer_fused * 2160) + (k_outer * 5)) + x_c)])));
      }
    }
    for (int32_t ax1_inner_inner = 0; ax1_inner_inner < 5; ++ax1_inner_inner) {
      int32_t cse_var_1 = ((ax1_outer_ax0_outer_fused * 5) + ax1_inner_inner);
      int32_t v_ = ((int32_t)(((((0 != 0) ? (((int64_t)((((int32_t*)compute_global_let)[ax1_inner_inner] + ((int32_t*)fused_nn_contrib_dense_pack_subtract_constant_6_let)[cse_var_1]) - ((int32_t*)fused_nn_contrib_dense_pack_constant_6_let)[cse_var_1])) << ((int64_t)0)) : ((int64_t)((((int32_t*)compute_global_let)[ax1_inner_inner] + ((int32_t*)fused_nn_contrib_dense_pack_subtract_constant_6_let)[cse_var_1]) - ((int32_t*)fused_nn_contrib_dense_pack_constant_6_let)[cse_var_1]))) * (int64_t)1496183668) + ((int64_t)1 << ((int64_t)((9 + 31) - 1)))) >> ((int64_t)(9 + 31)))) + 14;
      int32_t v__1 = (v_) < (127) ? (v_) : (127);
      T_multiply[cse_var_1] = (((float)(((v__1) > (-128) ? (v__1) : (-128)) - 14)) * 4.437626e-01f);
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_contrib_dense_pack_subtract_add_fixed_point_multiply_add_clip_subtract__fa059688879ad8de__3(int8_t* p0, float* T_multiply, uint8_t* global_const_workspace_242_var, uint8_t* global_workspace_243_var) {
  void* fused_nn_contrib_dense_pack_constant_9_let = (&(global_const_workspace_242_var[783584]));
  void* fused_nn_contrib_dense_pack_subtract_constant_9_let = (&(global_const_workspace_242_var[783392]));
  void* fused_constant_74_let = (&(global_const_workspace_242_var[729248]));
  for (int32_t ax1_outer_ax0_outer_fused = 0; ax1_outer_ax0_outer_fused < 2; ++ax1_outer_ax0_outer_fused) {
    void* compute_global_let = (&(global_workspace_243_var[232]));
    for (int32_t x_c_init = 0; x_c_init < 5; ++x_c_init) {
      ((int32_t*)compute_global_let)[x_c_init] = 0;
    }
    for (int32_t k_outer = 0; k_outer < 64; ++k_outer) {
      for (int32_t x_c = 0; x_c < 5; ++x_c) {
        ((int32_t*)compute_global_let)[x_c] = (((int32_t*)compute_global_let)[x_c] + (((int32_t)p0[k_outer]) * ((int32_t)((int8_t*)fused_constant_74_let)[(((ax1_outer_ax0_outer_fused * 320) + (k_outer * 5)) + x_c)])));
      }
    }
    for (int32_t ax1_inner_inner = 0; ax1_inner_inner < 5; ++ax1_inner_inner) {
      int32_t cse_var_1 = ((ax1_outer_ax0_outer_fused * 5) + ax1_inner_inner);
      int32_t v_ = ((int32_t)(((((0 != 0) ? (((int64_t)((((int32_t*)compute_global_let)[ax1_inner_inner] + ((int32_t*)fused_nn_contrib_dense_pack_subtract_constant_9_let)[cse_var_1]) - ((int32_t*)fused_nn_contrib_dense_pack_constant_9_let)[cse_var_1])) << ((int64_t)0)) : ((int64_t)((((int32_t*)compute_global_let)[ax1_inner_inner] + ((int32_t*)fused_nn_contrib_dense_pack_subtract_constant_9_let)[cse_var_1]) - ((int32_t*)fused_nn_contrib_dense_pack_constant_9_let)[cse_var_1]))) * (int64_t)1348507465) + ((int64_t)1 << ((int64_t)((8 + 31) - 1)))) >> ((int64_t)(8 + 31)))) - 20;
      int32_t v__1 = (v_) < (127) ? (v_) : (127);
      T_multiply[cse_var_1] = (((float)(((v__1) > (-128) ? (v__1) : (-128)) + 20)) * 1.371644e-01f);
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_add_fixed_point_multiply_per_axis_add_clip_cast(int8_t* p0, int8_t* T_cast, uint8_t* global_const_workspace_228_var, uint8_t* global_workspace_229_var) {
  void* fused_nn_conv2d_add_constant_8_let = (&(global_const_workspace_228_var[777632]));
  void* fused_nn_conv2d_add_constant_7_let = (&(global_const_workspace_228_var[777760]));
  void* fused_nn_conv2d_add_constant_6_let = (&(global_const_workspace_228_var[777888]));
  void* fused_nn_conv2d_constant_50_let = (&(global_const_workspace_228_var[776992]));
  void* fused_constant_69_let = (&(global_const_workspace_228_var[428256]));
  void* pad_temp_let = (&(global_workspace_229_var[0]));
  for (int32_t i0_i1_fused = 0; i0_i1_fused < 6; ++i0_i1_fused) {
    for (int32_t i2 = 0; i2 < 6; ++i2) {
      for (int32_t i3 = 0; i3 < 32; ++i3) {
        int32_t cse_var_1 = (((i0_i1_fused * 192) + (i2 * 32)) + i3);
        ((int8_t*)pad_temp_let)[cse_var_1] = p0[cse_var_1];
      }
    }
  }
  for (int32_t ax0_ax1_fused_ax2_fused = 0; ax0_ax1_fused_ax2_fused < 16; ++ax0_ax1_fused_ax2_fused) {
    void* conv2d_nhwc_let = (&(global_workspace_229_var[2816]));
    for (int32_t ax3 = 0; ax3 < 32; ++ax3) {
      ((int32_t*)conv2d_nhwc_let)[0] = 0;
      for (int32_t ry = 0; ry < 3; ++ry) {
        for (int32_t rx = 0; rx < 3; ++rx) {
          for (int32_t rc = 0; rc < 32; ++rc) {
            ((int32_t*)conv2d_nhwc_let)[0] = (((int32_t*)conv2d_nhwc_let)[0] + (((int32_t)((int8_t*)pad_temp_let)[((((((ax0_ax1_fused_ax2_fused >> 2) * 192) + (ry * 192)) + (rx * 32)) + ((ax0_ax1_fused_ax2_fused & 3) * 32)) + rc)]) * ((int32_t)((int8_t*)fused_constant_69_let)[((((ry * 3072) + (rx * 1024)) + (rc * 32)) + ax3)])));
          }
        }
      }
      int32_t v_ = ((int32_t)(((((int64_t)(((int32_t*)conv2d_nhwc_let)[0] + ((int32_t*)fused_nn_conv2d_constant_50_let)[ax3])) * ((int64_t)((int32_t*)fused_nn_conv2d_add_constant_6_let)[ax3])) + ((int64_t)1 << ((int64_t)((((int32_t*)fused_nn_conv2d_add_constant_8_let)[ax3] + 31) - 1)))) >> ((int64_t)(((int32_t*)fused_nn_conv2d_add_constant_8_let)[ax3] + 31)))) - 128;
      int32_t v__1 = (v_) < (127) ? (v_) : (127);
      T_cast[((ax0_ax1_fused_ax2_fused * 32) + ax3)] = ((int8_t)((v__1) > (-128) ? (v__1) : (-128)));
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_add_fixed_point_multiply_per_axis_add_clip_subtract_cast_multipl_a0b6f984222e477_(int8_t* p0, int8_t* T_cast, uint8_t* global_const_workspace_112_var, uint8_t* global_workspace_113_var) {
  void* fused_nn_conv2d_add_constant_2_let = (&(global_const_workspace_112_var[726288]));
  void* fused_nn_conv2d_add_constant_1_let = (&(global_const_workspace_112_var[727056]));
  void* fused_nn_conv2d_add_constant_let = (&(global_const_workspace_112_var[727824]));
  void* fused_nn_conv2d_constant_23_let = (&(global_const_workspace_112_var[723216]));
  void* fused_constant_34_let = (&(global_const_workspace_112_var[515040]));
  void* pad_temp_let = (&(global_workspace_113_var[52736]));
  for (int32_t i0_i1_fused = 0; i0_i1_fused < 4; ++i0_i1_fused) {
    for (int32_t i2 = 0; i2 < 4; ++i2) {
      for (int32_t i3 = 0; i3 < 32; ++i3) {
        int32_t cse_var_1 = (((i0_i1_fused * 128) + (i2 * 32)) + i3);
        ((int8_t*)pad_temp_let)[cse_var_1] = p0[cse_var_1];
      }
    }
  }
  for (int32_t ax0_ax1_fused_ax2_fused = 0; ax0_ax1_fused_ax2_fused < 16; ++ax0_ax1_fused_ax2_fused) {
    void* conv2d_nhwc_let = (&(global_workspace_113_var[53248]));
    for (int32_t ax3_outer = 0; ax3_outer < 3; ++ax3_outer) {
      for (int32_t ff = 0; ff < 64; ++ff) {
        ((int32_t*)conv2d_nhwc_let)[ff] = 0;
        for (int32_t rc = 0; rc < 32; ++rc) {
          ((int32_t*)conv2d_nhwc_let)[ff] = (((int32_t*)conv2d_nhwc_let)[ff] + (((int32_t)((int8_t*)pad_temp_let)[((ax0_ax1_fused_ax2_fused * 32) + rc)]) * ((int32_t)((int8_t*)fused_constant_34_let)[(((rc * 192) + (ax3_outer * 64)) + ff)])));
        }
      }
      for (int32_t ax3_inner = 0; ax3_inner < 64; ++ax3_inner) {
        int32_t cse_var_3 = (ax3_outer * 64);
        int32_t cse_var_2 = (cse_var_3 + ax3_inner);
        int32_t v_ = ((int32_t)(((((int64_t)(((int32_t*)conv2d_nhwc_let)[ax3_inner] + ((int32_t*)fused_nn_conv2d_constant_23_let)[cse_var_2])) * ((int64_t)((int32_t*)fused_nn_conv2d_add_constant_let)[cse_var_2])) + ((int64_t)1 << ((int64_t)((((int32_t*)fused_nn_conv2d_add_constant_2_let)[cse_var_2] + 31) - 1)))) >> ((int64_t)(((int32_t*)fused_nn_conv2d_add_constant_2_let)[cse_var_2] + 31)))) + 23;
        int32_t v__1 = (v_) < (127) ? (v_) : (127);
        float v__2 = (((float)(((v__1) > (-128) ? (v__1) : (-128)) - 23)) * 1.537299e-01f) + 3.000000e+00f;
        float v__3 = (v__2) < (6.000000e+00f) ? (v__2) : (6.000000e+00f);
        float v__4 = roundf(((((((float)(((v__1) > (-128) ? (v__1) : (-128)) - 23)) * 1.537299e-01f) * ((v__3) > (0.000000e+00f) ? (v__3) : (0.000000e+00f))) * 1.666667e-01f) * 1.560734e+01f)) + -1.220000e+02f;
        float v__5 = (v__4) < (1.270000e+02f) ? (v__4) : (1.270000e+02f);
        T_cast[(((ax0_ax1_fused_ax2_fused * 192) + cse_var_3) + ax3_inner)] = ((int8_t)((v__5) > (-1.280000e+02f) ? (v__5) : (-1.280000e+02f)));
      }
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_add_fixed_point_multiply_per_axis_add_clip_subtract_multiply_fix_52d6a4719dd81c1d_(int8_t* p0, int32_t* T_subtract, uint8_t* global_const_workspace_140_var, uint8_t* global_workspace_141_var) {
  void* fused_nn_conv2d_add_constant_5_let = (&(global_const_workspace_140_var[756336]));
  void* fused_nn_conv2d_add_constant_4_let = (&(global_const_workspace_140_var[756720]));
  void* fused_nn_conv2d_add_constant_3_let = (&(global_const_workspace_140_var[757104]));
  void* fused_nn_conv2d_constant_30_let = (&(global_const_workspace_140_var[754032]));
  void* fused_constant_43_let = (&(global_const_workspace_140_var[607920]));
  void* pad_temp_let = (&(global_workspace_141_var[53120]));
  void* conv2d_nhwc_let = (&(global_workspace_141_var[53144]));
  for (int32_t i3 = 0; i3 < 24; ++i3) {
    ((int8_t*)pad_temp_let)[i3] = p0[i3];
  }
  for (int32_t ax3 = 0; ax3 < 96; ++ax3) {
    ((int32_t*)conv2d_nhwc_let)[0] = 0;
    for (int32_t rc = 0; rc < 24; ++rc) {
      ((int32_t*)conv2d_nhwc_let)[0] = (((int32_t*)conv2d_nhwc_let)[0] + (((int32_t)((int8_t*)pad_temp_let)[rc]) * ((int32_t)((int8_t*)fused_constant_43_let)[((rc * 96) + ax3)])));
    }
    int32_t v_ = ((int32_t)(((((int64_t)(((int32_t*)conv2d_nhwc_let)[0] + ((int32_t*)fused_nn_conv2d_constant_30_let)[ax3])) * ((int64_t)((int32_t*)fused_nn_conv2d_add_constant_3_let)[ax3])) + ((int64_t)1 << ((int64_t)((((int32_t*)fused_nn_conv2d_add_constant_5_let)[ax3] + 31) - 1)))) >> ((int64_t)(((int32_t*)fused_nn_conv2d_add_constant_5_let)[ax3] + 31)))) - 128;
    int32_t v__1 = (v_) < (127) ? (v_) : (127);
    int32_t v__2 = ((int32_t)(((((int64_t)(((int32_t*)conv2d_nhwc_let)[0] + ((int32_t*)fused_nn_conv2d_constant_30_let)[ax3])) * ((int64_t)((int32_t*)fused_nn_conv2d_add_constant_3_let)[ax3])) + ((int64_t)1 << ((int64_t)((((int32_t*)fused_nn_conv2d_add_constant_5_let)[ax3] + 31) - 1)))) >> ((int64_t)(((int32_t*)fused_nn_conv2d_add_constant_5_let)[ax3] + 31)))) - 128;
    int32_t v__3 = (v__2) < (127) ? (v__2) : (127);
    int32_t v__4 = ((int32_t)(((((0 != 0) ? (((int64_t)((((v__1) > (-128) ? (v__1) : (-128)) * 255) + 32640)) << ((int64_t)0)) : ((int64_t)((((v__3) > (-128) ? (v__3) : (-128)) * 255) + 32640))) * (int64_t)1077952511) + ((int64_t)1 << ((int64_t)((7 + 31) - 1)))) >> ((int64_t)(7 + 31)))) - 128;
    int32_t v__5 = (v__4) < (127) ? (v__4) : (127);
    T_subtract[ax3] = (((v__5) > (-128) ? (v__5) : (-128)) + 128);
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip(int8_t* p0, int32_t* compute, uint8_t* global_const_workspace_8_var, uint8_t* global_workspace_9_var) {
  void* fused_nn_conv2d_subtract_add_constant_5_let = (&(global_const_workspace_8_var[782112]));
  void* fused_nn_conv2d_subtract_add_constant_4_let = (&(global_const_workspace_8_var[782176]));
  void* fused_nn_conv2d_subtract_add_constant_3_let = (&(global_const_workspace_8_var[782240]));
  void* fused_nn_conv2d_subtract_constant_1_let = (&(global_const_workspace_8_var[781728]));
  void* fused_nn_conv2d_constant_1_let = (&(global_const_workspace_8_var[783264]));
  void* fused_constant_1_let = (&(global_const_workspace_8_var[774800]));
  void* PaddedInput_let = (&(global_workspace_9_var[17424]));
  void* DepthwiseConv2d_let = (&(global_workspace_9_var[34848]));
  for (int32_t i1 = 0; i1 < 33; ++i1) {
    for (int32_t i2 = 0; i2 < 33; ++i2) {
      for (int32_t i3 = 0; i3 < 16; ++i3) {
        int32_t cse_var_1 = (((i1 * 528) + (i2 * 16)) + i3);
        ((int8_t*)PaddedInput_let)[cse_var_1] = p0[cse_var_1];
      }
    }
  }
  for (int32_t i = 0; i < 16; ++i) {
    for (int32_t j = 0; j < 16; ++j) {
      for (int32_t c = 0; c < 16; ++c) {
        ((int32_t*)DepthwiseConv2d_let)[(((i * 256) + (j * 16)) + c)] = 0;
        for (int32_t di = 0; di < 3; ++di) {
          for (int32_t dj = 0; dj < 3; ++dj) {
            int32_t cse_var_3 = (dj * 16);
            int32_t cse_var_2 = (((i * 256) + (j * 16)) + c);
            ((int32_t*)DepthwiseConv2d_let)[cse_var_2] = (((int32_t*)DepthwiseConv2d_let)[cse_var_2] + (((int32_t)((int8_t*)PaddedInput_let)[(((((i * 1056) + (di * 528)) + (j * 32)) + cse_var_3) + c)]) * ((int32_t)((int8_t*)fused_constant_1_let)[(((di * 48) + cse_var_3) + c)])));
          }
        }
      }
    }
  }
  for (int32_t ax1 = 0; ax1 < 16; ++ax1) {
    for (int32_t ax2 = 0; ax2 < 16; ++ax2) {
      for (int32_t ax3 = 0; ax3 < 16; ++ax3) {
        int32_t cse_var_4 = (((ax1 * 256) + (ax2 * 16)) + ax3);
        ((int32_t*)DepthwiseConv2d_let)[cse_var_4] = (((int32_t*)DepthwiseConv2d_let)[cse_var_4] - ((int32_t*)fused_nn_conv2d_constant_1_let)[ax3]);
      }
    }
  }
  for (int32_t ax1_1 = 0; ax1_1 < 16; ++ax1_1) {
    for (int32_t ax2_1 = 0; ax2_1 < 16; ++ax2_1) {
      for (int32_t ax3_1 = 0; ax3_1 < 16; ++ax3_1) {
        int32_t cse_var_5 = (((ax1_1 * 256) + (ax2_1 * 16)) + ax3_1);
        ((int32_t*)DepthwiseConv2d_let)[cse_var_5] = (((int32_t*)DepthwiseConv2d_let)[cse_var_5] + ((int32_t*)fused_nn_conv2d_subtract_constant_1_let)[ax3_1]);
      }
    }
  }
  for (int32_t i1_1 = 0; i1_1 < 16; ++i1_1) {
    for (int32_t i2_1 = 0; i2_1 < 16; ++i2_1) {
      for (int32_t i3_1 = 0; i3_1 < 16; ++i3_1) {
        int32_t cse_var_6 = (((i1_1 * 256) + (i2_1 * 16)) + i3_1);
        ((int32_t*)DepthwiseConv2d_let)[cse_var_6] = ((int32_t)(((((int64_t)((int32_t*)DepthwiseConv2d_let)[cse_var_6]) * ((int64_t)((int32_t*)fused_nn_conv2d_subtract_add_constant_3_let)[i3_1])) + ((int64_t)1 << ((int64_t)((((int32_t*)fused_nn_conv2d_subtract_add_constant_5_let)[i3_1] + 31) - 1)))) >> ((int64_t)(((int32_t*)fused_nn_conv2d_subtract_add_constant_5_let)[i3_1] + 31))));
      }
    }
  }
  for (int32_t ax1_2 = 0; ax1_2 < 16; ++ax1_2) {
    for (int32_t ax2_2 = 0; ax2_2 < 16; ++ax2_2) {
      for (int32_t ax3_2 = 0; ax3_2 < 16; ++ax3_2) {
        int32_t cse_var_7 = (((ax1_2 * 256) + (ax2_2 * 16)) + ax3_2);
        ((int32_t*)DepthwiseConv2d_let)[cse_var_7] = (((int32_t*)DepthwiseConv2d_let)[cse_var_7] - 128);
      }
    }
  }
  for (int32_t i1_2 = 0; i1_2 < 16; ++i1_2) {
    for (int32_t i2_2 = 0; i2_2 < 16; ++i2_2) {
      for (int32_t i3_2 = 0; i3_2 < 16; ++i3_2) {
        int32_t cse_var_8 = (((i1_2 * 256) + (i2_2 * 16)) + i3_2);
        int32_t v_ = ((int32_t*)DepthwiseConv2d_let)[cse_var_8];
        int32_t v__1 = (v_) < (127) ? (v_) : (127);
        compute[cse_var_8] = ((v__1) > (-128) ? (v__1) : (-128));
      }
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_1(int8_t* p0, int32_t* compute, uint8_t* global_const_workspace_40_var, uint8_t* global_workspace_41_var) {
  void* fused_nn_conv2d_subtract_add_constant_35_let = (&(global_const_workspace_40_var[776608]));
  void* fused_nn_conv2d_subtract_add_constant_34_let = (&(global_const_workspace_40_var[776736]));
  void* fused_nn_conv2d_subtract_add_constant_33_let = (&(global_const_workspace_40_var[776864]));
  void* fused_nn_conv2d_constant_11_let = (&(global_const_workspace_40_var[777504]));
  void* fused_nn_conv2d_subtract_constant_11_let = (&(global_const_workspace_40_var[775328]));
  void* fused_constant_12_let = (&(global_const_workspace_40_var[508128]));
  void* pad_temp_let = (&(global_workspace_41_var[8192]));
  for (int32_t i0_i1_fused = 0; i0_i1_fused < 10; ++i0_i1_fused) {
    for (int32_t i2 = 0; i2 < 10; ++i2) {
      for (int32_t i3 = 0; i3 < 24; ++i3) {
        int32_t cse_var_1 = (((i0_i1_fused * 240) + (i2 * 24)) + i3);
        ((int8_t*)pad_temp_let)[cse_var_1] = p0[cse_var_1];
      }
    }
  }
  for (int32_t i0_i1_fused_i2_fused = 0; i0_i1_fused_i2_fused < 64; ++i0_i1_fused_i2_fused) {
    void* conv2d_nhwc_let = (&(global_workspace_41_var[34400]));
    for (int32_t i3_1 = 0; i3_1 < 32; ++i3_1) {
      ((int32_t*)conv2d_nhwc_let)[0] = 0;
      for (int32_t ry = 0; ry < 3; ++ry) {
        for (int32_t rx = 0; rx < 3; ++rx) {
          for (int32_t rc = 0; rc < 24; ++rc) {
            ((int32_t*)conv2d_nhwc_let)[0] = (((int32_t*)conv2d_nhwc_let)[0] + (((int32_t)((int8_t*)pad_temp_let)[((((((i0_i1_fused_i2_fused >> 3) * 240) + (ry * 240)) + (rx * 24)) + ((i0_i1_fused_i2_fused & 7) * 24)) + rc)]) * ((int32_t)((int8_t*)fused_constant_12_let)[((((ry * 2304) + (rx * 768)) + (rc * 32)) + i3_1)])));
          }
        }
      }
      int32_t v_ = ((int32_t)(((((int64_t)((((int32_t*)conv2d_nhwc_let)[0] + ((int32_t*)fused_nn_conv2d_subtract_constant_11_let)[i3_1]) - ((int32_t*)fused_nn_conv2d_constant_11_let)[i3_1])) * ((int64_t)((int32_t*)fused_nn_conv2d_subtract_add_constant_33_let)[i3_1])) + ((int64_t)1 << ((int64_t)((((int32_t*)fused_nn_conv2d_subtract_add_constant_35_let)[i3_1] + 31) - 1)))) >> ((int64_t)(((int32_t*)fused_nn_conv2d_subtract_add_constant_35_let)[i3_1] + 31)))) - 128;
      int32_t v__1 = (v_) < (127) ? (v_) : (127);
      compute[((i0_i1_fused_i2_fused * 32) + i3_1)] = ((v__1) > (-128) ? (v__1) : (-128));
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_2(int8_t* p0, int32_t* compute, uint8_t* global_const_workspace_80_var, uint8_t* global_workspace_81_var) {
  void* fused_nn_conv2d_subtract_add_constant_56_let = (&(global_const_workspace_80_var[781920]));
  void* fused_nn_conv2d_subtract_add_constant_55_let = (&(global_const_workspace_80_var[781984]));
  void* fused_nn_conv2d_subtract_add_constant_54_let = (&(global_const_workspace_80_var[782048]));
  void* fused_nn_conv2d_constant_18_let = (&(global_const_workspace_80_var[783200]));
  void* fused_nn_conv2d_subtract_constant_18_let = (&(global_const_workspace_80_var[781664]));
  void* fused_constant_24_let = (&(global_const_workspace_80_var[569424]));
  void* pad_temp_let = (&(global_workspace_81_var[0]));
  for (int32_t i0_i1_fused = 0; i0_i1_fused < 6; ++i0_i1_fused) {
    for (int32_t i2 = 0; i2 < 6; ++i2) {
      for (int32_t i3 = 0; i3 < 32; ++i3) {
        int32_t cse_var_1 = (((i0_i1_fused * 192) + (i2 * 32)) + i3);
        ((int8_t*)pad_temp_let)[cse_var_1] = p0[cse_var_1];
      }
    }
  }
  for (int32_t i0_i1_fused_i2_fused = 0; i0_i1_fused_i2_fused < 16; ++i0_i1_fused_i2_fused) {
    void* conv2d_nhwc_let = (&(global_workspace_81_var[53248]));
    for (int32_t i3_1 = 0; i3_1 < 16; ++i3_1) {
      ((int32_t*)conv2d_nhwc_let)[0] = 0;
      for (int32_t ry = 0; ry < 3; ++ry) {
        for (int32_t rx = 0; rx < 3; ++rx) {
          for (int32_t rc = 0; rc < 32; ++rc) {
            ((int32_t*)conv2d_nhwc_let)[0] = (((int32_t*)conv2d_nhwc_let)[0] + (((int32_t)((int8_t*)pad_temp_let)[((((((i0_i1_fused_i2_fused >> 2) * 192) + (ry * 192)) + (rx * 32)) + ((i0_i1_fused_i2_fused & 3) * 32)) + rc)]) * ((int32_t)((int8_t*)fused_constant_24_let)[((((ry * 1536) + (rx * 512)) + (rc * 16)) + i3_1)])));
          }
        }
      }
      int32_t v_ = ((int32_t)(((((int64_t)((((int32_t*)conv2d_nhwc_let)[0] + ((int32_t*)fused_nn_conv2d_subtract_constant_18_let)[i3_1]) - ((int32_t*)fused_nn_conv2d_constant_18_let)[i3_1])) * ((int64_t)((int32_t*)fused_nn_conv2d_subtract_add_constant_54_let)[i3_1])) + ((int64_t)1 << ((int64_t)((((int32_t*)fused_nn_conv2d_subtract_add_constant_56_let)[i3_1] + 31) - 1)))) >> ((int64_t)(((int32_t*)fused_nn_conv2d_subtract_add_constant_56_let)[i3_1] + 31)))) - 128;
      int32_t v__1 = (v_) < (127) ? (v_) : (127);
      compute[((i0_i1_fused_i2_fused * 16) + i3_1)] = ((v__1) > (-128) ? (v__1) : (-128));
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_3(int8_t* p0, int32_t* compute, uint8_t* global_const_workspace_232_var, uint8_t* global_workspace_233_var) {
  void* fused_nn_conv2d_subtract_add_constant_146_let = (&(global_const_workspace_232_var[782368]));
  void* fused_nn_conv2d_subtract_add_constant_145_let = (&(global_const_workspace_232_var[782432]));
  void* fused_nn_conv2d_subtract_add_constant_144_let = (&(global_const_workspace_232_var[782496]));
  void* fused_nn_conv2d_constant_51_let = (&(global_const_workspace_232_var[783008]));
  void* fused_nn_conv2d_subtract_constant_48_let = (&(global_const_workspace_232_var[781472]));
  void* fused_constant_70_let = (&(global_const_workspace_232_var[564816]));
  void* pad_temp_let = (&(global_workspace_233_var[0]));
  for (int32_t i0_i1_fused = 0; i0_i1_fused < 6; ++i0_i1_fused) {
    for (int32_t i2 = 0; i2 < 6; ++i2) {
      for (int32_t i3 = 0; i3 < 32; ++i3) {
        int32_t cse_var_1 = (((i0_i1_fused * 192) + (i2 * 32)) + i3);
        ((int8_t*)pad_temp_let)[cse_var_1] = p0[cse_var_1];
      }
    }
  }
  for (int32_t i0_i1_fused_i2_fused = 0; i0_i1_fused_i2_fused < 16; ++i0_i1_fused_i2_fused) {
    void* conv2d_nhwc_let = (&(global_workspace_233_var[2176]));
    for (int32_t i3_1 = 0; i3_1 < 16; ++i3_1) {
      ((int32_t*)conv2d_nhwc_let)[0] = 0;
      for (int32_t ry = 0; ry < 3; ++ry) {
        for (int32_t rx = 0; rx < 3; ++rx) {
          for (int32_t rc = 0; rc < 32; ++rc) {
            ((int32_t*)conv2d_nhwc_let)[0] = (((int32_t*)conv2d_nhwc_let)[0] + (((int32_t)((int8_t*)pad_temp_let)[((((((i0_i1_fused_i2_fused >> 2) * 192) + (ry * 192)) + (rx * 32)) + ((i0_i1_fused_i2_fused & 3) * 32)) + rc)]) * ((int32_t)((int8_t*)fused_constant_70_let)[((((ry * 1536) + (rx * 512)) + (rc * 16)) + i3_1)])));
          }
        }
      }
      int32_t v_ = ((int32_t)(((((int64_t)((((int32_t*)conv2d_nhwc_let)[0] + ((int32_t*)fused_nn_conv2d_subtract_constant_48_let)[i3_1]) - ((int32_t*)fused_nn_conv2d_constant_51_let)[i3_1])) * ((int64_t)((int32_t*)fused_nn_conv2d_subtract_add_constant_144_let)[i3_1])) + ((int64_t)1 << ((int64_t)((((int32_t*)fused_nn_conv2d_subtract_add_constant_146_let)[i3_1] + 31) - 1)))) >> ((int64_t)(((int32_t*)fused_nn_conv2d_subtract_add_constant_146_let)[i3_1] + 31)))) - 128;
      int32_t v__1 = (v_) < (127) ? (v_) : (127);
      compute[((i0_i1_fused_i2_fused * 16) + i3_1)] = ((v__1) > (-128) ? (v__1) : (-128));
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_cast(int8_t* p0, int8_t* T_cast, uint8_t* global_const_workspace_14_var, uint8_t* global_workspace_15_var) {
  void* fused_nn_conv2d_subtract_add_constant_8_let = (&(global_const_workspace_14_var[783808]));
  void* fused_nn_conv2d_subtract_add_constant_7_let = (&(global_const_workspace_14_var[783840]));
  void* fused_nn_conv2d_subtract_add_constant_6_let = (&(global_const_workspace_14_var[783872]));
  void* fused_nn_conv2d_constant_2_let = (&(global_const_workspace_14_var[783904]));
  void* fused_nn_conv2d_subtract_constant_2_let = (&(global_const_workspace_14_var[783776]));
  void* fused_constant_3_let = (&(global_const_workspace_14_var[778144]));
  void* pad_temp_let = (&(global_workspace_15_var[16384]));
  void* conv2d_nhwc_let = (&(global_workspace_15_var[16408]));
  for (int32_t i3 = 0; i3 < 16; ++i3) {
    ((int8_t*)pad_temp_let)[i3] = p0[i3];
  }
  for (int32_t ax3 = 0; ax3 < 8; ++ax3) {
    ((int32_t*)conv2d_nhwc_let)[0] = 0;
    for (int32_t rc = 0; rc < 16; ++rc) {
      ((int32_t*)conv2d_nhwc_let)[0] = (((int32_t*)conv2d_nhwc_let)[0] + (((int32_t)((int8_t*)pad_temp_let)[rc]) * ((int32_t)((int8_t*)fused_constant_3_let)[((rc * 8) + ax3)])));
    }
    int32_t v_ = ((int32_t)(((((int64_t)((((int32_t*)conv2d_nhwc_let)[0] + ((int32_t*)fused_nn_conv2d_subtract_constant_2_let)[ax3]) - ((int32_t*)fused_nn_conv2d_constant_2_let)[ax3])) * ((int64_t)((int32_t*)fused_nn_conv2d_subtract_add_constant_6_let)[ax3])) + ((int64_t)1 << ((int64_t)((((int32_t*)fused_nn_conv2d_subtract_add_constant_8_let)[ax3] + 31) - 1)))) >> ((int64_t)(((int32_t*)fused_nn_conv2d_subtract_add_constant_8_let)[ax3] + 31)))) - 128;
    int32_t v__1 = (v_) < (127) ? (v_) : (127);
    T_cast[ax3] = ((int8_t)((v__1) > (-128) ? (v__1) : (-128)));
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_cast_1(int8_t* p0, int8_t* T_cast, uint8_t* global_const_workspace_20_var, uint8_t* global_workspace_21_var) {
  void* fused_nn_conv2d_subtract_add_constant_14_let = (&(global_const_workspace_20_var[782560]));
  void* fused_nn_conv2d_subtract_add_constant_13_let = (&(global_const_workspace_20_var[782624]));
  void* fused_nn_conv2d_subtract_add_constant_12_let = (&(global_const_workspace_20_var[782688]));
  void* fused_nn_conv2d_constant_4_let = (&(global_const_workspace_20_var[783072]));
  void* fused_nn_conv2d_subtract_constant_4_let = (&(global_const_workspace_20_var[781536]));
  void* fused_constant_5_let = (&(global_const_workspace_20_var[771024]));
  void* pad_temp_let = (&(global_workspace_21_var[20480]));
  for (int32_t i0_i1_fused = 0; i0_i1_fused < 16; ++i0_i1_fused) {
    for (int32_t i2 = 0; i2 < 16; ++i2) {
      for (int32_t i3 = 0; i3 < 16; ++i3) {
        int32_t cse_var_1 = (((i0_i1_fused * 256) + (i2 * 16)) + i3);
        ((int8_t*)pad_temp_let)[cse_var_1] = p0[cse_var_1];
      }
    }
  }
  for (int32_t ax0_ax1_fused_ax2_fused = 0; ax0_ax1_fused_ax2_fused < 256; ++ax0_ax1_fused_ax2_fused) {
    void* conv2d_nhwc_let = (&(global_workspace_21_var[24576]));
    for (int32_t ax3 = 0; ax3 < 16; ++ax3) {
      ((int32_t*)conv2d_nhwc_let)[0] = 0;
      for (int32_t rc = 0; rc < 16; ++rc) {
        ((int32_t*)conv2d_nhwc_let)[0] = (((int32_t*)conv2d_nhwc_let)[0] + (((int32_t)((int8_t*)pad_temp_let)[((ax0_ax1_fused_ax2_fused * 16) + rc)]) * ((int32_t)((int8_t*)fused_constant_5_let)[((rc * 16) + ax3)])));
      }
      int32_t v_ = ((int32_t)(((((int64_t)((((int32_t*)conv2d_nhwc_let)[0] + ((int32_t*)fused_nn_conv2d_subtract_constant_4_let)[ax3]) - ((int32_t*)fused_nn_conv2d_constant_4_let)[ax3])) * ((int64_t)((int32_t*)fused_nn_conv2d_subtract_add_constant_12_let)[ax3])) + ((int64_t)1 << ((int64_t)((((int32_t*)fused_nn_conv2d_subtract_add_constant_14_let)[ax3] + 31) - 1)))) >> ((int64_t)(((int32_t*)fused_nn_conv2d_subtract_add_constant_14_let)[ax3] + 31)))) - 7;
      int32_t v__1 = (v_) < (127) ? (v_) : (127);
      T_cast[((ax0_ax1_fused_ax2_fused * 16) + ax3)] = ((int8_t)((v__1) > (-128) ? (v__1) : (-128)));
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_cast_10(int8_t* p0, int8_t* T_cast, uint8_t* global_const_workspace_76_var, uint8_t* global_workspace_77_var) {
  void* fused_nn_conv2d_subtract_add_constant_53_let = (&(global_const_workspace_76_var[775840]));
  void* fused_nn_conv2d_subtract_add_constant_52_let = (&(global_const_workspace_76_var[775968]));
  void* fused_nn_conv2d_subtract_add_constant_51_let = (&(global_const_workspace_76_var[776096]));
  void* fused_nn_conv2d_constant_17_let = (&(global_const_workspace_76_var[777248]));
  void* fused_nn_conv2d_subtract_constant_17_let = (&(global_const_workspace_76_var[775072]));
  void* fused_constant_23_let = (&(global_const_workspace_76_var[474336]));
  void* pad_temp_let = (&(global_workspace_77_var[0]));
  for (int32_t i0_i1_fused = 0; i0_i1_fused < 6; ++i0_i1_fused) {
    for (int32_t i2 = 0; i2 < 6; ++i2) {
      for (int32_t i3 = 0; i3 < 32; ++i3) {
        int32_t cse_var_1 = (((i0_i1_fused * 192) + (i2 * 32)) + i3);
        ((int8_t*)pad_temp_let)[cse_var_1] = p0[cse_var_1];
      }
    }
  }
  for (int32_t ax0_ax1_fused_ax2_fused = 0; ax0_ax1_fused_ax2_fused < 16; ++ax0_ax1_fused_ax2_fused) {
    void* conv2d_nhwc_let = (&(global_workspace_77_var[53760]));
    for (int32_t ax3 = 0; ax3 < 32; ++ax3) {
      ((int32_t*)conv2d_nhwc_let)[0] = 0;
      for (int32_t ry = 0; ry < 3; ++ry) {
        for (int32_t rx = 0; rx < 3; ++rx) {
          for (int32_t rc = 0; rc < 32; ++rc) {
            ((int32_t*)conv2d_nhwc_let)[0] = (((int32_t*)conv2d_nhwc_let)[0] + (((int32_t)((int8_t*)pad_temp_let)[((((((ax0_ax1_fused_ax2_fused >> 2) * 192) + (ry * 192)) + (rx * 32)) + ((ax0_ax1_fused_ax2_fused & 3) * 32)) + rc)]) * ((int32_t)((int8_t*)fused_constant_23_let)[((((ry * 3072) + (rx * 1024)) + (rc * 32)) + ax3)])));
          }
        }
      }
      int32_t v_ = ((int32_t)(((((int64_t)((((int32_t*)conv2d_nhwc_let)[0] + ((int32_t*)fused_nn_conv2d_subtract_constant_17_let)[ax3]) - ((int32_t*)fused_nn_conv2d_constant_17_let)[ax3])) * ((int64_t)((int32_t*)fused_nn_conv2d_subtract_add_constant_51_let)[ax3])) + ((int64_t)1 << ((int64_t)((((int32_t*)fused_nn_conv2d_subtract_add_constant_53_let)[ax3] + 31) - 1)))) >> ((int64_t)(((int32_t*)fused_nn_conv2d_subtract_add_constant_53_let)[ax3] + 31)))) - 128;
      int32_t v__1 = (v_) < (127) ? (v_) : (127);
      T_cast[((ax0_ax1_fused_ax2_fused * 32) + ax3)] = ((int8_t)((v__1) > (-128) ? (v__1) : (-128)));
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_cast_11(int8_t* p0, int8_t* T_cast, uint8_t* global_const_workspace_104_var, uint8_t* global_workspace_105_var) {
  void* fused_nn_conv2d_subtract_add_constant_65_let = (&(global_const_workspace_104_var[772240]));
  void* fused_nn_conv2d_subtract_add_constant_64_let = (&(global_const_workspace_104_var[772432]));
  void* fused_nn_conv2d_subtract_add_constant_63_let = (&(global_const_workspace_104_var[772624]));
  void* fused_nn_conv2d_constant_21_let = (&(global_const_workspace_104_var[773008]));
  void* fused_nn_conv2d_subtract_constant_21_let = (&(global_const_workspace_104_var[771472]));
  void* fused_constant_32_let = (&(global_const_workspace_104_var[465120]));
  void* pad_temp_let = (&(global_workspace_105_var[53248]));
  void* conv2d_nhwc_let = (&(global_workspace_105_var[53488]));
  for (int32_t i3 = 0; i3 < 192; ++i3) {
    ((int8_t*)pad_temp_let)[i3] = p0[i3];
  }
  for (int32_t ax3 = 0; ax3 < 48; ++ax3) {
    ((int32_t*)conv2d_nhwc_let)[0] = 0;
    for (int32_t rc = 0; rc < 192; ++rc) {
      ((int32_t*)conv2d_nhwc_let)[0] = (((int32_t*)conv2d_nhwc_let)[0] + (((int32_t)((int8_t*)pad_temp_let)[rc]) * ((int32_t)((int8_t*)fused_constant_32_let)[((rc * 48) + ax3)])));
    }
    int32_t v_ = ((int32_t)(((((int64_t)((((int32_t*)conv2d_nhwc_let)[0] + ((int32_t*)fused_nn_conv2d_subtract_constant_21_let)[ax3]) - ((int32_t*)fused_nn_conv2d_constant_21_let)[ax3])) * ((int64_t)((int32_t*)fused_nn_conv2d_subtract_add_constant_63_let)[ax3])) + ((int64_t)1 << ((int64_t)((((int32_t*)fused_nn_conv2d_subtract_add_constant_65_let)[ax3] + 31) - 1)))) >> ((int64_t)(((int32_t*)fused_nn_conv2d_subtract_add_constant_65_let)[ax3] + 31)))) - 128;
    int32_t v__1 = (v_) < (127) ? (v_) : (127);
    T_cast[ax3] = ((int8_t)((v__1) > (-128) ? (v__1) : (-128)));
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_cast_12(int8_t* p0, int8_t* T_cast, uint8_t* global_const_workspace_120_var, uint8_t* global_workspace_121_var) {
  void* fused_nn_conv2d_subtract_add_constant_74_let = (&(global_const_workspace_120_var[771664]));
  void* fused_nn_conv2d_subtract_add_constant_73_let = (&(global_const_workspace_120_var[771856]));
  void* fused_nn_conv2d_subtract_add_constant_72_let = (&(global_const_workspace_120_var[772048]));
  void* fused_nn_conv2d_constant_25_let = (&(global_const_workspace_120_var[772816]));
  void* fused_nn_conv2d_subtract_constant_24_let = (&(global_const_workspace_120_var[771280]));
  void* fused_constant_37_let = (&(global_const_workspace_120_var[446688]));
  void* pad_temp_let = (&(global_workspace_121_var[52736]));
  void* conv2d_nhwc_let = (&(global_workspace_121_var[52976]));
  for (int32_t i3 = 0; i3 < 192; ++i3) {
    ((int8_t*)pad_temp_let)[i3] = p0[i3];
  }
  for (int32_t ax3 = 0; ax3 < 48; ++ax3) {
    ((int32_t*)conv2d_nhwc_let)[0] = 0;
    for (int32_t rc = 0; rc < 192; ++rc) {
      ((int32_t*)conv2d_nhwc_let)[0] = (((int32_t*)conv2d_nhwc_let)[0] + (((int32_t)((int8_t*)pad_temp_let)[rc]) * ((int32_t)((int8_t*)fused_constant_37_let)[((rc * 48) + ax3)])));
    }
    int32_t v_ = ((int32_t)(((((int64_t)((((int32_t*)conv2d_nhwc_let)[0] + ((int32_t*)fused_nn_conv2d_subtract_constant_24_let)[ax3]) - ((int32_t*)fused_nn_conv2d_constant_25_let)[ax3])) * ((int64_t)((int32_t*)fused_nn_conv2d_subtract_add_constant_72_let)[ax3])) + ((int64_t)1 << ((int64_t)((((int32_t*)fused_nn_conv2d_subtract_add_constant_74_let)[ax3] + 31) - 1)))) >> ((int64_t)(((int32_t*)fused_nn_conv2d_subtract_add_constant_74_let)[ax3] + 31)))) - 128;
    int32_t v__1 = (v_) < (127) ? (v_) : (127);
    T_cast[ax3] = ((int8_t)((v__1) > (-128) ? (v__1) : (-128)));
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_cast_13(int8_t* p0, int8_t* T_cast, uint8_t* global_const_workspace_144_var, uint8_t* global_workspace_145_var) {
  void* fused_nn_conv2d_subtract_add_constant_89_let = (&(global_const_workspace_144_var[773360]));
  void* fused_nn_conv2d_subtract_add_constant_88_let = (&(global_const_workspace_144_var[773520]));
  void* fused_nn_conv2d_subtract_add_constant_87_let = (&(global_const_workspace_144_var[773680]));
  void* fused_nn_conv2d_constant_31_let = (&(global_const_workspace_144_var[773840]));
  void* fused_nn_conv2d_subtract_constant_29_let = (&(global_const_workspace_144_var[773200]));
  void* fused_constant_44_let = (&(global_const_workspace_144_var[590128]));
  void* pad_temp_let = (&(global_workspace_145_var[7680]));
  for (int32_t i0_i1_fused = 0; i0_i1_fused < 4; ++i0_i1_fused) {
    for (int32_t i2 = 0; i2 < 4; ++i2) {
      for (int32_t i3 = 0; i3 < 96; ++i3) {
        int32_t cse_var_1 = (((i0_i1_fused * 384) + (i2 * 96)) + i3);
        ((int8_t*)pad_temp_let)[cse_var_1] = p0[cse_var_1];
      }
    }
  }
  for (int32_t ax0_ax1_fused_ax2_fused = 0; ax0_ax1_fused_ax2_fused < 16; ++ax0_ax1_fused_ax2_fused) {
    void* conv2d_nhwc_let = (&(global_workspace_145_var[52736]));
    for (int32_t ax3 = 0; ax3 < 40; ++ax3) {
      ((int32_t*)conv2d_nhwc_let)[0] = 0;
      for (int32_t rc = 0; rc < 96; ++rc) {
        ((int32_t*)conv2d_nhwc_let)[0] = (((int32_t*)conv2d_nhwc_let)[0] + (((int32_t)((int8_t*)pad_temp_let)[((ax0_ax1_fused_ax2_fused * 96) + rc)]) * ((int32_t)((int8_t*)fused_constant_44_let)[((rc * 40) + ax3)])));
      }
      int32_t v_ = ((int32_t)(((((int64_t)((((int32_t*)conv2d_nhwc_let)[0] + ((int32_t*)fused_nn_conv2d_subtract_constant_29_let)[ax3]) - ((int32_t*)fused_nn_conv2d_constant_31_let)[ax3])) * ((int64_t)((int32_t*)fused_nn_conv2d_subtract_add_constant_87_let)[ax3])) + ((int64_t)1 << ((int64_t)((((int32_t*)fused_nn_conv2d_subtract_add_constant_89_let)[ax3] + 31) - 1)))) >> ((int64_t)(((int32_t*)fused_nn_conv2d_subtract_add_constant_89_let)[ax3] + 31)))) + 2;
      int32_t v__1 = (v_) < (127) ? (v_) : (127);
      T_cast[((ax0_ax1_fused_ax2_fused * 40) + ax3)] = ((int8_t)((v__1) > (-128) ? (v__1) : (-128)));
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_cast_14(int8_t* p0, int8_t* T_cast, uint8_t* global_const_workspace_156_var, uint8_t* global_workspace_157_var) {
  void* fused_nn_conv2d_subtract_add_constant_98_let = (&(global_const_workspace_156_var[775456]));
  void* fused_nn_conv2d_subtract_add_constant_97_let = (&(global_const_workspace_156_var[775584]));
  void* fused_nn_conv2d_subtract_add_constant_96_let = (&(global_const_workspace_156_var[775712]));
  void* fused_nn_conv2d_constant_34_let = (&(global_const_workspace_156_var[777120]));
  void* fused_nn_conv2d_subtract_constant_32_let = (&(global_const_workspace_156_var[774944]));
  void* fused_constant_48_let = (&(global_const_workspace_156_var[586288]));
  void* pad_temp_let = (&(global_workspace_157_var[52736]));
  void* conv2d_nhwc_let = (&(global_workspace_157_var[52888]));
  for (int32_t i3 = 0; i3 < 120; ++i3) {
    ((int8_t*)pad_temp_let)[i3] = p0[i3];
  }
  for (int32_t ax3 = 0; ax3 < 32; ++ax3) {
    ((int32_t*)conv2d_nhwc_let)[0] = 0;
    for (int32_t rc = 0; rc < 120; ++rc) {
      ((int32_t*)conv2d_nhwc_let)[0] = (((int32_t*)conv2d_nhwc_let)[0] + (((int32_t)((int8_t*)pad_temp_let)[rc]) * ((int32_t)((int8_t*)fused_constant_48_let)[((rc * 32) + ax3)])));
    }
    int32_t v_ = ((int32_t)(((((int64_t)((((int32_t*)conv2d_nhwc_let)[0] + ((int32_t*)fused_nn_conv2d_subtract_constant_32_let)[ax3]) - ((int32_t*)fused_nn_conv2d_constant_34_let)[ax3])) * ((int64_t)((int32_t*)fused_nn_conv2d_subtract_add_constant_96_let)[ax3])) + ((int64_t)1 << ((int64_t)((((int32_t*)fused_nn_conv2d_subtract_add_constant_98_let)[ax3] + 31) - 1)))) >> ((int64_t)(((int32_t*)fused_nn_conv2d_subtract_add_constant_98_let)[ax3] + 31)))) - 128;
    int32_t v__1 = (v_) < (127) ? (v_) : (127);
    T_cast[ax3] = ((int8_t)((v__1) > (-128) ? (v__1) : (-128)));
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_cast_15(int8_t* p0, int8_t* T_cast, uint8_t* global_const_workspace_174_var, uint8_t* global_workspace_175_var) {
  void* fused_nn_conv2d_subtract_add_constant_110_let = (&(global_const_workspace_174_var[768464]));
  void* fused_nn_conv2d_subtract_add_constant_109_let = (&(global_const_workspace_174_var[768720]));
  void* fused_nn_conv2d_subtract_add_constant_108_let = (&(global_const_workspace_174_var[768976]));
  void* fused_nn_conv2d_constant_38_let = (&(global_const_workspace_174_var[769232]));
  void* fused_nn_conv2d_subtract_constant_36_let = (&(global_const_workspace_174_var[768208]));
  void* fused_constant_53_let = (&(global_const_workspace_174_var[381696]));
  void* pad_temp_let = (&(global_workspace_175_var[52992]));
  void* conv2d_nhwc_let = (&(global_workspace_175_var[52736]));
  for (int32_t i3 = 0; i3 < 240; ++i3) {
    ((int8_t*)pad_temp_let)[i3] = p0[i3];
  }
  for (int32_t ff = 0; ff < 64; ++ff) {
    ((int32_t*)conv2d_nhwc_let)[ff] = 0;
    for (int32_t rc = 0; rc < 240; ++rc) {
      ((int32_t*)conv2d_nhwc_let)[ff] = (((int32_t*)conv2d_nhwc_let)[ff] + (((int32_t)((int8_t*)pad_temp_let)[rc]) * ((int32_t)((int8_t*)fused_constant_53_let)[((rc * 64) + ff)])));
    }
  }
  for (int32_t ax3_inner = 0; ax3_inner < 64; ++ax3_inner) {
    int32_t v_ = ((int32_t)(((((int64_t)((((int32_t*)conv2d_nhwc_let)[ax3_inner] + ((int32_t*)fused_nn_conv2d_subtract_constant_36_let)[ax3_inner]) - ((int32_t*)fused_nn_conv2d_constant_38_let)[ax3_inner])) * ((int64_t)((int32_t*)fused_nn_conv2d_subtract_add_constant_108_let)[ax3_inner])) + ((int64_t)1 << ((int64_t)((((int32_t*)fused_nn_conv2d_subtract_add_constant_110_let)[ax3_inner] + 31) - 1)))) >> ((int64_t)(((int32_t*)fused_nn_conv2d_subtract_add_constant_110_let)[ax3_inner] + 31)))) - 128;
    int32_t v__1 = (v_) < (127) ? (v_) : (127);
    T_cast[ax3_inner] = ((int8_t)((v__1) > (-128) ? (v__1) : (-128)));
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_cast_16(int8_t* p0, int8_t* T_cast, uint8_t* global_const_workspace_180_var, uint8_t* global_workspace_181_var) {
  void* fused_nn_conv2d_subtract_add_constant_116_let = (&(global_const_workspace_180_var[763600]));
  void* fused_nn_conv2d_subtract_add_constant_115_let = (&(global_const_workspace_180_var[763888]));
  void* fused_nn_conv2d_subtract_add_constant_114_let = (&(global_const_workspace_180_var[764176]));
  void* fused_nn_conv2d_constant_40_let = (&(global_const_workspace_180_var[765040]));
  void* fused_nn_conv2d_subtract_constant_38_let = (&(global_const_workspace_180_var[761584]));
  void* fused_constant_55_let = (&(global_const_workspace_180_var[349056]));
  void* pad_temp_let = (&(global_workspace_181_var[5760]));
  for (int32_t i0_i1_fused = 0; i0_i1_fused < 2; ++i0_i1_fused) {
    for (int32_t i2 = 0; i2 < 2; ++i2) {
      for (int32_t i3 = 0; i3 < 240; ++i3) {
        int32_t cse_var_1 = (((i0_i1_fused * 480) + (i2 * 240)) + i3);
        ((int8_t*)pad_temp_let)[cse_var_1] = p0[cse_var_1];
      }
    }
  }
  for (int32_t ax0_ax1_fused_ax2_fused = 0; ax0_ax1_fused_ax2_fused < 4; ++ax0_ax1_fused_ax2_fused) {
    void* conv2d_nhwc_let = (&(global_workspace_181_var[54176]));
    for (int32_t ax3 = 0; ax3 < 72; ++ax3) {
      ((int32_t*)conv2d_nhwc_let)[0] = 0;
      for (int32_t rc = 0; rc < 240; ++rc) {
        ((int32_t*)conv2d_nhwc_let)[0] = (((int32_t*)conv2d_nhwc_let)[0] + (((int32_t)((int8_t*)pad_temp_let)[((ax0_ax1_fused_ax2_fused * 240) + rc)]) * ((int32_t)((int8_t*)fused_constant_55_let)[((rc * 72) + ax3)])));
      }
      int32_t v_ = ((int32_t)(((((int64_t)((((int32_t*)conv2d_nhwc_let)[0] + ((int32_t*)fused_nn_conv2d_subtract_constant_38_let)[ax3]) - ((int32_t*)fused_nn_conv2d_constant_40_let)[ax3])) * ((int64_t)((int32_t*)fused_nn_conv2d_subtract_add_constant_114_let)[ax3])) + ((int64_t)1 << ((int64_t)((((int32_t*)fused_nn_conv2d_subtract_add_constant_116_let)[ax3] + 31) - 1)))) >> ((int64_t)(((int32_t*)fused_nn_conv2d_subtract_add_constant_116_let)[ax3] + 31)))) - 13;
      int32_t v__1 = (v_) < (127) ? (v_) : (127);
      T_cast[((ax0_ax1_fused_ax2_fused * 72) + ax3)] = ((int8_t)((v__1) > (-128) ? (v__1) : (-128)));
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_cast_17(int8_t* p0, int8_t* T_cast, uint8_t* global_const_workspace_192_var, uint8_t* global_workspace_193_var) {
  void* fused_nn_conv2d_subtract_add_constant_125_let = (&(global_const_workspace_192_var[743680]));
  void* fused_nn_conv2d_subtract_add_constant_124_let = (&(global_const_workspace_192_var[744128]));
  void* fused_nn_conv2d_subtract_add_constant_123_let = (&(global_const_workspace_192_var[744576]));
  void* fused_nn_conv2d_constant_43_let = (&(global_const_workspace_192_var[745472]));
  void* fused_nn_conv2d_subtract_constant_41_let = (&(global_const_workspace_192_var[741888]));
  void* fused_constant_59_let = (&(global_const_workspace_192_var[145152]));
  void* pad_temp_let = (&(global_workspace_193_var[52736]));
  void* conv2d_nhwc_let = (&(global_workspace_193_var[54288]));
  for (int32_t i3 = 0; i3 < 432; ++i3) {
    ((int8_t*)pad_temp_let)[i3] = p0[i3];
  }
  for (int32_t ax3 = 0; ax3 < 112; ++ax3) {
    ((int32_t*)conv2d_nhwc_let)[0] = 0;
    for (int32_t rc = 0; rc < 432; ++rc) {
      ((int32_t*)conv2d_nhwc_let)[0] = (((int32_t*)conv2d_nhwc_let)[0] + (((int32_t)((int8_t*)pad_temp_let)[rc]) * ((int32_t)((int8_t*)fused_constant_59_let)[((rc * 112) + ax3)])));
    }
    int32_t v_ = ((int32_t)(((((int64_t)((((int32_t*)conv2d_nhwc_let)[0] + ((int32_t*)fused_nn_conv2d_subtract_constant_41_let)[ax3]) - ((int32_t*)fused_nn_conv2d_constant_43_let)[ax3])) * ((int64_t)((int32_t*)fused_nn_conv2d_subtract_add_constant_123_let)[ax3])) + ((int64_t)1 << ((int64_t)((((int32_t*)fused_nn_conv2d_subtract_add_constant_125_let)[ax3] + 31) - 1)))) >> ((int64_t)(((int32_t*)fused_nn_conv2d_subtract_add_constant_125_let)[ax3] + 31)))) - 128;
    int32_t v__1 = (v_) < (127) ? (v_) : (127);
    T_cast[ax3] = ((int8_t)((v__1) > (-128) ? (v__1) : (-128)));
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_cast_18(int8_t* p0, int8_t* T_cast, uint8_t* global_const_workspace_208_var, uint8_t* global_workspace_209_var) {
  void* fused_nn_conv2d_subtract_add_constant_137_let = (&(global_const_workspace_208_var[742336]));
  void* fused_nn_conv2d_subtract_add_constant_136_let = (&(global_const_workspace_208_var[742784]));
  void* fused_nn_conv2d_subtract_add_constant_135_let = (&(global_const_workspace_208_var[743232]));
  void* fused_nn_conv2d_constant_47_let = (&(global_const_workspace_208_var[745024]));
  void* fused_nn_conv2d_subtract_constant_45_let = (&(global_const_workspace_208_var[741440]));
  void* fused_constant_64_let = (&(global_const_workspace_208_var[48384]));
  void* pad_temp_let = (&(global_workspace_209_var[52736]));
  void* conv2d_nhwc_let = (&(global_workspace_209_var[54000]));
  for (int32_t i3 = 0; i3 < 432; ++i3) {
    ((int8_t*)pad_temp_let)[i3] = p0[i3];
  }
  for (int32_t ax3 = 0; ax3 < 112; ++ax3) {
    ((int32_t*)conv2d_nhwc_let)[0] = 0;
    for (int32_t rc = 0; rc < 432; ++rc) {
      ((int32_t*)conv2d_nhwc_let)[0] = (((int32_t*)conv2d_nhwc_let)[0] + (((int32_t)((int8_t*)pad_temp_let)[rc]) * ((int32_t)((int8_t*)fused_constant_64_let)[((rc * 112) + ax3)])));
    }
    int32_t v_ = ((int32_t)(((((int64_t)((((int32_t*)conv2d_nhwc_let)[0] + ((int32_t*)fused_nn_conv2d_subtract_constant_45_let)[ax3]) - ((int32_t*)fused_nn_conv2d_constant_47_let)[ax3])) * ((int64_t)((int32_t*)fused_nn_conv2d_subtract_add_constant_135_let)[ax3])) + ((int64_t)1 << ((int64_t)((((int32_t*)fused_nn_conv2d_subtract_add_constant_137_let)[ax3] + 31) - 1)))) >> ((int64_t)(((int32_t*)fused_nn_conv2d_subtract_add_constant_137_let)[ax3] + 31)))) - 128;
    int32_t v__1 = (v_) < (127) ? (v_) : (127);
    T_cast[ax3] = ((int8_t)((v__1) > (-128) ? (v__1) : (-128)));
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_cast_2(int8_t* p0, int8_t* T_cast, uint8_t* global_const_workspace_22_var, uint8_t* global_workspace_23_var) {
  void* fused_nn_conv2d_subtract_add_constant_17_let = (&(global_const_workspace_22_var[762736]));
  void* fused_nn_conv2d_subtract_add_constant_16_let = (&(global_const_workspace_22_var[763024]));
  void* fused_nn_conv2d_subtract_add_constant_15_let = (&(global_const_workspace_22_var[763312]));
  void* fused_nn_conv2d_constant_5_let = (&(global_const_workspace_22_var[764752]));
  void* fused_nn_conv2d_subtract_constant_5_let = (&(global_const_workspace_22_var[761296]));
  void* fused_constant_6_let = (&(global_const_workspace_22_var[689968]));
  void* pad_temp_let = (&(global_workspace_23_var[39240]));
  for (int32_t i0_i1_fused = 0; i0_i1_fused < 16; ++i0_i1_fused) {
    for (int32_t i2 = 0; i2 < 16; ++i2) {
      for (int32_t i3 = 0; i3 < 16; ++i3) {
        int32_t cse_var_1 = (((i0_i1_fused * 256) + (i2 * 16)) + i3);
        ((int8_t*)pad_temp_let)[cse_var_1] = p0[cse_var_1];
      }
    }
  }
  for (int32_t ax0_ax1_fused_ax2_fused = 0; ax0_ax1_fused_ax2_fused < 256; ++ax0_ax1_fused_ax2_fused) {
    void* conv2d_nhwc_let = (&(global_workspace_23_var[43336]));
    for (int32_t ax3 = 0; ax3 < 72; ++ax3) {
      ((int32_t*)conv2d_nhwc_let)[0] = 0;
      for (int32_t rc = 0; rc < 16; ++rc) {
        ((int32_t*)conv2d_nhwc_let)[0] = (((int32_t*)conv2d_nhwc_let)[0] + (((int32_t)((int8_t*)pad_temp_let)[((ax0_ax1_fused_ax2_fused * 16) + rc)]) * ((int32_t)((int8_t*)fused_constant_6_let)[((rc * 72) + ax3)])));
      }
      int32_t v_ = ((int32_t)(((((int64_t)((((int32_t*)conv2d_nhwc_let)[0] + ((int32_t*)fused_nn_conv2d_subtract_constant_5_let)[ax3]) - ((int32_t*)fused_nn_conv2d_constant_5_let)[ax3])) * ((int64_t)((int32_t*)fused_nn_conv2d_subtract_add_constant_15_let)[ax3])) + ((int64_t)1 << ((int64_t)((((int32_t*)fused_nn_conv2d_subtract_add_constant_17_let)[ax3] + 31) - 1)))) >> ((int64_t)(((int32_t*)fused_nn_conv2d_subtract_add_constant_17_let)[ax3] + 31)))) - 128;
      int32_t v__1 = (v_) < (127) ? (v_) : (127);
      T_cast[((ax0_ax1_fused_ax2_fused * 72) + ax3)] = ((int8_t)((v__1) > (-128) ? (v__1) : (-128)));
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_cast_3(int8_t* p0, int8_t* T_cast, uint8_t* global_const_workspace_26_var, uint8_t* global_workspace_27_var) {
  void* fused_nn_conv2d_subtract_add_constant_20_let = (&(global_const_workspace_26_var[761872]));
  void* fused_nn_conv2d_subtract_add_constant_19_let = (&(global_const_workspace_26_var[762160]));
  void* fused_nn_conv2d_subtract_add_constant_18_let = (&(global_const_workspace_26_var[762448]));
  void* fused_nn_conv2d_subtract_constant_6_let = (&(global_const_workspace_26_var[761008]));
  void* fused_nn_conv2d_constant_6_let = (&(global_const_workspace_26_var[764464]));
  void* fused_constant_7_let = (&(global_const_workspace_26_var[728592]));
  void* PaddedInput_let = (&(global_workspace_27_var[20808]));
  void* DepthwiseConv2d_let = (&(global_workspace_27_var[41616]));
  for (int32_t i1 = 0; i1 < 17; ++i1) {
    for (int32_t i2 = 0; i2 < 17; ++i2) {
      for (int32_t i3 = 0; i3 < 72; ++i3) {
        int32_t cse_var_1 = (((i1 * 1224) + (i2 * 72)) + i3);
        ((int8_t*)PaddedInput_let)[cse_var_1] = p0[cse_var_1];
      }
    }
  }
  for (int32_t i = 0; i < 8; ++i) {
    for (int32_t j = 0; j < 8; ++j) {
      for (int32_t c = 0; c < 72; ++c) {
        ((int32_t*)DepthwiseConv2d_let)[(((i * 576) + (j * 72)) + c)] = 0;
        for (int32_t di = 0; di < 3; ++di) {
          for (int32_t dj = 0; dj < 3; ++dj) {
            int32_t cse_var_3 = (dj * 72);
            int32_t cse_var_2 = (((i * 576) + (j * 72)) + c);
            ((int32_t*)DepthwiseConv2d_let)[cse_var_2] = (((int32_t*)DepthwiseConv2d_let)[cse_var_2] + (((int32_t)((int8_t*)PaddedInput_let)[(((((i * 2448) + (di * 1224)) + (j * 144)) + cse_var_3) + c)]) * ((int32_t)((int8_t*)fused_constant_7_let)[(((di * 216) + cse_var_3) + c)])));
          }
        }
      }
    }
  }
  for (int32_t ax1 = 0; ax1 < 8; ++ax1) {
    for (int32_t ax2 = 0; ax2 < 8; ++ax2) {
      for (int32_t ax3 = 0; ax3 < 72; ++ax3) {
        int32_t cse_var_4 = (((ax1 * 576) + (ax2 * 72)) + ax3);
        ((int32_t*)DepthwiseConv2d_let)[cse_var_4] = (((int32_t*)DepthwiseConv2d_let)[cse_var_4] - ((int32_t*)fused_nn_conv2d_constant_6_let)[ax3]);
      }
    }
  }
  for (int32_t ax1_1 = 0; ax1_1 < 8; ++ax1_1) {
    for (int32_t ax2_1 = 0; ax2_1 < 8; ++ax2_1) {
      for (int32_t ax3_1 = 0; ax3_1 < 72; ++ax3_1) {
        int32_t cse_var_5 = (((ax1_1 * 576) + (ax2_1 * 72)) + ax3_1);
        ((int32_t*)DepthwiseConv2d_let)[cse_var_5] = (((int32_t*)DepthwiseConv2d_let)[cse_var_5] + ((int32_t*)fused_nn_conv2d_subtract_constant_6_let)[ax3_1]);
      }
    }
  }
  for (int32_t i1_1 = 0; i1_1 < 8; ++i1_1) {
    for (int32_t i2_1 = 0; i2_1 < 8; ++i2_1) {
      for (int32_t i3_1 = 0; i3_1 < 72; ++i3_1) {
        int32_t cse_var_6 = (((i1_1 * 576) + (i2_1 * 72)) + i3_1);
        ((int32_t*)DepthwiseConv2d_let)[cse_var_6] = ((int32_t)(((((int64_t)((int32_t*)DepthwiseConv2d_let)[cse_var_6]) * ((int64_t)((int32_t*)fused_nn_conv2d_subtract_add_constant_18_let)[i3_1])) + ((int64_t)1 << ((int64_t)((((int32_t*)fused_nn_conv2d_subtract_add_constant_20_let)[i3_1] + 31) - 1)))) >> ((int64_t)(((int32_t*)fused_nn_conv2d_subtract_add_constant_20_let)[i3_1] + 31))));
      }
    }
  }
  for (int32_t ax1_2 = 0; ax1_2 < 8; ++ax1_2) {
    for (int32_t ax2_2 = 0; ax2_2 < 8; ++ax2_2) {
      for (int32_t ax3_2 = 0; ax3_2 < 72; ++ax3_2) {
        int32_t cse_var_7 = (((ax1_2 * 576) + (ax2_2 * 72)) + ax3_2);
        ((int32_t*)DepthwiseConv2d_let)[cse_var_7] = (((int32_t*)DepthwiseConv2d_let)[cse_var_7] - 128);
      }
    }
  }
  for (int32_t i1_2 = 0; i1_2 < 8; ++i1_2) {
    for (int32_t i2_2 = 0; i2_2 < 8; ++i2_2) {
      for (int32_t i3_2 = 0; i3_2 < 72; ++i3_2) {
        int32_t cse_var_8 = (((i1_2 * 576) + (i2_2 * 72)) + i3_2);
        int32_t v_ = ((int32_t*)DepthwiseConv2d_let)[cse_var_8];
        int32_t v__1 = (v_) < (127) ? (v_) : (127);
        ((int32_t*)DepthwiseConv2d_let)[cse_var_8] = ((v__1) > (-128) ? (v__1) : (-128));
      }
    }
  }
  for (int32_t ax1_3 = 0; ax1_3 < 8; ++ax1_3) {
    for (int32_t ax2_3 = 0; ax2_3 < 8; ++ax2_3) {
      for (int32_t ax3_3 = 0; ax3_3 < 72; ++ax3_3) {
        int32_t cse_var_9 = (((ax1_3 * 576) + (ax2_3 * 72)) + ax3_3);
        T_cast[cse_var_9] = ((int8_t)((int32_t*)DepthwiseConv2d_let)[cse_var_9]);
      }
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_cast_4(int8_t* p0, int8_t* T_cast, uint8_t* global_const_workspace_28_var, uint8_t* global_workspace_29_var) {
  void* fused_nn_conv2d_subtract_add_constant_23_let = (&(global_const_workspace_28_var[780800]));
  void* fused_nn_conv2d_subtract_add_constant_22_let = (&(global_const_workspace_28_var[780896]));
  void* fused_nn_conv2d_subtract_add_constant_21_let = (&(global_const_workspace_28_var[780992]));
  void* fused_nn_conv2d_constant_7_let = (&(global_const_workspace_28_var[781088]));
  void* fused_nn_conv2d_subtract_constant_7_let = (&(global_const_workspace_28_var[779552]));
  void* fused_constant_8_let = (&(global_const_workspace_28_var[688240]));
  void* pad_temp_let = (&(global_workspace_29_var[0]));
  for (int32_t i0_i1_fused = 0; i0_i1_fused < 8; ++i0_i1_fused) {
    for (int32_t i2 = 0; i2 < 8; ++i2) {
      for (int32_t i3 = 0; i3 < 72; ++i3) {
        int32_t cse_var_1 = (((i0_i1_fused * 576) + (i2 * 72)) + i3);
        ((int8_t*)pad_temp_let)[cse_var_1] = p0[cse_var_1];
      }
    }
  }
  for (int32_t ax0_ax1_fused_ax2_fused = 0; ax0_ax1_fused_ax2_fused < 64; ++ax0_ax1_fused_ax2_fused) {
    void* conv2d_nhwc_let = (&(global_workspace_29_var[32864]));
    for (int32_t ax3 = 0; ax3 < 24; ++ax3) {
      ((int32_t*)conv2d_nhwc_let)[0] = 0;
      for (int32_t rc = 0; rc < 72; ++rc) {
        ((int32_t*)conv2d_nhwc_let)[0] = (((int32_t*)conv2d_nhwc_let)[0] + (((int32_t)((int8_t*)pad_temp_let)[((ax0_ax1_fused_ax2_fused * 72) + rc)]) * ((int32_t)((int8_t*)fused_constant_8_let)[((rc * 24) + ax3)])));
      }
      int32_t v_ = ((int32_t)(((((int64_t)((((int32_t*)conv2d_nhwc_let)[0] + ((int32_t*)fused_nn_conv2d_subtract_constant_7_let)[ax3]) - ((int32_t*)fused_nn_conv2d_constant_7_let)[ax3])) * ((int64_t)((int32_t*)fused_nn_conv2d_subtract_add_constant_21_let)[ax3])) + ((int64_t)1 << ((int64_t)((((int32_t*)fused_nn_conv2d_subtract_add_constant_23_let)[ax3] + 31) - 1)))) >> ((int64_t)(((int32_t*)fused_nn_conv2d_subtract_add_constant_23_let)[ax3] + 31)))) - 4;
      int32_t v__1 = (v_) < (127) ? (v_) : (127);
      T_cast[((ax0_ax1_fused_ax2_fused * 24) + ax3)] = ((int8_t)((v__1) > (-128) ? (v__1) : (-128)));
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_cast_5(int8_t* p0, int8_t* T_cast, uint8_t* global_const_workspace_30_var, uint8_t* global_workspace_31_var) {
  void* fused_nn_conv2d_subtract_add_constant_26_let = (&(global_const_workspace_30_var[759248]));
  void* fused_nn_conv2d_subtract_add_constant_25_let = (&(global_const_workspace_30_var[759600]));
  void* fused_nn_conv2d_subtract_add_constant_24_let = (&(global_const_workspace_30_var[759952]));
  void* fused_nn_conv2d_constant_8_let = (&(global_const_workspace_30_var[760656]));
  void* fused_nn_conv2d_subtract_constant_8_let = (&(global_const_workspace_30_var[757840]));
  void* fused_constant_9_let = (&(global_const_workspace_30_var[619440]));
  void* pad_temp_let = (&(global_workspace_31_var[32864]));
  for (int32_t i0_i1_fused = 0; i0_i1_fused < 8; ++i0_i1_fused) {
    for (int32_t i2 = 0; i2 < 8; ++i2) {
      for (int32_t i3 = 0; i3 < 24; ++i3) {
        int32_t cse_var_1 = (((i0_i1_fused * 192) + (i2 * 24)) + i3);
        ((int8_t*)pad_temp_let)[cse_var_1] = p0[cse_var_1];
      }
    }
  }
  for (int32_t ax0_ax1_fused_ax2_fused = 0; ax0_ax1_fused_ax2_fused < 64; ++ax0_ax1_fused_ax2_fused) {
    void* conv2d_nhwc_let = (&(global_workspace_31_var[34400]));
    for (int32_t ax3 = 0; ax3 < 88; ++ax3) {
      ((int32_t*)conv2d_nhwc_let)[0] = 0;
      for (int32_t rc = 0; rc < 24; ++rc) {
        ((int32_t*)conv2d_nhwc_let)[0] = (((int32_t*)conv2d_nhwc_let)[0] + (((int32_t)((int8_t*)pad_temp_let)[((ax0_ax1_fused_ax2_fused * 24) + rc)]) * ((int32_t)((int8_t*)fused_constant_9_let)[((rc * 88) + ax3)])));
      }
      int32_t v_ = ((int32_t)(((((int64_t)((((int32_t*)conv2d_nhwc_let)[0] + ((int32_t*)fused_nn_conv2d_subtract_constant_8_let)[ax3]) - ((int32_t*)fused_nn_conv2d_constant_8_let)[ax3])) * ((int64_t)((int32_t*)fused_nn_conv2d_subtract_add_constant_24_let)[ax3])) + ((int64_t)1 << ((int64_t)((((int32_t*)fused_nn_conv2d_subtract_add_constant_26_let)[ax3] + 31) - 1)))) >> ((int64_t)(((int32_t*)fused_nn_conv2d_subtract_add_constant_26_let)[ax3] + 31)))) - 128;
      int32_t v__1 = (v_) < (127) ? (v_) : (127);
      T_cast[((ax0_ax1_fused_ax2_fused * 88) + ax3)] = ((int8_t)((v__1) > (-128) ? (v__1) : (-128)));
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_cast_6(int8_t* p0, int8_t* T_cast, uint8_t* global_const_workspace_34_var, uint8_t* global_workspace_35_var) {
  void* fused_nn_conv2d_subtract_add_constant_29_let = (&(global_const_workspace_34_var[758192]));
  void* fused_nn_conv2d_subtract_add_constant_28_let = (&(global_const_workspace_34_var[758544]));
  void* fused_nn_conv2d_subtract_add_constant_27_let = (&(global_const_workspace_34_var[758896]));
  void* fused_nn_conv2d_subtract_constant_9_let = (&(global_const_workspace_34_var[757488]));
  void* fused_nn_conv2d_constant_9_let = (&(global_const_workspace_34_var[760304]));
  void* fused_constant_10_let = (&(global_const_workspace_34_var[705520]));
  void* PaddedInput_let = (&(global_workspace_35_var[22528]));
  void* DepthwiseConv2d_let = (&(global_workspace_35_var[0]));
  for (int32_t i1 = 0; i1 < 10; ++i1) {
    for (int32_t i2 = 0; i2 < 10; ++i2) {
      for (int32_t i3 = 0; i3 < 88; ++i3) {
        int32_t cse_var_1 = (((i1 * 880) + (i2 * 88)) + i3);
        ((int8_t*)PaddedInput_let)[cse_var_1] = p0[cse_var_1];
      }
    }
  }
  for (int32_t i = 0; i < 8; ++i) {
    for (int32_t j = 0; j < 8; ++j) {
      for (int32_t c = 0; c < 88; ++c) {
        ((int32_t*)DepthwiseConv2d_let)[(((i * 704) + (j * 88)) + c)] = 0;
        for (int32_t di = 0; di < 3; ++di) {
          for (int32_t dj = 0; dj < 3; ++dj) {
            int32_t cse_var_4 = (j * 88);
            int32_t cse_var_3 = (dj * 88);
            int32_t cse_var_2 = (((i * 704) + cse_var_4) + c);
            ((int32_t*)DepthwiseConv2d_let)[cse_var_2] = (((int32_t*)DepthwiseConv2d_let)[cse_var_2] + (((int32_t)((int8_t*)PaddedInput_let)[(((((i * 880) + (di * 880)) + cse_var_4) + cse_var_3) + c)]) * ((int32_t)((int8_t*)fused_constant_10_let)[(((di * 264) + cse_var_3) + c)])));
          }
        }
      }
    }
  }
  for (int32_t ax1 = 0; ax1 < 8; ++ax1) {
    for (int32_t ax2 = 0; ax2 < 8; ++ax2) {
      for (int32_t ax3 = 0; ax3 < 88; ++ax3) {
        int32_t cse_var_5 = (((ax1 * 704) + (ax2 * 88)) + ax3);
        ((int32_t*)DepthwiseConv2d_let)[cse_var_5] = (((int32_t*)DepthwiseConv2d_let)[cse_var_5] - ((int32_t*)fused_nn_conv2d_constant_9_let)[ax3]);
      }
    }
  }
  for (int32_t ax1_1 = 0; ax1_1 < 8; ++ax1_1) {
    for (int32_t ax2_1 = 0; ax2_1 < 8; ++ax2_1) {
      for (int32_t ax3_1 = 0; ax3_1 < 88; ++ax3_1) {
        int32_t cse_var_6 = (((ax1_1 * 704) + (ax2_1 * 88)) + ax3_1);
        ((int32_t*)DepthwiseConv2d_let)[cse_var_6] = (((int32_t*)DepthwiseConv2d_let)[cse_var_6] + ((int32_t*)fused_nn_conv2d_subtract_constant_9_let)[ax3_1]);
      }
    }
  }
  for (int32_t i1_1 = 0; i1_1 < 8; ++i1_1) {
    for (int32_t i2_1 = 0; i2_1 < 8; ++i2_1) {
      for (int32_t i3_1 = 0; i3_1 < 88; ++i3_1) {
        int32_t cse_var_7 = (((i1_1 * 704) + (i2_1 * 88)) + i3_1);
        ((int32_t*)DepthwiseConv2d_let)[cse_var_7] = ((int32_t)(((((int64_t)((int32_t*)DepthwiseConv2d_let)[cse_var_7]) * ((int64_t)((int32_t*)fused_nn_conv2d_subtract_add_constant_27_let)[i3_1])) + ((int64_t)1 << ((int64_t)((((int32_t*)fused_nn_conv2d_subtract_add_constant_29_let)[i3_1] + 31) - 1)))) >> ((int64_t)(((int32_t*)fused_nn_conv2d_subtract_add_constant_29_let)[i3_1] + 31))));
      }
    }
  }
  for (int32_t ax1_2 = 0; ax1_2 < 8; ++ax1_2) {
    for (int32_t ax2_2 = 0; ax2_2 < 8; ++ax2_2) {
      for (int32_t ax3_2 = 0; ax3_2 < 88; ++ax3_2) {
        int32_t cse_var_8 = (((ax1_2 * 704) + (ax2_2 * 88)) + ax3_2);
        ((int32_t*)DepthwiseConv2d_let)[cse_var_8] = (((int32_t*)DepthwiseConv2d_let)[cse_var_8] - 128);
      }
    }
  }
  for (int32_t i1_2 = 0; i1_2 < 8; ++i1_2) {
    for (int32_t i2_2 = 0; i2_2 < 8; ++i2_2) {
      for (int32_t i3_2 = 0; i3_2 < 88; ++i3_2) {
        int32_t cse_var_9 = (((i1_2 * 704) + (i2_2 * 88)) + i3_2);
        int32_t v_ = ((int32_t*)DepthwiseConv2d_let)[cse_var_9];
        int32_t v__1 = (v_) < (127) ? (v_) : (127);
        ((int32_t*)DepthwiseConv2d_let)[cse_var_9] = ((v__1) > (-128) ? (v__1) : (-128));
      }
    }
  }
  for (int32_t ax1_3 = 0; ax1_3 < 8; ++ax1_3) {
    for (int32_t ax2_3 = 0; ax2_3 < 8; ++ax2_3) {
      for (int32_t ax3_3 = 0; ax3_3 < 88; ++ax3_3) {
        int32_t cse_var_10 = (((ax1_3 * 704) + (ax2_3 * 88)) + ax3_3);
        T_cast[cse_var_10] = ((int8_t)((int32_t*)DepthwiseConv2d_let)[cse_var_10]);
      }
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_cast_7(int8_t* p0, int8_t* T_cast, uint8_t* global_const_workspace_36_var, uint8_t* global_workspace_37_var) {
  void* fused_nn_conv2d_subtract_add_constant_32_let = (&(global_const_workspace_36_var[780512]));
  void* fused_nn_conv2d_subtract_add_constant_31_let = (&(global_const_workspace_36_var[780608]));
  void* fused_nn_conv2d_subtract_add_constant_30_let = (&(global_const_workspace_36_var[780704]));
  void* fused_nn_conv2d_constant_10_let = (&(global_const_workspace_36_var[781376]));
  void* fused_nn_conv2d_subtract_constant_10_let = (&(global_const_workspace_36_var[779840]));
  void* fused_constant_11_let = (&(global_const_workspace_36_var[621552]));
  void* pad_temp_let = (&(global_workspace_37_var[0]));
  for (int32_t i0_i1_fused = 0; i0_i1_fused < 8; ++i0_i1_fused) {
    for (int32_t i2 = 0; i2 < 8; ++i2) {
      for (int32_t i3 = 0; i3 < 88; ++i3) {
        int32_t cse_var_1 = (((i0_i1_fused * 704) + (i2 * 88)) + i3);
        ((int8_t*)pad_temp_let)[cse_var_1] = p0[cse_var_1];
      }
    }
  }
  for (int32_t ax0_ax1_fused_ax2_fused = 0; ax0_ax1_fused_ax2_fused < 64; ++ax0_ax1_fused_ax2_fused) {
    void* conv2d_nhwc_let = (&(global_workspace_37_var[34400]));
    for (int32_t ax3 = 0; ax3 < 24; ++ax3) {
      ((int32_t*)conv2d_nhwc_let)[0] = 0;
      for (int32_t rc = 0; rc < 88; ++rc) {
        ((int32_t*)conv2d_nhwc_let)[0] = (((int32_t*)conv2d_nhwc_let)[0] + (((int32_t)((int8_t*)pad_temp_let)[((ax0_ax1_fused_ax2_fused * 88) + rc)]) * ((int32_t)((int8_t*)fused_constant_11_let)[((rc * 24) + ax3)])));
      }
      int32_t v_ = ((int32_t)(((((int64_t)((((int32_t*)conv2d_nhwc_let)[0] + ((int32_t*)fused_nn_conv2d_subtract_constant_10_let)[ax3]) - ((int32_t*)fused_nn_conv2d_constant_10_let)[ax3])) * ((int64_t)((int32_t*)fused_nn_conv2d_subtract_add_constant_30_let)[ax3])) + ((int64_t)1 << ((int64_t)((((int32_t*)fused_nn_conv2d_subtract_add_constant_32_let)[ax3] + 31) - 1)))) >> ((int64_t)(((int32_t*)fused_nn_conv2d_subtract_add_constant_32_let)[ax3] + 31)))) - 5;
      int32_t v__1 = (v_) < (127) ? (v_) : (127);
      T_cast[((ax0_ax1_fused_ax2_fused * 24) + ax3)] = ((int8_t)((v__1) > (-128) ? (v__1) : (-128)));
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_cast_8(int8_t* p0, int8_t* T_cast, uint8_t* global_const_workspace_66_var, uint8_t* global_workspace_67_var) {
  void* fused_nn_conv2d_subtract_add_constant_44_let = (&(global_const_workspace_66_var[780224]));
  void* fused_nn_conv2d_subtract_add_constant_43_let = (&(global_const_workspace_66_var[780320]));
  void* fused_nn_conv2d_subtract_add_constant_42_let = (&(global_const_workspace_66_var[780416]));
  void* fused_nn_conv2d_constant_14_let = (&(global_const_workspace_66_var[781280]));
  void* fused_nn_conv2d_subtract_constant_14_let = (&(global_const_workspace_66_var[779744]));
  void* fused_constant_20_let = (&(global_const_workspace_66_var[614832]));
  void* pad_temp_let = (&(global_workspace_67_var[6144]));
  void* conv2d_nhwc_let = (&(global_workspace_67_var[6264]));
  for (int32_t i3 = 0; i3 < 96; ++i3) {
    ((int8_t*)pad_temp_let)[i3] = p0[i3];
  }
  for (int32_t ax3 = 0; ax3 < 24; ++ax3) {
    ((int32_t*)conv2d_nhwc_let)[0] = 0;
    for (int32_t rc = 0; rc < 96; ++rc) {
      ((int32_t*)conv2d_nhwc_let)[0] = (((int32_t*)conv2d_nhwc_let)[0] + (((int32_t)((int8_t*)pad_temp_let)[rc]) * ((int32_t)((int8_t*)fused_constant_20_let)[((rc * 24) + ax3)])));
    }
    int32_t v_ = ((int32_t)(((((int64_t)((((int32_t*)conv2d_nhwc_let)[0] + ((int32_t*)fused_nn_conv2d_subtract_constant_14_let)[ax3]) - ((int32_t*)fused_nn_conv2d_constant_14_let)[ax3])) * ((int64_t)((int32_t*)fused_nn_conv2d_subtract_add_constant_42_let)[ax3])) + ((int64_t)1 << ((int64_t)((((int32_t*)fused_nn_conv2d_subtract_add_constant_44_let)[ax3] + 31) - 1)))) >> ((int64_t)(((int32_t*)fused_nn_conv2d_subtract_add_constant_44_let)[ax3] + 31)))) - 128;
    int32_t v__1 = (v_) < (127) ? (v_) : (127);
    T_cast[ax3] = ((int8_t)((v__1) > (-128) ? (v__1) : (-128)));
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_cast_9(int8_t* p0, int8_t* T_cast, uint8_t* global_const_workspace_72_var, uint8_t* global_workspace_73_var) {
  void* fused_nn_conv2d_subtract_add_constant_50_let = (&(global_const_workspace_72_var[776224]));
  void* fused_nn_conv2d_subtract_add_constant_49_let = (&(global_const_workspace_72_var[776352]));
  void* fused_nn_conv2d_subtract_add_constant_48_let = (&(global_const_workspace_72_var[776480]));
  void* fused_nn_conv2d_constant_16_let = (&(global_const_workspace_72_var[777376]));
  void* fused_nn_conv2d_subtract_constant_16_let = (&(global_const_workspace_72_var[775200]));
  void* fused_constant_22_let = (&(global_const_workspace_72_var[597040]));
  void* pad_temp_let = (&(global_workspace_73_var[7680]));
  for (int32_t i0_i1_fused = 0; i0_i1_fused < 4; ++i0_i1_fused) {
    for (int32_t i2 = 0; i2 < 4; ++i2) {
      for (int32_t i3 = 0; i3 < 96; ++i3) {
        int32_t cse_var_1 = (((i0_i1_fused * 384) + (i2 * 96)) + i3);
        ((int8_t*)pad_temp_let)[cse_var_1] = p0[cse_var_1];
      }
    }
  }
  for (int32_t ax0_ax1_fused_ax2_fused = 0; ax0_ax1_fused_ax2_fused < 16; ++ax0_ax1_fused_ax2_fused) {
    void* conv2d_nhwc_let = (&(global_workspace_73_var[53248]));
    for (int32_t ax3 = 0; ax3 < 32; ++ax3) {
      ((int32_t*)conv2d_nhwc_let)[0] = 0;
      for (int32_t rc = 0; rc < 96; ++rc) {
        ((int32_t*)conv2d_nhwc_let)[0] = (((int32_t*)conv2d_nhwc_let)[0] + (((int32_t)((int8_t*)pad_temp_let)[((ax0_ax1_fused_ax2_fused * 96) + rc)]) * ((int32_t)((int8_t*)fused_constant_22_let)[((rc * 32) + ax3)])));
      }
      int32_t v_ = ((int32_t)(((((int64_t)((((int32_t*)conv2d_nhwc_let)[0] + ((int32_t*)fused_nn_conv2d_subtract_constant_16_let)[ax3]) - ((int32_t*)fused_nn_conv2d_constant_16_let)[ax3])) * ((int64_t)((int32_t*)fused_nn_conv2d_subtract_add_constant_48_let)[ax3])) + ((int64_t)1 << ((int64_t)((((int32_t*)fused_nn_conv2d_subtract_add_constant_50_let)[ax3] + 31) - 1)))) >> ((int64_t)(((int32_t*)fused_nn_conv2d_subtract_add_constant_50_let)[ax3] + 31)))) - 1;
      int32_t v__1 = (v_) < (127) ? (v_) : (127);
      T_cast[((ax0_ax1_fused_ax2_fused * 32) + ax3)] = ((int8_t)((v__1) > (-128) ? (v__1) : (-128)));
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_subtract_cas_c93f40e30d1c190e_(int8_t* p0, int8_t* T_cast, uint8_t* global_const_workspace_4_var, uint8_t* global_workspace_5_var) {
  void* fused_nn_conv2d_subtract_add_constant_2_let = (&(global_const_workspace_4_var[782304]));
  void* fused_nn_conv2d_subtract_add_constant_1_let = (&(global_const_workspace_4_var[782880]));
  void* fused_nn_conv2d_subtract_add_constant_let = (&(global_const_workspace_4_var[782944]));
  void* fused_nn_conv2d_constant_let = (&(global_const_workspace_4_var[783328]));
  void* fused_nn_conv2d_subtract_constant_let = (&(global_const_workspace_4_var[781792]));
  void* fused_constant_let = (&(global_const_workspace_4_var[745920]));
  void* pad_temp_let = (&(global_workspace_5_var[33808]));
  for (int32_t i0_i1_fused = 0; i0_i1_fused < 65; ++i0_i1_fused) {
    for (int32_t i2 = 0; i2 < 65; ++i2) {
      for (int32_t i3 = 0; i3 < 3; ++i3) {
        int32_t cse_var_1 = (((i0_i1_fused * 195) + (i2 * 3)) + i3);
        ((int8_t*)pad_temp_let)[cse_var_1] = p0[cse_var_1];
      }
    }
  }
  for (int32_t ax0_ax1_fused_ax2_fused = 0; ax0_ax1_fused_ax2_fused < 1024; ++ax0_ax1_fused_ax2_fused) {
    void* conv2d_nhwc_let = (&(global_workspace_5_var[46488]));
    for (int32_t ax3 = 0; ax3 < 16; ++ax3) {
      ((int32_t*)conv2d_nhwc_let)[0] = 0;
      for (int32_t ry = 0; ry < 3; ++ry) {
        for (int32_t rx = 0; rx < 3; ++rx) {
          for (int32_t rc = 0; rc < 3; ++rc) {
            ((int32_t*)conv2d_nhwc_let)[0] = (((int32_t*)conv2d_nhwc_let)[0] + (((int32_t)((int8_t*)pad_temp_let)[((((((ax0_ax1_fused_ax2_fused >> 5) * 390) + (ry * 195)) + ((ax0_ax1_fused_ax2_fused & 31) * 6)) + (rx * 3)) + rc)]) * ((int32_t)((int8_t*)fused_constant_let)[((((ry * 144) + (rx * 48)) + (rc * 16)) + ax3)])));
          }
        }
      }
      int32_t v_ = ((int32_t)(((((int64_t)((((int32_t*)conv2d_nhwc_let)[0] + ((int32_t*)fused_nn_conv2d_subtract_constant_let)[ax3]) - ((int32_t*)fused_nn_conv2d_constant_let)[ax3])) * ((int64_t)((int32_t*)fused_nn_conv2d_subtract_add_constant_let)[ax3])) + ((int64_t)1 << ((int64_t)((((int32_t*)fused_nn_conv2d_subtract_add_constant_2_let)[ax3] + 31) - 1)))) >> ((int64_t)(((int32_t*)fused_nn_conv2d_subtract_add_constant_2_let)[ax3] + 31)))) - 43;
      int32_t v__1 = (v_) < (127) ? (v_) : (127);
      int32_t v__2 = ((int32_t)(((((int64_t)((((int32_t*)conv2d_nhwc_let)[0] + ((int32_t*)fused_nn_conv2d_subtract_constant_let)[ax3]) - ((int32_t*)fused_nn_conv2d_constant_let)[ax3])) * ((int64_t)((int32_t*)fused_nn_conv2d_subtract_add_constant_let)[ax3])) + ((int64_t)1 << ((int64_t)((((int32_t*)fused_nn_conv2d_subtract_add_constant_2_let)[ax3] + 31) - 1)))) >> ((int64_t)(((int32_t*)fused_nn_conv2d_subtract_add_constant_2_let)[ax3] + 31)))) - 43;
      int32_t v__3 = (v__2) < (127) ? (v__2) : (127);
      float v__4 = (((float)(((v__3) > (-128) ? (v__3) : (-128)) + 43)) * 1.609988e-01f) + 3.000000e+00f;
      float v__5 = (v__4) < (6.000000e+00f) ? (v__4) : (6.000000e+00f);
      float v__6 = roundf(((((((float)(((v__1) > (-128) ? (v__1) : (-128)) + 43)) * 1.609988e-01f) * ((v__5) > (0.000000e+00f) ? (v__5) : (0.000000e+00f))) * 1.666667e-01f) * 9.190380e+00f)) + -1.250000e+02f;
      float v__7 = (v__6) < (1.270000e+02f) ? (v__6) : (1.270000e+02f);
      T_cast[((ax0_ax1_fused_ax2_fused * 16) + ax3)] = ((int8_t)((v__7) > (-1.280000e+02f) ? (v__7) : (-1.280000e+02f)));
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_subtract_cas_c93f40e30d1c190e__1(int8_t* p0, int8_t* T_cast, uint8_t* global_const_workspace_56_var, uint8_t* global_workspace_57_var) {
  void* fused_nn_conv2d_subtract_add_constant_38_let = (&(global_const_workspace_56_var[752880]));
  void* fused_nn_conv2d_subtract_add_constant_37_let = (&(global_const_workspace_56_var[753264]));
  void* fused_nn_conv2d_subtract_add_constant_36_let = (&(global_const_workspace_56_var[753648]));
  void* fused_nn_conv2d_constant_12_let = (&(global_const_workspace_56_var[755952]));
  void* fused_nn_conv2d_subtract_constant_12_let = (&(global_const_workspace_56_var[747888]));
  void* fused_constant_17_let = (&(global_const_workspace_56_var[617136]));
  void* pad_temp_let = (&(global_workspace_57_var[35936]));
  for (int32_t i0_i1_fused = 0; i0_i1_fused < 8; ++i0_i1_fused) {
    for (int32_t i2 = 0; i2 < 8; ++i2) {
      for (int32_t i3 = 0; i3 < 24; ++i3) {
        int32_t cse_var_1 = (((i0_i1_fused * 192) + (i2 * 24)) + i3);
        ((int8_t*)pad_temp_let)[cse_var_1] = p0[cse_var_1];
      }
    }
  }
  for (int32_t ax0_ax1_fused_ax2_fused = 0; ax0_ax1_fused_ax2_fused < 64; ++ax0_ax1_fused_ax2_fused) {
    void* conv2d_nhwc_let = (&(global_workspace_57_var[37472]));
    for (int32_t ax3 = 0; ax3 < 96; ++ax3) {
      ((int32_t*)conv2d_nhwc_let)[0] = 0;
      for (int32_t rc = 0; rc < 24; ++rc) {
        ((int32_t*)conv2d_nhwc_let)[0] = (((int32_t*)conv2d_nhwc_let)[0] + (((int32_t)((int8_t*)pad_temp_let)[((ax0_ax1_fused_ax2_fused * 24) + rc)]) * ((int32_t)((int8_t*)fused_constant_17_let)[((rc * 96) + ax3)])));
      }
      int32_t v_ = ((int32_t)(((((int64_t)((((int32_t*)conv2d_nhwc_let)[0] + ((int32_t*)fused_nn_conv2d_subtract_constant_12_let)[ax3]) - ((int32_t*)fused_nn_conv2d_constant_12_let)[ax3])) * ((int64_t)((int32_t*)fused_nn_conv2d_subtract_add_constant_36_let)[ax3])) + ((int64_t)1 << ((int64_t)((((int32_t*)fused_nn_conv2d_subtract_add_constant_38_let)[ax3] + 31) - 1)))) >> ((int64_t)(((int32_t*)fused_nn_conv2d_subtract_add_constant_38_let)[ax3] + 31)))) + 1;
      int32_t v__1 = (v_) < (127) ? (v_) : (127);
      int32_t v__2 = ((int32_t)(((((int64_t)((((int32_t*)conv2d_nhwc_let)[0] + ((int32_t*)fused_nn_conv2d_subtract_constant_12_let)[ax3]) - ((int32_t*)fused_nn_conv2d_constant_12_let)[ax3])) * ((int64_t)((int32_t*)fused_nn_conv2d_subtract_add_constant_36_let)[ax3])) + ((int64_t)1 << ((int64_t)((((int32_t*)fused_nn_conv2d_subtract_add_constant_38_let)[ax3] + 31) - 1)))) >> ((int64_t)(((int32_t*)fused_nn_conv2d_subtract_add_constant_38_let)[ax3] + 31)))) + 1;
      int32_t v__3 = (v__2) < (127) ? (v__2) : (127);
      float v__4 = (((float)(((v__3) > (-128) ? (v__3) : (-128)) - 1)) * 3.307024e-01f) + 3.000000e+00f;
      float v__5 = (v__4) < (6.000000e+00f) ? (v__4) : (6.000000e+00f);
      float v__6 = roundf(((((((float)(((v__1) > (-128) ? (v__1) : (-128)) - 1)) * 3.307024e-01f) * ((v__5) > (0.000000e+00f) ? (v__5) : (0.000000e+00f))) * 1.666667e-01f) * 6.051700e+00f)) + -1.260000e+02f;
      float v__7 = (v__6) < (1.270000e+02f) ? (v__6) : (1.270000e+02f);
      T_cast[((ax0_ax1_fused_ax2_fused * 96) + ax3)] = ((int8_t)((v__7) > (-1.280000e+02f) ? (v__7) : (-1.280000e+02f)));
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_subtract_cas_c93f40e30d1c190e__10(int8_t* p0, int32_t* T_cast, uint8_t* global_const_workspace_168_var, uint8_t* global_workspace_169_var) {
  void* fused_nn_conv2d_subtract_add_constant_107_let = (&(global_const_workspace_168_var[696880]));
  void* fused_nn_conv2d_subtract_add_constant_106_let = (&(global_const_workspace_168_var[697840]));
  void* fused_nn_conv2d_subtract_add_constant_105_let = (&(global_const_workspace_168_var[698800]));
  void* fused_nn_conv2d_subtract_constant_35_let = (&(global_const_workspace_168_var[692080]));
  void* fused_nn_conv2d_constant_37_let = (&(global_const_workspace_168_var[703600]));
  void* fused_constant_51_let = (&(global_const_workspace_168_var[539616]));
  void* PaddedInput_let = (&(global_workspace_169_var[0]));
  void* DepthwiseConv2d_let = (&(global_workspace_169_var[15600]));
  void* compute_let = (&(global_workspace_169_var[11760]));
  for (int32_t i1 = 0; i1 < 7; ++i1) {
    for (int32_t i2 = 0; i2 < 7; ++i2) {
      for (int32_t i3 = 0; i3 < 240; ++i3) {
        int32_t cse_var_1 = (((i1 * 1680) + (i2 * 240)) + i3);
        ((int8_t*)PaddedInput_let)[cse_var_1] = p0[cse_var_1];
      }
    }
  }
  for (int32_t i = 0; i < 2; ++i) {
    for (int32_t j = 0; j < 2; ++j) {
      for (int32_t c = 0; c < 240; ++c) {
        ((int32_t*)DepthwiseConv2d_let)[(((i * 480) + (j * 240)) + c)] = 0;
        for (int32_t di = 0; di < 5; ++di) {
          for (int32_t dj = 0; dj < 5; ++dj) {
            int32_t cse_var_3 = (dj * 240);
            int32_t cse_var_2 = (((i * 480) + (j * 240)) + c);
            ((int32_t*)DepthwiseConv2d_let)[cse_var_2] = (((int32_t*)DepthwiseConv2d_let)[cse_var_2] + (((int32_t)((int8_t*)PaddedInput_let)[(((((i * 3360) + (di * 1680)) + (j * 480)) + cse_var_3) + c)]) * ((int32_t)((int8_t*)fused_constant_51_let)[(((di * 1200) + cse_var_3) + c)])));
          }
        }
      }
    }
  }
  for (int32_t ax1 = 0; ax1 < 2; ++ax1) {
    for (int32_t ax2 = 0; ax2 < 2; ++ax2) {
      for (int32_t ax3 = 0; ax3 < 240; ++ax3) {
        int32_t cse_var_4 = (((ax1 * 480) + (ax2 * 240)) + ax3);
        ((int32_t*)DepthwiseConv2d_let)[cse_var_4] = (((int32_t*)DepthwiseConv2d_let)[cse_var_4] - ((int32_t*)fused_nn_conv2d_constant_37_let)[ax3]);
      }
    }
  }
  for (int32_t ax1_1 = 0; ax1_1 < 2; ++ax1_1) {
    for (int32_t ax2_1 = 0; ax2_1 < 2; ++ax2_1) {
      for (int32_t ax3_1 = 0; ax3_1 < 240; ++ax3_1) {
        int32_t cse_var_5 = (((ax1_1 * 480) + (ax2_1 * 240)) + ax3_1);
        ((int32_t*)DepthwiseConv2d_let)[cse_var_5] = (((int32_t*)DepthwiseConv2d_let)[cse_var_5] + ((int32_t*)fused_nn_conv2d_subtract_constant_35_let)[ax3_1]);
      }
    }
  }
  for (int32_t i1_1 = 0; i1_1 < 2; ++i1_1) {
    for (int32_t i2_1 = 0; i2_1 < 2; ++i2_1) {
      for (int32_t i3_1 = 0; i3_1 < 240; ++i3_1) {
        int32_t cse_var_6 = (((i1_1 * 480) + (i2_1 * 240)) + i3_1);
        ((int32_t*)DepthwiseConv2d_let)[cse_var_6] = ((int32_t)(((((int64_t)((int32_t*)DepthwiseConv2d_let)[cse_var_6]) * ((int64_t)((int32_t*)fused_nn_conv2d_subtract_add_constant_105_let)[i3_1])) + ((int64_t)1 << ((int64_t)((((int32_t*)fused_nn_conv2d_subtract_add_constant_107_let)[i3_1] + 31) - 1)))) >> ((int64_t)(((int32_t*)fused_nn_conv2d_subtract_add_constant_107_let)[i3_1] + 31))));
      }
    }
  }
  for (int32_t ax1_2 = 0; ax1_2 < 2; ++ax1_2) {
    for (int32_t ax2_2 = 0; ax2_2 < 2; ++ax2_2) {
      for (int32_t ax3_2 = 0; ax3_2 < 240; ++ax3_2) {
        int32_t cse_var_7 = (((ax1_2 * 480) + (ax2_2 * 240)) + ax3_2);
        ((int32_t*)DepthwiseConv2d_let)[cse_var_7] = (((int32_t*)DepthwiseConv2d_let)[cse_var_7] - 15);
      }
    }
  }
  for (int32_t i1_2 = 0; i1_2 < 2; ++i1_2) {
    for (int32_t i2_2 = 0; i2_2 < 2; ++i2_2) {
      for (int32_t i3_2 = 0; i3_2 < 240; ++i3_2) {
        int32_t cse_var_8 = (((i1_2 * 480) + (i2_2 * 240)) + i3_2);
        int32_t v_ = ((int32_t*)DepthwiseConv2d_let)[cse_var_8];
        int32_t v__1 = (v_) < (127) ? (v_) : (127);
        ((int32_t*)DepthwiseConv2d_let)[cse_var_8] = ((v__1) > (-128) ? (v__1) : (-128));
      }
    }
  }
  for (int32_t ax1_3 = 0; ax1_3 < 2; ++ax1_3) {
    for (int32_t ax2_3 = 0; ax2_3 < 2; ++ax2_3) {
      for (int32_t ax3_3 = 0; ax3_3 < 240; ++ax3_3) {
        int32_t cse_var_9 = (((ax1_3 * 480) + (ax2_3 * 240)) + ax3_3);
        ((int32_t*)DepthwiseConv2d_let)[cse_var_9] = (((int32_t*)DepthwiseConv2d_let)[cse_var_9] + 15);
      }
    }
  }
  for (int32_t ax1_4 = 0; ax1_4 < 2; ++ax1_4) {
    for (int32_t ax2_4 = 0; ax2_4 < 2; ++ax2_4) {
      for (int32_t ax3_4 = 0; ax3_4 < 240; ++ax3_4) {
        int32_t cse_var_10 = (((ax1_4 * 480) + (ax2_4 * 240)) + ax3_4);
        ((float*)PaddedInput_let)[cse_var_10] = ((float)((int32_t*)DepthwiseConv2d_let)[cse_var_10]);
      }
    }
  }
  for (int32_t ax1_5 = 0; ax1_5 < 2; ++ax1_5) {
    for (int32_t ax2_5 = 0; ax2_5 < 2; ++ax2_5) {
      for (int32_t ax3_5 = 0; ax3_5 < 240; ++ax3_5) {
        int32_t cse_var_11 = (((ax1_5 * 480) + (ax2_5 * 240)) + ax3_5);
        ((float*)DepthwiseConv2d_let)[cse_var_11] = (((float*)PaddedInput_let)[cse_var_11] * 1.250458e-01f);
      }
    }
  }
  for (int32_t ax1_6 = 0; ax1_6 < 2; ++ax1_6) {
    for (int32_t ax2_6 = 0; ax2_6 < 2; ++ax2_6) {
      for (int32_t ax3_6 = 0; ax3_6 < 240; ++ax3_6) {
        int32_t cse_var_12 = (((ax1_6 * 480) + (ax2_6 * 240)) + ax3_6);
        ((float*)PaddedInput_let)[cse_var_12] = (((float*)DepthwiseConv2d_let)[cse_var_12] + 3.000000e+00f);
      }
    }
  }
  for (int32_t i1_3 = 0; i1_3 < 2; ++i1_3) {
    for (int32_t i2_3 = 0; i2_3 < 2; ++i2_3) {
      for (int32_t i3_3 = 0; i3_3 < 240; ++i3_3) {
        int32_t cse_var_13 = (((i1_3 * 480) + (i2_3 * 240)) + i3_3);
        float v__2 = ((float*)PaddedInput_let)[cse_var_13];
        float v__3 = (v__2) < (6.000000e+00f) ? (v__2) : (6.000000e+00f);
        ((float*)compute_let)[cse_var_13] = ((v__3) > (0.000000e+00f) ? (v__3) : (0.000000e+00f));
      }
    }
  }
  for (int32_t ax1_7 = 0; ax1_7 < 2; ++ax1_7) {
    for (int32_t ax2_7 = 0; ax2_7 < 2; ++ax2_7) {
      for (int32_t ax3_7 = 0; ax3_7 < 240; ++ax3_7) {
        int32_t cse_var_14 = (((ax1_7 * 480) + (ax2_7 * 240)) + ax3_7);
        ((float*)compute_let)[cse_var_14] = (((float*)DepthwiseConv2d_let)[cse_var_14] * ((float*)compute_let)[cse_var_14]);
      }
    }
  }
  for (int32_t ax1_8 = 0; ax1_8 < 2; ++ax1_8) {
    for (int32_t ax2_8 = 0; ax2_8 < 2; ++ax2_8) {
      for (int32_t ax3_8 = 0; ax3_8 < 240; ++ax3_8) {
        int32_t cse_var_15 = (((ax1_8 * 480) + (ax2_8 * 240)) + ax3_8);
        ((float*)compute_let)[cse_var_15] = (((float*)compute_let)[cse_var_15] * 1.666667e-01f);
      }
    }
  }
  for (int32_t ax1_9 = 0; ax1_9 < 2; ++ax1_9) {
    for (int32_t ax2_9 = 0; ax2_9 < 2; ++ax2_9) {
      for (int32_t ax3_9 = 0; ax3_9 < 240; ++ax3_9) {
        int32_t cse_var_16 = (((ax1_9 * 480) + (ax2_9 * 240)) + ax3_9);
        ((float*)compute_let)[cse_var_16] = (((float*)compute_let)[cse_var_16] * 1.408553e+01f);
      }
    }
  }
  for (int32_t ax1_10 = 0; ax1_10 < 2; ++ax1_10) {
    for (int32_t ax2_10 = 0; ax2_10 < 2; ++ax2_10) {
      for (int32_t ax3_10 = 0; ax3_10 < 240; ++ax3_10) {
        int32_t cse_var_17 = (((ax1_10 * 480) + (ax2_10 * 240)) + ax3_10);
        ((float*)compute_let)[cse_var_17] = roundf(((float*)compute_let)[cse_var_17]);
      }
    }
  }
  for (int32_t ax1_11 = 0; ax1_11 < 2; ++ax1_11) {
    for (int32_t ax2_11 = 0; ax2_11 < 2; ++ax2_11) {
      for (int32_t ax3_11 = 0; ax3_11 < 240; ++ax3_11) {
        int32_t cse_var_18 = (((ax1_11 * 480) + (ax2_11 * 240)) + ax3_11);
        ((float*)compute_let)[cse_var_18] = (((float*)compute_let)[cse_var_18] + -1.230000e+02f);
      }
    }
  }
  for (int32_t i1_4 = 0; i1_4 < 2; ++i1_4) {
    for (int32_t i2_4 = 0; i2_4 < 2; ++i2_4) {
      for (int32_t i3_4 = 0; i3_4 < 240; ++i3_4) {
        int32_t cse_var_19 = (((i1_4 * 480) + (i2_4 * 240)) + i3_4);
        float v__4 = ((float*)compute_let)[cse_var_19];
        float v__5 = (v__4) < (1.270000e+02f) ? (v__4) : (1.270000e+02f);
        ((float*)compute_let)[cse_var_19] = ((v__5) > (-1.280000e+02f) ? (v__5) : (-1.280000e+02f));
      }
    }
  }
  for (int32_t ax1_12 = 0; ax1_12 < 2; ++ax1_12) {
    for (int32_t ax2_12 = 0; ax2_12 < 2; ++ax2_12) {
      for (int32_t ax3_12 = 0; ax3_12 < 240; ++ax3_12) {
        int32_t cse_var_20 = (((ax1_12 * 480) + (ax2_12 * 240)) + ax3_12);
        T_cast[cse_var_20] = ((int32_t)((float*)compute_let)[cse_var_20]);
      }
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_subtract_cas_c93f40e30d1c190e__11(int8_t* p0, int8_t* T_cast, uint8_t* global_const_workspace_182_var, uint8_t* global_workspace_183_var) {
  void* fused_nn_conv2d_subtract_add_constant_119_let = (&(global_const_workspace_182_var[670960]));
  void* fused_nn_conv2d_subtract_add_constant_118_let = (&(global_const_workspace_182_var[672688]));
  void* fused_nn_conv2d_subtract_add_constant_117_let = (&(global_const_workspace_182_var[674416]));
  void* fused_nn_conv2d_constant_41_let = (&(global_const_workspace_182_var[686512]));
  void* fused_nn_conv2d_subtract_constant_39_let = (&(global_const_workspace_182_var[638128]));
  void* fused_constant_56_let = (&(global_const_workspace_182_var[255744]));
  void* pad_temp_let = (&(global_workspace_183_var[54176]));
  for (int32_t i0_i1_fused = 0; i0_i1_fused < 2; ++i0_i1_fused) {
    for (int32_t i2 = 0; i2 < 2; ++i2) {
      for (int32_t i3 = 0; i3 < 72; ++i3) {
        int32_t cse_var_1 = (((i0_i1_fused * 144) + (i2 * 72)) + i3);
        ((int8_t*)pad_temp_let)[cse_var_1] = p0[cse_var_1];
      }
    }
  }
  for (int32_t ax0_ax1_fused_ax2_fused = 0; ax0_ax1_fused_ax2_fused < 4; ++ax0_ax1_fused_ax2_fused) {
    void* conv2d_nhwc_let = (&(global_workspace_183_var[54464]));
    for (int32_t ax3 = 0; ax3 < 432; ++ax3) {
      ((int32_t*)conv2d_nhwc_let)[0] = 0;
      for (int32_t rc = 0; rc < 72; ++rc) {
        ((int32_t*)conv2d_nhwc_let)[0] = (((int32_t*)conv2d_nhwc_let)[0] + (((int32_t)((int8_t*)pad_temp_let)[((ax0_ax1_fused_ax2_fused * 72) + rc)]) * ((int32_t)((int8_t*)fused_constant_56_let)[((rc * 432) + ax3)])));
      }
      int32_t v_ = ((int32_t)(((((int64_t)((((int32_t*)conv2d_nhwc_let)[0] + ((int32_t*)fused_nn_conv2d_subtract_constant_39_let)[ax3]) - ((int32_t*)fused_nn_conv2d_constant_41_let)[ax3])) * ((int64_t)((int32_t*)fused_nn_conv2d_subtract_add_constant_117_let)[ax3])) + ((int64_t)1 << ((int64_t)((((int32_t*)fused_nn_conv2d_subtract_add_constant_119_let)[ax3] + 31) - 1)))) >> ((int64_t)(((int32_t*)fused_nn_conv2d_subtract_add_constant_119_let)[ax3] + 31)))) - 18;
      int32_t v__1 = (v_) < (127) ? (v_) : (127);
      int32_t v__2 = ((int32_t)(((((int64_t)((((int32_t*)conv2d_nhwc_let)[0] + ((int32_t*)fused_nn_conv2d_subtract_constant_39_let)[ax3]) - ((int32_t*)fused_nn_conv2d_constant_41_let)[ax3])) * ((int64_t)((int32_t*)fused_nn_conv2d_subtract_add_constant_117_let)[ax3])) + ((int64_t)1 << ((int64_t)((((int32_t*)fused_nn_conv2d_subtract_add_constant_119_let)[ax3] + 31) - 1)))) >> ((int64_t)(((int32_t*)fused_nn_conv2d_subtract_add_constant_119_let)[ax3] + 31)))) - 18;
      int32_t v__3 = (v__2) < (127) ? (v__2) : (127);
      float v__4 = (((float)(((v__3) > (-128) ? (v__3) : (-128)) + 18)) * 1.290745e-01f) + 3.000000e+00f;
      float v__5 = (v__4) < (6.000000e+00f) ? (v__4) : (6.000000e+00f);
      float v__6 = roundf(((((((float)(((v__1) > (-128) ? (v__1) : (-128)) + 18)) * 1.290745e-01f) * ((v__5) > (0.000000e+00f) ? (v__5) : (0.000000e+00f))) * 1.666667e-01f) * 1.336400e+01f)) + -1.230000e+02f;
      float v__7 = (v__6) < (1.270000e+02f) ? (v__6) : (1.270000e+02f);
      T_cast[((ax0_ax1_fused_ax2_fused * 432) + ax3)] = ((int8_t)((v__7) > (-1.280000e+02f) ? (v__7) : (-1.280000e+02f)));
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_subtract_cas_c93f40e30d1c190e__12(int8_t* p0, int32_t* T_cast, uint8_t* global_const_workspace_186_var, uint8_t* global_workspace_187_var) {
  void* fused_nn_conv2d_subtract_add_constant_122_let = (&(global_const_workspace_186_var[665776]));
  void* fused_nn_conv2d_subtract_add_constant_121_let = (&(global_const_workspace_186_var[667504]));
  void* fused_nn_conv2d_subtract_add_constant_120_let = (&(global_const_workspace_186_var[669232]));
  void* fused_nn_conv2d_subtract_constant_40_let = (&(global_const_workspace_186_var[636400]));
  void* fused_nn_conv2d_constant_42_let = (&(global_const_workspace_186_var[684784]));
  void* fused_constant_57_let = (&(global_const_workspace_186_var[407856]));
  void* PaddedInput_let = (&(global_workspace_187_var[0]));
  void* DepthwiseConv2d_let = (&(global_workspace_187_var[22464]));
  void* compute_let = (&(global_workspace_187_var[15552]));
  for (int32_t i1 = 0; i1 < 6; ++i1) {
    for (int32_t i2 = 0; i2 < 6; ++i2) {
      for (int32_t i3 = 0; i3 < 432; ++i3) {
        int32_t cse_var_1 = (((i1 * 2592) + (i2 * 432)) + i3);
        ((int8_t*)PaddedInput_let)[cse_var_1] = p0[cse_var_1];
      }
    }
  }
  for (int32_t i = 0; i < 2; ++i) {
    for (int32_t j = 0; j < 2; ++j) {
      for (int32_t c = 0; c < 432; ++c) {
        ((int32_t*)DepthwiseConv2d_let)[(((i * 864) + (j * 432)) + c)] = 0;
        for (int32_t di = 0; di < 5; ++di) {
          for (int32_t dj = 0; dj < 5; ++dj) {
            int32_t cse_var_4 = (j * 432);
            int32_t cse_var_3 = (dj * 432);
            int32_t cse_var_2 = (((i * 864) + cse_var_4) + c);
            ((int32_t*)DepthwiseConv2d_let)[cse_var_2] = (((int32_t*)DepthwiseConv2d_let)[cse_var_2] + (((int32_t)((int8_t*)PaddedInput_let)[(((((i * 2592) + (di * 2592)) + cse_var_4) + cse_var_3) + c)]) * ((int32_t)((int8_t*)fused_constant_57_let)[(((di * 2160) + cse_var_3) + c)])));
          }
        }
      }
    }
  }
  for (int32_t ax1 = 0; ax1 < 2; ++ax1) {
    for (int32_t ax2 = 0; ax2 < 2; ++ax2) {
      for (int32_t ax3 = 0; ax3 < 432; ++ax3) {
        int32_t cse_var_5 = (((ax1 * 864) + (ax2 * 432)) + ax3);
        ((int32_t*)DepthwiseConv2d_let)[cse_var_5] = (((int32_t*)DepthwiseConv2d_let)[cse_var_5] - ((int32_t*)fused_nn_conv2d_constant_42_let)[ax3]);
      }
    }
  }
  for (int32_t ax1_1 = 0; ax1_1 < 2; ++ax1_1) {
    for (int32_t ax2_1 = 0; ax2_1 < 2; ++ax2_1) {
      for (int32_t ax3_1 = 0; ax3_1 < 432; ++ax3_1) {
        int32_t cse_var_6 = (((ax1_1 * 864) + (ax2_1 * 432)) + ax3_1);
        ((int32_t*)DepthwiseConv2d_let)[cse_var_6] = (((int32_t*)DepthwiseConv2d_let)[cse_var_6] + ((int32_t*)fused_nn_conv2d_subtract_constant_40_let)[ax3_1]);
      }
    }
  }
  for (int32_t i1_1 = 0; i1_1 < 2; ++i1_1) {
    for (int32_t i2_1 = 0; i2_1 < 2; ++i2_1) {
      for (int32_t i3_1 = 0; i3_1 < 432; ++i3_1) {
        int32_t cse_var_7 = (((i1_1 * 864) + (i2_1 * 432)) + i3_1);
        ((int32_t*)DepthwiseConv2d_let)[cse_var_7] = ((int32_t)(((((int64_t)((int32_t*)DepthwiseConv2d_let)[cse_var_7]) * ((int64_t)((int32_t*)fused_nn_conv2d_subtract_add_constant_120_let)[i3_1])) + ((int64_t)1 << ((int64_t)((((int32_t*)fused_nn_conv2d_subtract_add_constant_122_let)[i3_1] + 31) - 1)))) >> ((int64_t)(((int32_t*)fused_nn_conv2d_subtract_add_constant_122_let)[i3_1] + 31))));
      }
    }
  }
  for (int32_t ax1_2 = 0; ax1_2 < 2; ++ax1_2) {
    for (int32_t ax2_2 = 0; ax2_2 < 2; ++ax2_2) {
      for (int32_t ax3_2 = 0; ax3_2 < 432; ++ax3_2) {
        int32_t cse_var_8 = (((ax1_2 * 864) + (ax2_2 * 432)) + ax3_2);
        ((int32_t*)DepthwiseConv2d_let)[cse_var_8] = (((int32_t*)DepthwiseConv2d_let)[cse_var_8] - 19);
      }
    }
  }
  for (int32_t i1_2 = 0; i1_2 < 2; ++i1_2) {
    for (int32_t i2_2 = 0; i2_2 < 2; ++i2_2) {
      for (int32_t i3_2 = 0; i3_2 < 432; ++i3_2) {
        int32_t cse_var_9 = (((i1_2 * 864) + (i2_2 * 432)) + i3_2);
        int32_t v_ = ((int32_t*)DepthwiseConv2d_let)[cse_var_9];
        int32_t v__1 = (v_) < (127) ? (v_) : (127);
        ((int32_t*)DepthwiseConv2d_let)[cse_var_9] = ((v__1) > (-128) ? (v__1) : (-128));
      }
    }
  }
  for (int32_t ax1_3 = 0; ax1_3 < 2; ++ax1_3) {
    for (int32_t ax2_3 = 0; ax2_3 < 2; ++ax2_3) {
      for (int32_t ax3_3 = 0; ax3_3 < 432; ++ax3_3) {
        int32_t cse_var_10 = (((ax1_3 * 864) + (ax2_3 * 432)) + ax3_3);
        ((int32_t*)DepthwiseConv2d_let)[cse_var_10] = (((int32_t*)DepthwiseConv2d_let)[cse_var_10] + 19);
      }
    }
  }
  for (int32_t ax1_4 = 0; ax1_4 < 2; ++ax1_4) {
    for (int32_t ax2_4 = 0; ax2_4 < 2; ++ax2_4) {
      for (int32_t ax3_4 = 0; ax3_4 < 432; ++ax3_4) {
        int32_t cse_var_11 = (((ax1_4 * 864) + (ax2_4 * 432)) + ax3_4);
        ((float*)PaddedInput_let)[cse_var_11] = ((float)((int32_t*)DepthwiseConv2d_let)[cse_var_11]);
      }
    }
  }
  for (int32_t ax1_5 = 0; ax1_5 < 2; ++ax1_5) {
    for (int32_t ax2_5 = 0; ax2_5 < 2; ++ax2_5) {
      for (int32_t ax3_5 = 0; ax3_5 < 432; ++ax3_5) {
        int32_t cse_var_12 = (((ax1_5 * 864) + (ax2_5 * 432)) + ax3_5);
        ((float*)DepthwiseConv2d_let)[cse_var_12] = (((float*)PaddedInput_let)[cse_var_12] * 1.924749e-01f);
      }
    }
  }
  for (int32_t ax1_6 = 0; ax1_6 < 2; ++ax1_6) {
    for (int32_t ax2_6 = 0; ax2_6 < 2; ++ax2_6) {
      for (int32_t ax3_6 = 0; ax3_6 < 432; ++ax3_6) {
        int32_t cse_var_13 = (((ax1_6 * 864) + (ax2_6 * 432)) + ax3_6);
        ((float*)PaddedInput_let)[cse_var_13] = (((float*)DepthwiseConv2d_let)[cse_var_13] + 3.000000e+00f);
      }
    }
  }
  for (int32_t i1_3 = 0; i1_3 < 2; ++i1_3) {
    for (int32_t i2_3 = 0; i2_3 < 2; ++i2_3) {
      for (int32_t i3_3 = 0; i3_3 < 432; ++i3_3) {
        int32_t cse_var_14 = (((i1_3 * 864) + (i2_3 * 432)) + i3_3);
        float v__2 = ((float*)PaddedInput_let)[cse_var_14];
        float v__3 = (v__2) < (6.000000e+00f) ? (v__2) : (6.000000e+00f);
        ((float*)compute_let)[cse_var_14] = ((v__3) > (0.000000e+00f) ? (v__3) : (0.000000e+00f));
      }
    }
  }
  for (int32_t ax1_7 = 0; ax1_7 < 2; ++ax1_7) {
    for (int32_t ax2_7 = 0; ax2_7 < 2; ++ax2_7) {
      for (int32_t ax3_7 = 0; ax3_7 < 432; ++ax3_7) {
        int32_t cse_var_15 = (((ax1_7 * 864) + (ax2_7 * 432)) + ax3_7);
        ((float*)compute_let)[cse_var_15] = (((float*)DepthwiseConv2d_let)[cse_var_15] * ((float*)compute_let)[cse_var_15]);
      }
    }
  }
  for (int32_t ax1_8 = 0; ax1_8 < 2; ++ax1_8) {
    for (int32_t ax2_8 = 0; ax2_8 < 2; ++ax2_8) {
      for (int32_t ax3_8 = 0; ax3_8 < 432; ++ax3_8) {
        int32_t cse_var_16 = (((ax1_8 * 864) + (ax2_8 * 432)) + ax3_8);
        ((float*)compute_let)[cse_var_16] = (((float*)compute_let)[cse_var_16] * 1.666667e-01f);
      }
    }
  }
  for (int32_t ax1_9 = 0; ax1_9 < 2; ++ax1_9) {
    for (int32_t ax2_9 = 0; ax2_9 < 2; ++ax2_9) {
      for (int32_t ax3_9 = 0; ax3_9 < 432; ++ax3_9) {
        int32_t cse_var_17 = (((ax1_9 * 864) + (ax2_9 * 432)) + ax3_9);
        ((float*)compute_let)[cse_var_17] = (((float*)compute_let)[cse_var_17] * 8.947480e+00f);
      }
    }
  }
  for (int32_t ax1_10 = 0; ax1_10 < 2; ++ax1_10) {
    for (int32_t ax2_10 = 0; ax2_10 < 2; ++ax2_10) {
      for (int32_t ax3_10 = 0; ax3_10 < 432; ++ax3_10) {
        int32_t cse_var_18 = (((ax1_10 * 864) + (ax2_10 * 432)) + ax3_10);
        ((float*)compute_let)[cse_var_18] = roundf(((float*)compute_let)[cse_var_18]);
      }
    }
  }
  for (int32_t ax1_11 = 0; ax1_11 < 2; ++ax1_11) {
    for (int32_t ax2_11 = 0; ax2_11 < 2; ++ax2_11) {
      for (int32_t ax3_11 = 0; ax3_11 < 432; ++ax3_11) {
        int32_t cse_var_19 = (((ax1_11 * 864) + (ax2_11 * 432)) + ax3_11);
        ((float*)compute_let)[cse_var_19] = (((float*)compute_let)[cse_var_19] + -1.250000e+02f);
      }
    }
  }
  for (int32_t i1_4 = 0; i1_4 < 2; ++i1_4) {
    for (int32_t i2_4 = 0; i2_4 < 2; ++i2_4) {
      for (int32_t i3_4 = 0; i3_4 < 432; ++i3_4) {
        int32_t cse_var_20 = (((i1_4 * 864) + (i2_4 * 432)) + i3_4);
        float v__4 = ((float*)compute_let)[cse_var_20];
        float v__5 = (v__4) < (1.270000e+02f) ? (v__4) : (1.270000e+02f);
        ((float*)compute_let)[cse_var_20] = ((v__5) > (-1.280000e+02f) ? (v__5) : (-1.280000e+02f));
      }
    }
  }
  for (int32_t ax1_12 = 0; ax1_12 < 2; ++ax1_12) {
    for (int32_t ax2_12 = 0; ax2_12 < 2; ++ax2_12) {
      for (int32_t ax3_12 = 0; ax3_12 < 432; ++ax3_12) {
        int32_t cse_var_21 = (((ax1_12 * 864) + (ax2_12 * 432)) + ax3_12);
        T_cast[cse_var_21] = ((int32_t)((float*)compute_let)[cse_var_21]);
      }
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_subtract_cas_c93f40e30d1c190e__13(int8_t* p0, int8_t* T_cast, uint8_t* global_const_workspace_200_var, uint8_t* global_workspace_201_var) {
  void* fused_nn_conv2d_subtract_add_constant_131_let = (&(global_const_workspace_200_var[655408]));
  void* fused_nn_conv2d_subtract_add_constant_130_let = (&(global_const_workspace_200_var[657136]));
  void* fused_nn_conv2d_subtract_add_constant_129_let = (&(global_const_workspace_200_var[658864]));
  void* fused_nn_conv2d_constant_45_let = (&(global_const_workspace_200_var[681328]));
  void* fused_nn_conv2d_subtract_constant_43_let = (&(global_const_workspace_200_var[632944]));
  void* fused_constant_61_let = (&(global_const_workspace_200_var[224640]));
  void* pad_temp_let = (&(global_workspace_201_var[53888]));
  for (int32_t i0_i1_fused = 0; i0_i1_fused < 2; ++i0_i1_fused) {
    for (int32_t i2 = 0; i2 < 2; ++i2) {
      for (int32_t i3 = 0; i3 < 72; ++i3) {
        int32_t cse_var_1 = (((i0_i1_fused * 144) + (i2 * 72)) + i3);
        ((int8_t*)pad_temp_let)[cse_var_1] = p0[cse_var_1];
      }
    }
  }
  for (int32_t ax0_ax1_fused_ax2_fused = 0; ax0_ax1_fused_ax2_fused < 4; ++ax0_ax1_fused_ax2_fused) {
    void* conv2d_nhwc_let = (&(global_workspace_201_var[54176]));
    for (int32_t ax3 = 0; ax3 < 432; ++ax3) {
      ((int32_t*)conv2d_nhwc_let)[0] = 0;
      for (int32_t rc = 0; rc < 72; ++rc) {
        ((int32_t*)conv2d_nhwc_let)[0] = (((int32_t*)conv2d_nhwc_let)[0] + (((int32_t)((int8_t*)pad_temp_let)[((ax0_ax1_fused_ax2_fused * 72) + rc)]) * ((int32_t)((int8_t*)fused_constant_61_let)[((rc * 432) + ax3)])));
      }
      int32_t v_ = ((int32_t)(((((int64_t)((((int32_t*)conv2d_nhwc_let)[0] + ((int32_t*)fused_nn_conv2d_subtract_constant_43_let)[ax3]) - ((int32_t*)fused_nn_conv2d_constant_45_let)[ax3])) * ((int64_t)((int32_t*)fused_nn_conv2d_subtract_add_constant_129_let)[ax3])) + ((int64_t)1 << ((int64_t)((((int32_t*)fused_nn_conv2d_subtract_add_constant_131_let)[ax3] + 31) - 1)))) >> ((int64_t)(((int32_t*)fused_nn_conv2d_subtract_add_constant_131_let)[ax3] + 31)))) - 35;
      int32_t v__1 = (v_) < (127) ? (v_) : (127);
      int32_t v__2 = ((int32_t)(((((int64_t)((((int32_t*)conv2d_nhwc_let)[0] + ((int32_t*)fused_nn_conv2d_subtract_constant_43_let)[ax3]) - ((int32_t*)fused_nn_conv2d_constant_45_let)[ax3])) * ((int64_t)((int32_t*)fused_nn_conv2d_subtract_add_constant_129_let)[ax3])) + ((int64_t)1 << ((int64_t)((((int32_t*)fused_nn_conv2d_subtract_add_constant_131_let)[ax3] + 31) - 1)))) >> ((int64_t)(((int32_t*)fused_nn_conv2d_subtract_add_constant_131_let)[ax3] + 31)))) - 35;
      int32_t v__3 = (v__2) < (127) ? (v__2) : (127);
      float v__4 = (((float)(((v__3) > (-128) ? (v__3) : (-128)) + 35)) * 5.545549e-01f) + 3.000000e+00f;
      float v__5 = (v__4) < (6.000000e+00f) ? (v__4) : (6.000000e+00f);
      float v__6 = roundf(((((((float)(((v__1) > (-128) ? (v__1) : (-128)) + 35)) * 5.545549e-01f) * ((v__5) > (0.000000e+00f) ? (v__5) : (0.000000e+00f))) * 1.666667e-01f) * 2.824722e+00f)) + -1.270000e+02f;
      float v__7 = (v__6) < (1.270000e+02f) ? (v__6) : (1.270000e+02f);
      T_cast[((ax0_ax1_fused_ax2_fused * 432) + ax3)] = ((int8_t)((v__7) > (-1.280000e+02f) ? (v__7) : (-1.280000e+02f)));
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_subtract_cas_c93f40e30d1c190e__14(int8_t* p0, int32_t* T_cast, uint8_t* global_const_workspace_204_var, uint8_t* global_workspace_205_var) {
  void* fused_nn_conv2d_subtract_add_constant_134_let = (&(global_const_workspace_204_var[650224]));
  void* fused_nn_conv2d_subtract_add_constant_133_let = (&(global_const_workspace_204_var[651952]));
  void* fused_nn_conv2d_subtract_add_constant_132_let = (&(global_const_workspace_204_var[653680]));
  void* fused_nn_conv2d_subtract_constant_44_let = (&(global_const_workspace_204_var[631216]));
  void* fused_nn_conv2d_constant_46_let = (&(global_const_workspace_204_var[679600]));
  void* fused_constant_62_let = (&(global_const_workspace_204_var[397056]));
  void* PaddedInput_let = (&(global_workspace_205_var[0]));
  void* DepthwiseConv2d_let = (&(global_workspace_205_var[22464]));
  void* compute_let = (&(global_workspace_205_var[15552]));
  for (int32_t i1 = 0; i1 < 6; ++i1) {
    for (int32_t i2 = 0; i2 < 6; ++i2) {
      for (int32_t i3 = 0; i3 < 432; ++i3) {
        int32_t cse_var_1 = (((i1 * 2592) + (i2 * 432)) + i3);
        ((int8_t*)PaddedInput_let)[cse_var_1] = p0[cse_var_1];
      }
    }
  }
  for (int32_t i = 0; i < 2; ++i) {
    for (int32_t j = 0; j < 2; ++j) {
      for (int32_t c = 0; c < 432; ++c) {
        ((int32_t*)DepthwiseConv2d_let)[(((i * 864) + (j * 432)) + c)] = 0;
        for (int32_t di = 0; di < 5; ++di) {
          for (int32_t dj = 0; dj < 5; ++dj) {
            int32_t cse_var_4 = (j * 432);
            int32_t cse_var_3 = (dj * 432);
            int32_t cse_var_2 = (((i * 864) + cse_var_4) + c);
            ((int32_t*)DepthwiseConv2d_let)[cse_var_2] = (((int32_t*)DepthwiseConv2d_let)[cse_var_2] + (((int32_t)((int8_t*)PaddedInput_let)[(((((i * 2592) + (di * 2592)) + cse_var_4) + cse_var_3) + c)]) * ((int32_t)((int8_t*)fused_constant_62_let)[(((di * 2160) + cse_var_3) + c)])));
          }
        }
      }
    }
  }
  for (int32_t ax1 = 0; ax1 < 2; ++ax1) {
    for (int32_t ax2 = 0; ax2 < 2; ++ax2) {
      for (int32_t ax3 = 0; ax3 < 432; ++ax3) {
        int32_t cse_var_5 = (((ax1 * 864) + (ax2 * 432)) + ax3);
        ((int32_t*)DepthwiseConv2d_let)[cse_var_5] = (((int32_t*)DepthwiseConv2d_let)[cse_var_5] - ((int32_t*)fused_nn_conv2d_constant_46_let)[ax3]);
      }
    }
  }
  for (int32_t ax1_1 = 0; ax1_1 < 2; ++ax1_1) {
    for (int32_t ax2_1 = 0; ax2_1 < 2; ++ax2_1) {
      for (int32_t ax3_1 = 0; ax3_1 < 432; ++ax3_1) {
        int32_t cse_var_6 = (((ax1_1 * 864) + (ax2_1 * 432)) + ax3_1);
        ((int32_t*)DepthwiseConv2d_let)[cse_var_6] = (((int32_t*)DepthwiseConv2d_let)[cse_var_6] + ((int32_t*)fused_nn_conv2d_subtract_constant_44_let)[ax3_1]);
      }
    }
  }
  for (int32_t i1_1 = 0; i1_1 < 2; ++i1_1) {
    for (int32_t i2_1 = 0; i2_1 < 2; ++i2_1) {
      for (int32_t i3_1 = 0; i3_1 < 432; ++i3_1) {
        int32_t cse_var_7 = (((i1_1 * 864) + (i2_1 * 432)) + i3_1);
        ((int32_t*)DepthwiseConv2d_let)[cse_var_7] = ((int32_t)((((((int64_t)((int32_t*)DepthwiseConv2d_let)[cse_var_7]) << ((int64_t)((int32_t*)fused_nn_conv2d_subtract_add_constant_133_let)[i3_1])) * ((int64_t)((int32_t*)fused_nn_conv2d_subtract_add_constant_132_let)[i3_1])) + ((int64_t)1 << ((int64_t)((((int32_t*)fused_nn_conv2d_subtract_add_constant_134_let)[i3_1] + 31) - 1)))) >> ((int64_t)(((int32_t*)fused_nn_conv2d_subtract_add_constant_134_let)[i3_1] + 31))));
      }
    }
  }
  for (int32_t ax1_2 = 0; ax1_2 < 2; ++ax1_2) {
    for (int32_t ax2_2 = 0; ax2_2 < 2; ++ax2_2) {
      for (int32_t ax3_2 = 0; ax3_2 < 432; ++ax3_2) {
        int32_t cse_var_8 = (((ax1_2 * 864) + (ax2_2 * 432)) + ax3_2);
        ((int32_t*)DepthwiseConv2d_let)[cse_var_8] = (((int32_t*)DepthwiseConv2d_let)[cse_var_8] - 31);
      }
    }
  }
  for (int32_t i1_2 = 0; i1_2 < 2; ++i1_2) {
    for (int32_t i2_2 = 0; i2_2 < 2; ++i2_2) {
      for (int32_t i3_2 = 0; i3_2 < 432; ++i3_2) {
        int32_t cse_var_9 = (((i1_2 * 864) + (i2_2 * 432)) + i3_2);
        int32_t v_ = ((int32_t*)DepthwiseConv2d_let)[cse_var_9];
        int32_t v__1 = (v_) < (127) ? (v_) : (127);
        ((int32_t*)DepthwiseConv2d_let)[cse_var_9] = ((v__1) > (-128) ? (v__1) : (-128));
      }
    }
  }
  for (int32_t ax1_3 = 0; ax1_3 < 2; ++ax1_3) {
    for (int32_t ax2_3 = 0; ax2_3 < 2; ++ax2_3) {
      for (int32_t ax3_3 = 0; ax3_3 < 432; ++ax3_3) {
        int32_t cse_var_10 = (((ax1_3 * 864) + (ax2_3 * 432)) + ax3_3);
        ((int32_t*)DepthwiseConv2d_let)[cse_var_10] = (((int32_t*)DepthwiseConv2d_let)[cse_var_10] + 31);
      }
    }
  }
  for (int32_t ax1_4 = 0; ax1_4 < 2; ++ax1_4) {
    for (int32_t ax2_4 = 0; ax2_4 < 2; ++ax2_4) {
      for (int32_t ax3_4 = 0; ax3_4 < 432; ++ax3_4) {
        int32_t cse_var_11 = (((ax1_4 * 864) + (ax2_4 * 432)) + ax3_4);
        ((float*)PaddedInput_let)[cse_var_11] = ((float)((int32_t*)DepthwiseConv2d_let)[cse_var_11]);
      }
    }
  }
  for (int32_t ax1_5 = 0; ax1_5 < 2; ++ax1_5) {
    for (int32_t ax2_5 = 0; ax2_5 < 2; ++ax2_5) {
      for (int32_t ax3_5 = 0; ax3_5 < 432; ++ax3_5) {
        int32_t cse_var_12 = (((ax1_5 * 864) + (ax2_5 * 432)) + ax3_5);
        ((float*)DepthwiseConv2d_let)[cse_var_12] = (((float*)PaddedInput_let)[cse_var_12] * 3.832174e-01f);
      }
    }
  }
  for (int32_t ax1_6 = 0; ax1_6 < 2; ++ax1_6) {
    for (int32_t ax2_6 = 0; ax2_6 < 2; ++ax2_6) {
      for (int32_t ax3_6 = 0; ax3_6 < 432; ++ax3_6) {
        int32_t cse_var_13 = (((ax1_6 * 864) + (ax2_6 * 432)) + ax3_6);
        ((float*)PaddedInput_let)[cse_var_13] = (((float*)DepthwiseConv2d_let)[cse_var_13] + 3.000000e+00f);
      }
    }
  }
  for (int32_t i1_3 = 0; i1_3 < 2; ++i1_3) {
    for (int32_t i2_3 = 0; i2_3 < 2; ++i2_3) {
      for (int32_t i3_3 = 0; i3_3 < 432; ++i3_3) {
        int32_t cse_var_14 = (((i1_3 * 864) + (i2_3 * 432)) + i3_3);
        float v__2 = ((float*)PaddedInput_let)[cse_var_14];
        float v__3 = (v__2) < (6.000000e+00f) ? (v__2) : (6.000000e+00f);
        ((float*)compute_let)[cse_var_14] = ((v__3) > (0.000000e+00f) ? (v__3) : (0.000000e+00f));
      }
    }
  }
  for (int32_t ax1_7 = 0; ax1_7 < 2; ++ax1_7) {
    for (int32_t ax2_7 = 0; ax2_7 < 2; ++ax2_7) {
      for (int32_t ax3_7 = 0; ax3_7 < 432; ++ax3_7) {
        int32_t cse_var_15 = (((ax1_7 * 864) + (ax2_7 * 432)) + ax3_7);
        ((float*)compute_let)[cse_var_15] = (((float*)DepthwiseConv2d_let)[cse_var_15] * ((float*)compute_let)[cse_var_15]);
      }
    }
  }
  for (int32_t ax1_8 = 0; ax1_8 < 2; ++ax1_8) {
    for (int32_t ax2_8 = 0; ax2_8 < 2; ++ax2_8) {
      for (int32_t ax3_8 = 0; ax3_8 < 432; ++ax3_8) {
        int32_t cse_var_16 = (((ax1_8 * 864) + (ax2_8 * 432)) + ax3_8);
        ((float*)compute_let)[cse_var_16] = (((float*)compute_let)[cse_var_16] * 1.666667e-01f);
      }
    }
  }
  for (int32_t ax1_9 = 0; ax1_9 < 2; ++ax1_9) {
    for (int32_t ax2_9 = 0; ax2_9 < 2; ++ax2_9) {
      for (int32_t ax3_9 = 0; ax3_9 < 432; ++ax3_9) {
        int32_t cse_var_17 = (((ax1_9 * 864) + (ax2_9 * 432)) + ax3_9);
        ((float*)compute_let)[cse_var_17] = (((float*)compute_let)[cse_var_17] * 4.185743e+00f);
      }
    }
  }
  for (int32_t ax1_10 = 0; ax1_10 < 2; ++ax1_10) {
    for (int32_t ax2_10 = 0; ax2_10 < 2; ++ax2_10) {
      for (int32_t ax3_10 = 0; ax3_10 < 432; ++ax3_10) {
        int32_t cse_var_18 = (((ax1_10 * 864) + (ax2_10 * 432)) + ax3_10);
        ((float*)compute_let)[cse_var_18] = roundf(((float*)compute_let)[cse_var_18]);
      }
    }
  }
  for (int32_t ax1_11 = 0; ax1_11 < 2; ++ax1_11) {
    for (int32_t ax2_11 = 0; ax2_11 < 2; ++ax2_11) {
      for (int32_t ax3_11 = 0; ax3_11 < 432; ++ax3_11) {
        int32_t cse_var_19 = (((ax1_11 * 864) + (ax2_11 * 432)) + ax3_11);
        ((float*)compute_let)[cse_var_19] = (((float*)compute_let)[cse_var_19] + -1.260000e+02f);
      }
    }
  }
  for (int32_t i1_4 = 0; i1_4 < 2; ++i1_4) {
    for (int32_t i2_4 = 0; i2_4 < 2; ++i2_4) {
      for (int32_t i3_4 = 0; i3_4 < 432; ++i3_4) {
        int32_t cse_var_20 = (((i1_4 * 864) + (i2_4 * 432)) + i3_4);
        float v__4 = ((float*)compute_let)[cse_var_20];
        float v__5 = (v__4) < (1.270000e+02f) ? (v__4) : (1.270000e+02f);
        ((float*)compute_let)[cse_var_20] = ((v__5) > (-1.280000e+02f) ? (v__5) : (-1.280000e+02f));
      }
    }
  }
  for (int32_t ax1_12 = 0; ax1_12 < 2; ++ax1_12) {
    for (int32_t ax2_12 = 0; ax2_12 < 2; ++ax2_12) {
      for (int32_t ax3_12 = 0; ax3_12 < 432; ++ax3_12) {
        int32_t cse_var_21 = (((ax1_12 * 864) + (ax2_12 * 432)) + ax3_12);
        T_cast[cse_var_21] = ((int32_t)((float*)compute_let)[cse_var_21]);
      }
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_subtract_cas_c93f40e30d1c190e__15(int8_t* p0, int32_t* T_cast, uint8_t* global_const_workspace_216_var, uint8_t* global_workspace_217_var) {
  void* fused_nn_conv2d_subtract_add_constant_143_let = (&(global_const_workspace_216_var[639856]));
  void* fused_nn_conv2d_subtract_add_constant_142_let = (&(global_const_workspace_216_var[641584]));
  void* fused_nn_conv2d_subtract_add_constant_141_let = (&(global_const_workspace_216_var[643312]));
  void* fused_nn_conv2d_constant_49_let = (&(global_const_workspace_216_var[676144]));
  void* fused_nn_conv2d_subtract_constant_47_let = (&(global_const_workspace_216_var[627760]));
  void* fused_constant_66_let = (&(global_const_workspace_216_var[193536]));
  void* pad_temp_let = (&(global_workspace_217_var[54176]));
  for (int32_t i0_i1_fused = 0; i0_i1_fused < 2; ++i0_i1_fused) {
    for (int32_t i2 = 0; i2 < 2; ++i2) {
      for (int32_t i3 = 0; i3 < 72; ++i3) {
        int32_t cse_var_1 = (((i0_i1_fused * 144) + (i2 * 72)) + i3);
        ((int8_t*)pad_temp_let)[cse_var_1] = p0[cse_var_1];
      }
    }
  }
  for (int32_t ax0_ax1_fused_ax2_fused = 0; ax0_ax1_fused_ax2_fused < 4; ++ax0_ax1_fused_ax2_fused) {
    void* conv2d_nhwc_let = (&(global_workspace_217_var[54464]));
    for (int32_t ax3 = 0; ax3 < 432; ++ax3) {
      ((int32_t*)conv2d_nhwc_let)[0] = 0;
      for (int32_t rc = 0; rc < 72; ++rc) {
        ((int32_t*)conv2d_nhwc_let)[0] = (((int32_t*)conv2d_nhwc_let)[0] + (((int32_t)((int8_t*)pad_temp_let)[((ax0_ax1_fused_ax2_fused * 72) + rc)]) * ((int32_t)((int8_t*)fused_constant_66_let)[((rc * 432) + ax3)])));
      }
      int32_t v_ = ((int32_t)(((((int64_t)((((int32_t*)conv2d_nhwc_let)[0] + ((int32_t*)fused_nn_conv2d_subtract_constant_47_let)[ax3]) - ((int32_t*)fused_nn_conv2d_constant_49_let)[ax3])) * ((int64_t)((int32_t*)fused_nn_conv2d_subtract_add_constant_141_let)[ax3])) + ((int64_t)1 << ((int64_t)((((int32_t*)fused_nn_conv2d_subtract_add_constant_143_let)[ax3] + 31) - 1)))) >> ((int64_t)(((int32_t*)fused_nn_conv2d_subtract_add_constant_143_let)[ax3] + 31)))) + 95;
      int32_t v__1 = (v_) < (127) ? (v_) : (127);
      int32_t v__2 = ((int32_t)(((((int64_t)((((int32_t*)conv2d_nhwc_let)[0] + ((int32_t*)fused_nn_conv2d_subtract_constant_47_let)[ax3]) - ((int32_t*)fused_nn_conv2d_constant_49_let)[ax3])) * ((int64_t)((int32_t*)fused_nn_conv2d_subtract_add_constant_141_let)[ax3])) + ((int64_t)1 << ((int64_t)((((int32_t*)fused_nn_conv2d_subtract_add_constant_143_let)[ax3] + 31) - 1)))) >> ((int64_t)(((int32_t*)fused_nn_conv2d_subtract_add_constant_143_let)[ax3] + 31)))) + 95;
      int32_t v__3 = (v__2) < (127) ? (v__2) : (127);
      float v__4 = (((float)(((v__3) > (-128) ? (v__3) : (-128)) - 95)) * 2.704321e+00f) + 3.000000e+00f;
      float v__5 = (v__4) < (6.000000e+00f) ? (v__4) : (6.000000e+00f);
      float v__6 = roundf(((((((float)(((v__1) > (-128) ? (v__1) : (-128)) - 95)) * 2.704321e+00f) * ((v__5) > (0.000000e+00f) ? (v__5) : (0.000000e+00f))) * 1.666667e-01f) * 2.976470e+00f)) + -1.270000e+02f;
      float v__7 = (v__6) < (1.270000e+02f) ? (v__6) : (1.270000e+02f);
      T_cast[((ax0_ax1_fused_ax2_fused * 432) + ax3)] = ((int32_t)((v__7) > (-1.280000e+02f) ? (v__7) : (-1.280000e+02f)));
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_subtract_cas_c93f40e30d1c190e__2(int8_t* p0, int32_t* T_cast, uint8_t* global_const_workspace_60_var, uint8_t* global_workspace_61_var) {
  void* fused_nn_conv2d_subtract_add_constant_41_let = (&(global_const_workspace_60_var[751728]));
  void* fused_nn_conv2d_subtract_add_constant_40_let = (&(global_const_workspace_60_var[752112]));
  void* fused_nn_conv2d_subtract_add_constant_39_let = (&(global_const_workspace_60_var[752496]));
  void* fused_nn_conv2d_subtract_constant_13_let = (&(global_const_workspace_60_var[747504]));
  void* fused_nn_conv2d_constant_13_let = (&(global_const_workspace_60_var[755568]));
  void* fused_constant_18_let = (&(global_const_workspace_60_var[605520]));
  void* PaddedInput_let = (&(global_workspace_61_var[0]));
  void* DepthwiseConv2d_let = (&(global_workspace_61_var[17760]));
  void* compute_let = (&(global_workspace_61_var[11616]));
  for (int32_t i1 = 0; i1 < 11; ++i1) {
    for (int32_t i2 = 0; i2 < 11; ++i2) {
      for (int32_t i3 = 0; i3 < 96; ++i3) {
        int32_t cse_var_1 = (((i1 * 1056) + (i2 * 96)) + i3);
        ((int8_t*)PaddedInput_let)[cse_var_1] = p0[cse_var_1];
      }
    }
  }
  for (int32_t i = 0; i < 4; ++i) {
    for (int32_t j = 0; j < 4; ++j) {
      for (int32_t c = 0; c < 96; ++c) {
        ((int32_t*)DepthwiseConv2d_let)[(((i * 384) + (j * 96)) + c)] = 0;
        for (int32_t di = 0; di < 5; ++di) {
          for (int32_t dj = 0; dj < 5; ++dj) {
            int32_t cse_var_3 = (dj * 96);
            int32_t cse_var_2 = (((i * 384) + (j * 96)) + c);
            ((int32_t*)DepthwiseConv2d_let)[cse_var_2] = (((int32_t*)DepthwiseConv2d_let)[cse_var_2] + (((int32_t)((int8_t*)PaddedInput_let)[(((((i * 2112) + (di * 1056)) + (j * 192)) + cse_var_3) + c)]) * ((int32_t)((int8_t*)fused_constant_18_let)[(((di * 480) + cse_var_3) + c)])));
          }
        }
      }
    }
  }
  for (int32_t ax1 = 0; ax1 < 4; ++ax1) {
    for (int32_t ax2 = 0; ax2 < 4; ++ax2) {
      for (int32_t ax3 = 0; ax3 < 96; ++ax3) {
        int32_t cse_var_4 = (((ax1 * 384) + (ax2 * 96)) + ax3);
        ((int32_t*)DepthwiseConv2d_let)[cse_var_4] = (((int32_t*)DepthwiseConv2d_let)[cse_var_4] - ((int32_t*)fused_nn_conv2d_constant_13_let)[ax3]);
      }
    }
  }
  for (int32_t ax1_1 = 0; ax1_1 < 4; ++ax1_1) {
    for (int32_t ax2_1 = 0; ax2_1 < 4; ++ax2_1) {
      for (int32_t ax3_1 = 0; ax3_1 < 96; ++ax3_1) {
        int32_t cse_var_5 = (((ax1_1 * 384) + (ax2_1 * 96)) + ax3_1);
        ((int32_t*)DepthwiseConv2d_let)[cse_var_5] = (((int32_t*)DepthwiseConv2d_let)[cse_var_5] + ((int32_t*)fused_nn_conv2d_subtract_constant_13_let)[ax3_1]);
      }
    }
  }
  for (int32_t i1_1 = 0; i1_1 < 4; ++i1_1) {
    for (int32_t i2_1 = 0; i2_1 < 4; ++i2_1) {
      for (int32_t i3_1 = 0; i3_1 < 96; ++i3_1) {
        int32_t cse_var_6 = (((i1_1 * 384) + (i2_1 * 96)) + i3_1);
        ((int32_t*)DepthwiseConv2d_let)[cse_var_6] = ((int32_t)(((((int64_t)((int32_t*)DepthwiseConv2d_let)[cse_var_6]) * ((int64_t)((int32_t*)fused_nn_conv2d_subtract_add_constant_39_let)[i3_1])) + ((int64_t)1 << ((int64_t)((((int32_t*)fused_nn_conv2d_subtract_add_constant_41_let)[i3_1] + 31) - 1)))) >> ((int64_t)(((int32_t*)fused_nn_conv2d_subtract_add_constant_41_let)[i3_1] + 31))));
      }
    }
  }
  for (int32_t ax1_2 = 0; ax1_2 < 4; ++ax1_2) {
    for (int32_t ax2_2 = 0; ax2_2 < 4; ++ax2_2) {
      for (int32_t ax3_2 = 0; ax3_2 < 96; ++ax3_2) {
        int32_t cse_var_7 = (((ax1_2 * 384) + (ax2_2 * 96)) + ax3_2);
        ((int32_t*)DepthwiseConv2d_let)[cse_var_7] = (((int32_t*)DepthwiseConv2d_let)[cse_var_7] + 3);
      }
    }
  }
  for (int32_t i1_2 = 0; i1_2 < 4; ++i1_2) {
    for (int32_t i2_2 = 0; i2_2 < 4; ++i2_2) {
      for (int32_t i3_2 = 0; i3_2 < 96; ++i3_2) {
        int32_t cse_var_8 = (((i1_2 * 384) + (i2_2 * 96)) + i3_2);
        int32_t v_ = ((int32_t*)DepthwiseConv2d_let)[cse_var_8];
        int32_t v__1 = (v_) < (127) ? (v_) : (127);
        ((int32_t*)DepthwiseConv2d_let)[cse_var_8] = ((v__1) > (-128) ? (v__1) : (-128));
      }
    }
  }
  for (int32_t ax1_3 = 0; ax1_3 < 4; ++ax1_3) {
    for (int32_t ax2_3 = 0; ax2_3 < 4; ++ax2_3) {
      for (int32_t ax3_3 = 0; ax3_3 < 96; ++ax3_3) {
        int32_t cse_var_9 = (((ax1_3 * 384) + (ax2_3 * 96)) + ax3_3);
        ((int32_t*)DepthwiseConv2d_let)[cse_var_9] = (((int32_t*)DepthwiseConv2d_let)[cse_var_9] - 3);
      }
    }
  }
  for (int32_t ax1_4 = 0; ax1_4 < 4; ++ax1_4) {
    for (int32_t ax2_4 = 0; ax2_4 < 4; ++ax2_4) {
      for (int32_t ax3_4 = 0; ax3_4 < 96; ++ax3_4) {
        int32_t cse_var_10 = (((ax1_4 * 384) + (ax2_4 * 96)) + ax3_4);
        ((float*)PaddedInput_let)[cse_var_10] = ((float)((int32_t*)DepthwiseConv2d_let)[cse_var_10]);
      }
    }
  }
  for (int32_t ax1_5 = 0; ax1_5 < 4; ++ax1_5) {
    for (int32_t ax2_5 = 0; ax2_5 < 4; ++ax2_5) {
      for (int32_t ax3_5 = 0; ax3_5 < 96; ++ax3_5) {
        int32_t cse_var_11 = (((ax1_5 * 384) + (ax2_5 * 96)) + ax3_5);
        ((float*)DepthwiseConv2d_let)[cse_var_11] = (((float*)PaddedInput_let)[cse_var_11] * 2.172156e-01f);
      }
    }
  }
  for (int32_t ax1_6 = 0; ax1_6 < 4; ++ax1_6) {
    for (int32_t ax2_6 = 0; ax2_6 < 4; ++ax2_6) {
      for (int32_t ax3_6 = 0; ax3_6 < 96; ++ax3_6) {
        int32_t cse_var_12 = (((ax1_6 * 384) + (ax2_6 * 96)) + ax3_6);
        ((float*)PaddedInput_let)[cse_var_12] = (((float*)DepthwiseConv2d_let)[cse_var_12] + 3.000000e+00f);
      }
    }
  }
  for (int32_t i1_3 = 0; i1_3 < 4; ++i1_3) {
    for (int32_t i2_3 = 0; i2_3 < 4; ++i2_3) {
      for (int32_t i3_3 = 0; i3_3 < 96; ++i3_3) {
        int32_t cse_var_13 = (((i1_3 * 384) + (i2_3 * 96)) + i3_3);
        float v__2 = ((float*)PaddedInput_let)[cse_var_13];
        float v__3 = (v__2) < (6.000000e+00f) ? (v__2) : (6.000000e+00f);
        ((float*)compute_let)[cse_var_13] = ((v__3) > (0.000000e+00f) ? (v__3) : (0.000000e+00f));
      }
    }
  }
  for (int32_t ax1_7 = 0; ax1_7 < 4; ++ax1_7) {
    for (int32_t ax2_7 = 0; ax2_7 < 4; ++ax2_7) {
      for (int32_t ax3_7 = 0; ax3_7 < 96; ++ax3_7) {
        int32_t cse_var_14 = (((ax1_7 * 384) + (ax2_7 * 96)) + ax3_7);
        ((float*)compute_let)[cse_var_14] = (((float*)DepthwiseConv2d_let)[cse_var_14] * ((float*)compute_let)[cse_var_14]);
      }
    }
  }
  for (int32_t ax1_8 = 0; ax1_8 < 4; ++ax1_8) {
    for (int32_t ax2_8 = 0; ax2_8 < 4; ++ax2_8) {
      for (int32_t ax3_8 = 0; ax3_8 < 96; ++ax3_8) {
        int32_t cse_var_15 = (((ax1_8 * 384) + (ax2_8 * 96)) + ax3_8);
        ((float*)compute_let)[cse_var_15] = (((float*)compute_let)[cse_var_15] * 1.666667e-01f);
      }
    }
  }
  for (int32_t ax1_9 = 0; ax1_9 < 4; ++ax1_9) {
    for (int32_t ax2_9 = 0; ax2_9 < 4; ++ax2_9) {
      for (int32_t ax3_9 = 0; ax3_9 < 96; ++ax3_9) {
        int32_t cse_var_16 = (((ax1_9 * 384) + (ax2_9 * 96)) + ax3_9);
        ((float*)compute_let)[cse_var_16] = (((float*)compute_let)[cse_var_16] * 9.332091e+00f);
      }
    }
  }
  for (int32_t ax1_10 = 0; ax1_10 < 4; ++ax1_10) {
    for (int32_t ax2_10 = 0; ax2_10 < 4; ++ax2_10) {
      for (int32_t ax3_10 = 0; ax3_10 < 96; ++ax3_10) {
        int32_t cse_var_17 = (((ax1_10 * 384) + (ax2_10 * 96)) + ax3_10);
        ((float*)compute_let)[cse_var_17] = roundf(((float*)compute_let)[cse_var_17]);
      }
    }
  }
  for (int32_t ax1_11 = 0; ax1_11 < 4; ++ax1_11) {
    for (int32_t ax2_11 = 0; ax2_11 < 4; ++ax2_11) {
      for (int32_t ax3_11 = 0; ax3_11 < 96; ++ax3_11) {
        int32_t cse_var_18 = (((ax1_11 * 384) + (ax2_11 * 96)) + ax3_11);
        ((float*)compute_let)[cse_var_18] = (((float*)compute_let)[cse_var_18] + -1.250000e+02f);
      }
    }
  }
  for (int32_t i1_4 = 0; i1_4 < 4; ++i1_4) {
    for (int32_t i2_4 = 0; i2_4 < 4; ++i2_4) {
      for (int32_t i3_4 = 0; i3_4 < 96; ++i3_4) {
        int32_t cse_var_19 = (((i1_4 * 384) + (i2_4 * 96)) + i3_4);
        float v__4 = ((float*)compute_let)[cse_var_19];
        float v__5 = (v__4) < (1.270000e+02f) ? (v__4) : (1.270000e+02f);
        ((float*)compute_let)[cse_var_19] = ((v__5) > (-1.280000e+02f) ? (v__5) : (-1.280000e+02f));
      }
    }
  }
  for (int32_t ax1_12 = 0; ax1_12 < 4; ++ax1_12) {
    for (int32_t ax2_12 = 0; ax2_12 < 4; ++ax2_12) {
      for (int32_t ax3_12 = 0; ax3_12 < 96; ++ax3_12) {
        int32_t cse_var_20 = (((ax1_12 * 384) + (ax2_12 * 96)) + ax3_12);
        T_cast[cse_var_20] = ((int32_t)((float*)compute_let)[cse_var_20]);
      }
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_subtract_cas_c93f40e30d1c190e__3(int8_t* p0, int8_t* T_cast, uint8_t* global_const_workspace_94_var, uint8_t* global_workspace_95_var) {
  void* fused_nn_conv2d_subtract_add_constant_59_let = (&(global_const_workspace_94_var[719376]));
  void* fused_nn_conv2d_subtract_add_constant_58_let = (&(global_const_workspace_94_var[720144]));
  void* fused_nn_conv2d_subtract_add_constant_57_let = (&(global_const_workspace_94_var[720912]));
  void* fused_nn_conv2d_constant_19_let = (&(global_const_workspace_94_var[725520]));
  void* fused_nn_conv2d_subtract_constant_19_let = (&(global_const_workspace_94_var[709392]));
  void* fused_constant_29_let = (&(global_const_workspace_94_var[521184]));
  void* pad_temp_let = (&(global_workspace_95_var[53248]));
  for (int32_t i0_i1_fused = 0; i0_i1_fused < 4; ++i0_i1_fused) {
    for (int32_t i2 = 0; i2 < 4; ++i2) {
      for (int32_t i3 = 0; i3 < 32; ++i3) {
        int32_t cse_var_1 = (((i0_i1_fused * 128) + (i2 * 32)) + i3);
        ((int8_t*)pad_temp_let)[cse_var_1] = p0[cse_var_1];
      }
    }
  }
  for (int32_t ax0_ax1_fused_ax2_fused = 0; ax0_ax1_fused_ax2_fused < 16; ++ax0_ax1_fused_ax2_fused) {
    void* conv2d_nhwc_let = (&(global_workspace_95_var[53760]));
    for (int32_t ax3_outer = 0; ax3_outer < 3; ++ax3_outer) {
      for (int32_t ff = 0; ff < 64; ++ff) {
        ((int32_t*)conv2d_nhwc_let)[ff] = 0;
        for (int32_t rc = 0; rc < 32; ++rc) {
          ((int32_t*)conv2d_nhwc_let)[ff] = (((int32_t*)conv2d_nhwc_let)[ff] + (((int32_t)((int8_t*)pad_temp_let)[((ax0_ax1_fused_ax2_fused * 32) + rc)]) * ((int32_t)((int8_t*)fused_constant_29_let)[(((rc * 192) + (ax3_outer * 64)) + ff)])));
        }
      }
      for (int32_t ax3_inner = 0; ax3_inner < 64; ++ax3_inner) {
        int32_t cse_var_3 = (ax3_outer * 64);
        int32_t cse_var_2 = (cse_var_3 + ax3_inner);
        int32_t v_ = ((int32_t)(((((int64_t)((((int32_t*)conv2d_nhwc_let)[ax3_inner] + ((int32_t*)fused_nn_conv2d_subtract_constant_19_let)[cse_var_2]) - ((int32_t*)fused_nn_conv2d_constant_19_let)[cse_var_2])) * ((int64_t)((int32_t*)fused_nn_conv2d_subtract_add_constant_57_let)[cse_var_2])) + ((int64_t)1 << ((int64_t)((((int32_t*)fused_nn_conv2d_subtract_add_constant_59_let)[cse_var_2] + 31) - 1)))) >> ((int64_t)(((int32_t*)fused_nn_conv2d_subtract_add_constant_59_let)[cse_var_2] + 31)))) - 24;
        int32_t v__1 = (v_) < (127) ? (v_) : (127);
        float v__2 = (((float)(((v__1) > (-128) ? (v__1) : (-128)) + 24)) * 1.867823e-01f) + 3.000000e+00f;
        float v__3 = (v__2) < (6.000000e+00f) ? (v__2) : (6.000000e+00f);
        float v__4 = roundf(((((((float)(((v__1) > (-128) ? (v__1) : (-128)) + 24)) * 1.867823e-01f) * ((v__3) > (0.000000e+00f) ? (v__3) : (0.000000e+00f))) * 1.666667e-01f) * 8.951831e+00f)) + -1.250000e+02f;
        float v__5 = (v__4) < (1.270000e+02f) ? (v__4) : (1.270000e+02f);
        T_cast[(((ax0_ax1_fused_ax2_fused * 192) + cse_var_3) + ax3_inner)] = ((int8_t)((v__5) > (-1.280000e+02f) ? (v__5) : (-1.280000e+02f)));
      }
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_subtract_cas_c93f40e30d1c190e__4(int8_t* p0, int32_t* T_cast, uint8_t* global_const_workspace_98_var, uint8_t* global_workspace_99_var) {
  void* fused_nn_conv2d_subtract_add_constant_62_let = (&(global_const_workspace_98_var[717072]));
  void* fused_nn_conv2d_subtract_add_constant_61_let = (&(global_const_workspace_98_var[717840]));
  void* fused_nn_conv2d_subtract_add_constant_60_let = (&(global_const_workspace_98_var[718608]));
  void* fused_nn_conv2d_subtract_constant_20_let = (&(global_const_workspace_98_var[708624]));
  void* fused_nn_conv2d_constant_20_let = (&(global_const_workspace_98_var[724752]));
  void* fused_constant_30_let = (&(global_const_workspace_98_var[555216]));
  void* PaddedInput_let = (&(global_workspace_99_var[24576]));
  void* DepthwiseConv2d_let = (&(global_workspace_99_var[36864]));
  void* compute_let = (&(global_workspace_99_var[12288]));
  for (int32_t i1 = 0; i1 < 8; ++i1) {
    for (int32_t i2 = 0; i2 < 8; ++i2) {
      for (int32_t i3 = 0; i3 < 192; ++i3) {
        int32_t cse_var_1 = (((i1 * 1536) + (i2 * 192)) + i3);
        ((int8_t*)PaddedInput_let)[cse_var_1] = p0[cse_var_1];
      }
    }
  }
  for (int32_t i = 0; i < 4; ++i) {
    for (int32_t j = 0; j < 4; ++j) {
      for (int32_t c = 0; c < 192; ++c) {
        ((int32_t*)DepthwiseConv2d_let)[(((i * 768) + (j * 192)) + c)] = 0;
        for (int32_t di = 0; di < 5; ++di) {
          for (int32_t dj = 0; dj < 5; ++dj) {
            int32_t cse_var_4 = (j * 192);
            int32_t cse_var_3 = (dj * 192);
            int32_t cse_var_2 = (((i * 768) + cse_var_4) + c);
            ((int32_t*)DepthwiseConv2d_let)[cse_var_2] = (((int32_t*)DepthwiseConv2d_let)[cse_var_2] + (((int32_t)((int8_t*)PaddedInput_let)[(((((i * 1536) + (di * 1536)) + cse_var_4) + cse_var_3) + c)]) * ((int32_t)((int8_t*)fused_constant_30_let)[(((di * 960) + cse_var_3) + c)])));
          }
        }
      }
    }
  }
  for (int32_t ax1 = 0; ax1 < 4; ++ax1) {
    for (int32_t ax2 = 0; ax2 < 4; ++ax2) {
      for (int32_t ax3 = 0; ax3 < 192; ++ax3) {
        int32_t cse_var_5 = (((ax1 * 768) + (ax2 * 192)) + ax3);
        ((int32_t*)DepthwiseConv2d_let)[cse_var_5] = (((int32_t*)DepthwiseConv2d_let)[cse_var_5] - ((int32_t*)fused_nn_conv2d_constant_20_let)[ax3]);
      }
    }
  }
  for (int32_t ax1_1 = 0; ax1_1 < 4; ++ax1_1) {
    for (int32_t ax2_1 = 0; ax2_1 < 4; ++ax2_1) {
      for (int32_t ax3_1 = 0; ax3_1 < 192; ++ax3_1) {
        int32_t cse_var_6 = (((ax1_1 * 768) + (ax2_1 * 192)) + ax3_1);
        ((int32_t*)DepthwiseConv2d_let)[cse_var_6] = (((int32_t*)DepthwiseConv2d_let)[cse_var_6] + ((int32_t*)fused_nn_conv2d_subtract_constant_20_let)[ax3_1]);
      }
    }
  }
  for (int32_t i1_1 = 0; i1_1 < 4; ++i1_1) {
    for (int32_t i2_1 = 0; i2_1 < 4; ++i2_1) {
      for (int32_t i3_1 = 0; i3_1 < 192; ++i3_1) {
        int32_t cse_var_7 = (((i1_1 * 768) + (i2_1 * 192)) + i3_1);
        ((int32_t*)DepthwiseConv2d_let)[cse_var_7] = ((int32_t)(((((int64_t)((int32_t*)DepthwiseConv2d_let)[cse_var_7]) * ((int64_t)((int32_t*)fused_nn_conv2d_subtract_add_constant_60_let)[i3_1])) + ((int64_t)1 << ((int64_t)((((int32_t*)fused_nn_conv2d_subtract_add_constant_62_let)[i3_1] + 31) - 1)))) >> ((int64_t)(((int32_t*)fused_nn_conv2d_subtract_add_constant_62_let)[i3_1] + 31))));
      }
    }
  }
  for (int32_t ax1_2 = 0; ax1_2 < 4; ++ax1_2) {
    for (int32_t ax2_2 = 0; ax2_2 < 4; ++ax2_2) {
      for (int32_t ax3_2 = 0; ax3_2 < 192; ++ax3_2) {
        int32_t cse_var_8 = (((ax1_2 * 768) + (ax2_2 * 192)) + ax3_2);
        ((int32_t*)DepthwiseConv2d_let)[cse_var_8] = (((int32_t*)DepthwiseConv2d_let)[cse_var_8] + 6);
      }
    }
  }
  for (int32_t i1_2 = 0; i1_2 < 4; ++i1_2) {
    for (int32_t i2_2 = 0; i2_2 < 4; ++i2_2) {
      for (int32_t i3_2 = 0; i3_2 < 192; ++i3_2) {
        int32_t cse_var_9 = (((i1_2 * 768) + (i2_2 * 192)) + i3_2);
        int32_t v_ = ((int32_t*)DepthwiseConv2d_let)[cse_var_9];
        int32_t v__1 = (v_) < (127) ? (v_) : (127);
        ((int32_t*)DepthwiseConv2d_let)[cse_var_9] = ((v__1) > (-128) ? (v__1) : (-128));
      }
    }
  }
  for (int32_t ax1_3 = 0; ax1_3 < 4; ++ax1_3) {
    for (int32_t ax2_3 = 0; ax2_3 < 4; ++ax2_3) {
      for (int32_t ax3_3 = 0; ax3_3 < 192; ++ax3_3) {
        int32_t cse_var_10 = (((ax1_3 * 768) + (ax2_3 * 192)) + ax3_3);
        ((int32_t*)DepthwiseConv2d_let)[cse_var_10] = (((int32_t*)DepthwiseConv2d_let)[cse_var_10] - 6);
      }
    }
  }
  for (int32_t ax1_4 = 0; ax1_4 < 4; ++ax1_4) {
    for (int32_t ax2_4 = 0; ax2_4 < 4; ++ax2_4) {
      for (int32_t ax3_4 = 0; ax3_4 < 192; ++ax3_4) {
        int32_t cse_var_11 = (((ax1_4 * 768) + (ax2_4 * 192)) + ax3_4);
        ((float*)PaddedInput_let)[cse_var_11] = ((float)((int32_t*)DepthwiseConv2d_let)[cse_var_11]);
      }
    }
  }
  for (int32_t ax1_5 = 0; ax1_5 < 4; ++ax1_5) {
    for (int32_t ax2_5 = 0; ax2_5 < 4; ++ax2_5) {
      for (int32_t ax3_5 = 0; ax3_5 < 192; ++ax3_5) {
        int32_t cse_var_12 = (((ax1_5 * 768) + (ax2_5 * 192)) + ax3_5);
        ((float*)DepthwiseConv2d_let)[cse_var_12] = (((float*)PaddedInput_let)[cse_var_12] * 2.768524e-01f);
      }
    }
  }
  for (int32_t ax1_6 = 0; ax1_6 < 4; ++ax1_6) {
    for (int32_t ax2_6 = 0; ax2_6 < 4; ++ax2_6) {
      for (int32_t ax3_6 = 0; ax3_6 < 192; ++ax3_6) {
        int32_t cse_var_13 = (((ax1_6 * 768) + (ax2_6 * 192)) + ax3_6);
        ((float*)PaddedInput_let)[cse_var_13] = (((float*)DepthwiseConv2d_let)[cse_var_13] + 3.000000e+00f);
      }
    }
  }
  for (int32_t i1_3 = 0; i1_3 < 4; ++i1_3) {
    for (int32_t i2_3 = 0; i2_3 < 4; ++i2_3) {
      for (int32_t i3_3 = 0; i3_3 < 192; ++i3_3) {
        int32_t cse_var_14 = (((i1_3 * 768) + (i2_3 * 192)) + i3_3);
        float v__2 = ((float*)PaddedInput_let)[cse_var_14];
        float v__3 = (v__2) < (6.000000e+00f) ? (v__2) : (6.000000e+00f);
        ((float*)compute_let)[cse_var_14] = ((v__3) > (0.000000e+00f) ? (v__3) : (0.000000e+00f));
      }
    }
  }
  for (int32_t ax1_7 = 0; ax1_7 < 4; ++ax1_7) {
    for (int32_t ax2_7 = 0; ax2_7 < 4; ++ax2_7) {
      for (int32_t ax3_7 = 0; ax3_7 < 192; ++ax3_7) {
        int32_t cse_var_15 = (((ax1_7 * 768) + (ax2_7 * 192)) + ax3_7);
        ((float*)compute_let)[cse_var_15] = (((float*)DepthwiseConv2d_let)[cse_var_15] * ((float*)compute_let)[cse_var_15]);
      }
    }
  }
  for (int32_t ax1_8 = 0; ax1_8 < 4; ++ax1_8) {
    for (int32_t ax2_8 = 0; ax2_8 < 4; ++ax2_8) {
      for (int32_t ax3_8 = 0; ax3_8 < 192; ++ax3_8) {
        int32_t cse_var_16 = (((ax1_8 * 768) + (ax2_8 * 192)) + ax3_8);
        ((float*)compute_let)[cse_var_16] = (((float*)compute_let)[cse_var_16] * 1.666667e-01f);
      }
    }
  }
  for (int32_t ax1_9 = 0; ax1_9 < 4; ++ax1_9) {
    for (int32_t ax2_9 = 0; ax2_9 < 4; ++ax2_9) {
      for (int32_t ax3_9 = 0; ax3_9 < 192; ++ax3_9) {
        int32_t cse_var_17 = (((ax1_9 * 768) + (ax2_9 * 192)) + ax3_9);
        ((float*)compute_let)[cse_var_17] = (((float*)compute_let)[cse_var_17] * 7.542913e+00f);
      }
    }
  }
  for (int32_t ax1_10 = 0; ax1_10 < 4; ++ax1_10) {
    for (int32_t ax2_10 = 0; ax2_10 < 4; ++ax2_10) {
      for (int32_t ax3_10 = 0; ax3_10 < 192; ++ax3_10) {
        int32_t cse_var_18 = (((ax1_10 * 768) + (ax2_10 * 192)) + ax3_10);
        ((float*)compute_let)[cse_var_18] = roundf(((float*)compute_let)[cse_var_18]);
      }
    }
  }
  for (int32_t ax1_11 = 0; ax1_11 < 4; ++ax1_11) {
    for (int32_t ax2_11 = 0; ax2_11 < 4; ++ax2_11) {
      for (int32_t ax3_11 = 0; ax3_11 < 192; ++ax3_11) {
        int32_t cse_var_19 = (((ax1_11 * 768) + (ax2_11 * 192)) + ax3_11);
        ((float*)compute_let)[cse_var_19] = (((float*)compute_let)[cse_var_19] + -1.250000e+02f);
      }
    }
  }
  for (int32_t i1_4 = 0; i1_4 < 4; ++i1_4) {
    for (int32_t i2_4 = 0; i2_4 < 4; ++i2_4) {
      for (int32_t i3_4 = 0; i3_4 < 192; ++i3_4) {
        int32_t cse_var_20 = (((i1_4 * 768) + (i2_4 * 192)) + i3_4);
        float v__4 = ((float*)compute_let)[cse_var_20];
        float v__5 = (v__4) < (1.270000e+02f) ? (v__4) : (1.270000e+02f);
        ((float*)compute_let)[cse_var_20] = ((v__5) > (-1.280000e+02f) ? (v__5) : (-1.280000e+02f));
      }
    }
  }
  for (int32_t ax1_12 = 0; ax1_12 < 4; ++ax1_12) {
    for (int32_t ax2_12 = 0; ax2_12 < 4; ++ax2_12) {
      for (int32_t ax3_12 = 0; ax3_12 < 192; ++ax3_12) {
        int32_t cse_var_21 = (((ax1_12 * 768) + (ax2_12 * 192)) + ax3_12);
        T_cast[cse_var_21] = ((int32_t)((float*)compute_let)[cse_var_21]);
      }
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_subtract_cas_c93f40e30d1c190e__5(int8_t* p0, int8_t* T_cast, uint8_t* global_const_workspace_128_var, uint8_t* global_workspace_129_var) {
  void* fused_nn_conv2d_subtract_add_constant_80_let = (&(global_const_workspace_128_var[749424]));
  void* fused_nn_conv2d_subtract_add_constant_79_let = (&(global_const_workspace_128_var[749808]));
  void* fused_nn_conv2d_subtract_add_constant_78_let = (&(global_const_workspace_128_var[750192]));
  void* fused_nn_conv2d_constant_27_let = (&(global_const_workspace_128_var[754800]));
  void* fused_nn_conv2d_subtract_constant_26_let = (&(global_const_workspace_128_var[746736]));
  void* fused_constant_39_let = (&(global_const_workspace_128_var[593968]));
  void* pad_temp_let = (&(global_workspace_129_var[53248]));
  for (int32_t i0_i1_fused = 0; i0_i1_fused < 4; ++i0_i1_fused) {
    for (int32_t i2 = 0; i2 < 4; ++i2) {
      for (int32_t i3 = 0; i3 < 32; ++i3) {
        int32_t cse_var_1 = (((i0_i1_fused * 128) + (i2 * 32)) + i3);
        ((int8_t*)pad_temp_let)[cse_var_1] = p0[cse_var_1];
      }
    }
  }
  for (int32_t ax0_ax1_fused_ax2_fused = 0; ax0_ax1_fused_ax2_fused < 16; ++ax0_ax1_fused_ax2_fused) {
    void* conv2d_nhwc_let = (&(global_workspace_129_var[53760]));
    for (int32_t ax3 = 0; ax3 < 96; ++ax3) {
      ((int32_t*)conv2d_nhwc_let)[0] = 0;
      for (int32_t rc = 0; rc < 32; ++rc) {
        ((int32_t*)conv2d_nhwc_let)[0] = (((int32_t*)conv2d_nhwc_let)[0] + (((int32_t)((int8_t*)pad_temp_let)[((ax0_ax1_fused_ax2_fused * 32) + rc)]) * ((int32_t)((int8_t*)fused_constant_39_let)[((rc * 96) + ax3)])));
      }
      int32_t v_ = ((int32_t)(((((int64_t)((((int32_t*)conv2d_nhwc_let)[0] + ((int32_t*)fused_nn_conv2d_subtract_constant_26_let)[ax3]) - ((int32_t*)fused_nn_conv2d_constant_27_let)[ax3])) * ((int64_t)((int32_t*)fused_nn_conv2d_subtract_add_constant_78_let)[ax3])) + ((int64_t)1 << ((int64_t)((((int32_t*)fused_nn_conv2d_subtract_add_constant_80_let)[ax3] + 31) - 1)))) >> ((int64_t)(((int32_t*)fused_nn_conv2d_subtract_add_constant_80_let)[ax3] + 31)))) - 3;
      int32_t v__1 = (v_) < (127) ? (v_) : (127);
      int32_t v__2 = ((int32_t)(((((int64_t)((((int32_t*)conv2d_nhwc_let)[0] + ((int32_t*)fused_nn_conv2d_subtract_constant_26_let)[ax3]) - ((int32_t*)fused_nn_conv2d_constant_27_let)[ax3])) * ((int64_t)((int32_t*)fused_nn_conv2d_subtract_add_constant_78_let)[ax3])) + ((int64_t)1 << ((int64_t)((((int32_t*)fused_nn_conv2d_subtract_add_constant_80_let)[ax3] + 31) - 1)))) >> ((int64_t)(((int32_t*)fused_nn_conv2d_subtract_add_constant_80_let)[ax3] + 31)))) - 3;
      int32_t v__3 = (v__2) < (127) ? (v__2) : (127);
      float v__4 = (((float)(((v__3) > (-128) ? (v__3) : (-128)) + 3)) * 1.259628e-01f) + 3.000000e+00f;
      float v__5 = (v__4) < (6.000000e+00f) ? (v__4) : (6.000000e+00f);
      float v__6 = roundf(((((((float)(((v__1) > (-128) ? (v__1) : (-128)) + 3)) * 1.259628e-01f) * ((v__5) > (0.000000e+00f) ? (v__5) : (0.000000e+00f))) * 1.666667e-01f) * 1.520980e+01f)) + -1.220000e+02f;
      float v__7 = (v__6) < (1.270000e+02f) ? (v__6) : (1.270000e+02f);
      T_cast[((ax0_ax1_fused_ax2_fused * 96) + ax3)] = ((int8_t)((v__7) > (-1.280000e+02f) ? (v__7) : (-1.280000e+02f)));
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_subtract_cas_c93f40e30d1c190e__6(int8_t* p0, int32_t* T_cast, uint8_t* global_const_workspace_132_var, uint8_t* global_workspace_133_var) {
  void* fused_nn_conv2d_subtract_add_constant_83_let = (&(global_const_workspace_132_var[748272]));
  void* fused_nn_conv2d_subtract_add_constant_82_let = (&(global_const_workspace_132_var[748656]));
  void* fused_nn_conv2d_subtract_add_constant_81_let = (&(global_const_workspace_132_var[749040]));
  void* fused_nn_conv2d_subtract_constant_27_let = (&(global_const_workspace_132_var[746352]));
  void* fused_nn_conv2d_constant_28_let = (&(global_const_workspace_132_var[754416]));
  void* fused_constant_40_let = (&(global_const_workspace_132_var[603120]));
  void* PaddedInput_let = (&(global_workspace_133_var[12288]));
  void* DepthwiseConv2d_let = (&(global_workspace_133_var[18432]));
  void* compute_let = (&(global_workspace_133_var[6144]));
  for (int32_t i1 = 0; i1 < 8; ++i1) {
    for (int32_t i2 = 0; i2 < 8; ++i2) {
      for (int32_t i3 = 0; i3 < 96; ++i3) {
        int32_t cse_var_1 = (((i1 * 768) + (i2 * 96)) + i3);
        ((int8_t*)PaddedInput_let)[cse_var_1] = p0[cse_var_1];
      }
    }
  }
  for (int32_t i = 0; i < 4; ++i) {
    for (int32_t j = 0; j < 4; ++j) {
      for (int32_t c = 0; c < 96; ++c) {
        ((int32_t*)DepthwiseConv2d_let)[(((i * 384) + (j * 96)) + c)] = 0;
        for (int32_t di = 0; di < 5; ++di) {
          for (int32_t dj = 0; dj < 5; ++dj) {
            int32_t cse_var_4 = (j * 96);
            int32_t cse_var_3 = (dj * 96);
            int32_t cse_var_2 = (((i * 384) + cse_var_4) + c);
            ((int32_t*)DepthwiseConv2d_let)[cse_var_2] = (((int32_t*)DepthwiseConv2d_let)[cse_var_2] + (((int32_t)((int8_t*)PaddedInput_let)[(((((i * 768) + (di * 768)) + cse_var_4) + cse_var_3) + c)]) * ((int32_t)((int8_t*)fused_constant_40_let)[(((di * 480) + cse_var_3) + c)])));
          }
        }
      }
    }
  }
  for (int32_t ax1 = 0; ax1 < 4; ++ax1) {
    for (int32_t ax2 = 0; ax2 < 4; ++ax2) {
      for (int32_t ax3 = 0; ax3 < 96; ++ax3) {
        int32_t cse_var_5 = (((ax1 * 384) + (ax2 * 96)) + ax3);
        ((int32_t*)DepthwiseConv2d_let)[cse_var_5] = (((int32_t*)DepthwiseConv2d_let)[cse_var_5] - ((int32_t*)fused_nn_conv2d_constant_28_let)[ax3]);
      }
    }
  }
  for (int32_t ax1_1 = 0; ax1_1 < 4; ++ax1_1) {
    for (int32_t ax2_1 = 0; ax2_1 < 4; ++ax2_1) {
      for (int32_t ax3_1 = 0; ax3_1 < 96; ++ax3_1) {
        int32_t cse_var_6 = (((ax1_1 * 384) + (ax2_1 * 96)) + ax3_1);
        ((int32_t*)DepthwiseConv2d_let)[cse_var_6] = (((int32_t*)DepthwiseConv2d_let)[cse_var_6] + ((int32_t*)fused_nn_conv2d_subtract_constant_27_let)[ax3_1]);
      }
    }
  }
  for (int32_t i1_1 = 0; i1_1 < 4; ++i1_1) {
    for (int32_t i2_1 = 0; i2_1 < 4; ++i2_1) {
      for (int32_t i3_1 = 0; i3_1 < 96; ++i3_1) {
        int32_t cse_var_7 = (((i1_1 * 384) + (i2_1 * 96)) + i3_1);
        ((int32_t*)DepthwiseConv2d_let)[cse_var_7] = ((int32_t)(((((int64_t)((int32_t*)DepthwiseConv2d_let)[cse_var_7]) * ((int64_t)((int32_t*)fused_nn_conv2d_subtract_add_constant_81_let)[i3_1])) + ((int64_t)1 << ((int64_t)((((int32_t*)fused_nn_conv2d_subtract_add_constant_83_let)[i3_1] + 31) - 1)))) >> ((int64_t)(((int32_t*)fused_nn_conv2d_subtract_add_constant_83_let)[i3_1] + 31))));
      }
    }
  }
  for (int32_t ax1_2 = 0; ax1_2 < 4; ++ax1_2) {
    for (int32_t ax2_2 = 0; ax2_2 < 4; ++ax2_2) {
      for (int32_t ax3_2 = 0; ax3_2 < 96; ++ax3_2) {
        int32_t cse_var_8 = (((ax1_2 * 384) + (ax2_2 * 96)) + ax3_2);
        ((int32_t*)DepthwiseConv2d_let)[cse_var_8] = (((int32_t*)DepthwiseConv2d_let)[cse_var_8] - 17);
      }
    }
  }
  for (int32_t i1_2 = 0; i1_2 < 4; ++i1_2) {
    for (int32_t i2_2 = 0; i2_2 < 4; ++i2_2) {
      for (int32_t i3_2 = 0; i3_2 < 96; ++i3_2) {
        int32_t cse_var_9 = (((i1_2 * 384) + (i2_2 * 96)) + i3_2);
        int32_t v_ = ((int32_t*)DepthwiseConv2d_let)[cse_var_9];
        int32_t v__1 = (v_) < (127) ? (v_) : (127);
        ((int32_t*)DepthwiseConv2d_let)[cse_var_9] = ((v__1) > (-128) ? (v__1) : (-128));
      }
    }
  }
  for (int32_t ax1_3 = 0; ax1_3 < 4; ++ax1_3) {
    for (int32_t ax2_3 = 0; ax2_3 < 4; ++ax2_3) {
      for (int32_t ax3_3 = 0; ax3_3 < 96; ++ax3_3) {
        int32_t cse_var_10 = (((ax1_3 * 384) + (ax2_3 * 96)) + ax3_3);
        ((int32_t*)DepthwiseConv2d_let)[cse_var_10] = (((int32_t*)DepthwiseConv2d_let)[cse_var_10] + 17);
      }
    }
  }
  for (int32_t ax1_4 = 0; ax1_4 < 4; ++ax1_4) {
    for (int32_t ax2_4 = 0; ax2_4 < 4; ++ax2_4) {
      for (int32_t ax3_4 = 0; ax3_4 < 96; ++ax3_4) {
        int32_t cse_var_11 = (((ax1_4 * 384) + (ax2_4 * 96)) + ax3_4);
        ((float*)PaddedInput_let)[cse_var_11] = ((float)((int32_t*)DepthwiseConv2d_let)[cse_var_11]);
      }
    }
  }
  for (int32_t ax1_5 = 0; ax1_5 < 4; ++ax1_5) {
    for (int32_t ax2_5 = 0; ax2_5 < 4; ++ax2_5) {
      for (int32_t ax3_5 = 0; ax3_5 < 96; ++ax3_5) {
        int32_t cse_var_12 = (((ax1_5 * 384) + (ax2_5 * 96)) + ax3_5);
        ((float*)DepthwiseConv2d_let)[cse_var_12] = (((float*)PaddedInput_let)[cse_var_12] * 1.831288e-01f);
      }
    }
  }
  for (int32_t ax1_6 = 0; ax1_6 < 4; ++ax1_6) {
    for (int32_t ax2_6 = 0; ax2_6 < 4; ++ax2_6) {
      for (int32_t ax3_6 = 0; ax3_6 < 96; ++ax3_6) {
        int32_t cse_var_13 = (((ax1_6 * 384) + (ax2_6 * 96)) + ax3_6);
        ((float*)PaddedInput_let)[cse_var_13] = (((float*)DepthwiseConv2d_let)[cse_var_13] + 3.000000e+00f);
      }
    }
  }
  for (int32_t i1_3 = 0; i1_3 < 4; ++i1_3) {
    for (int32_t i2_3 = 0; i2_3 < 4; ++i2_3) {
      for (int32_t i3_3 = 0; i3_3 < 96; ++i3_3) {
        int32_t cse_var_14 = (((i1_3 * 384) + (i2_3 * 96)) + i3_3);
        float v__2 = ((float*)PaddedInput_let)[cse_var_14];
        float v__3 = (v__2) < (6.000000e+00f) ? (v__2) : (6.000000e+00f);
        ((float*)compute_let)[cse_var_14] = ((v__3) > (0.000000e+00f) ? (v__3) : (0.000000e+00f));
      }
    }
  }
  for (int32_t ax1_7 = 0; ax1_7 < 4; ++ax1_7) {
    for (int32_t ax2_7 = 0; ax2_7 < 4; ++ax2_7) {
      for (int32_t ax3_7 = 0; ax3_7 < 96; ++ax3_7) {
        int32_t cse_var_15 = (((ax1_7 * 384) + (ax2_7 * 96)) + ax3_7);
        ((float*)compute_let)[cse_var_15] = (((float*)DepthwiseConv2d_let)[cse_var_15] * ((float*)compute_let)[cse_var_15]);
      }
    }
  }
  for (int32_t ax1_8 = 0; ax1_8 < 4; ++ax1_8) {
    for (int32_t ax2_8 = 0; ax2_8 < 4; ++ax2_8) {
      for (int32_t ax3_8 = 0; ax3_8 < 96; ++ax3_8) {
        int32_t cse_var_16 = (((ax1_8 * 384) + (ax2_8 * 96)) + ax3_8);
        ((float*)compute_let)[cse_var_16] = (((float*)compute_let)[cse_var_16] * 1.666667e-01f);
      }
    }
  }
  for (int32_t ax1_9 = 0; ax1_9 < 4; ++ax1_9) {
    for (int32_t ax2_9 = 0; ax2_9 < 4; ++ax2_9) {
      for (int32_t ax3_9 = 0; ax3_9 < 96; ++ax3_9) {
        int32_t cse_var_17 = (((ax1_9 * 384) + (ax2_9 * 96)) + ax3_9);
        ((float*)compute_let)[cse_var_17] = (((float*)compute_let)[cse_var_17] * 9.556944e+00f);
      }
    }
  }
  for (int32_t ax1_10 = 0; ax1_10 < 4; ++ax1_10) {
    for (int32_t ax2_10 = 0; ax2_10 < 4; ++ax2_10) {
      for (int32_t ax3_10 = 0; ax3_10 < 96; ++ax3_10) {
        int32_t cse_var_18 = (((ax1_10 * 384) + (ax2_10 * 96)) + ax3_10);
        ((float*)compute_let)[cse_var_18] = roundf(((float*)compute_let)[cse_var_18]);
      }
    }
  }
  for (int32_t ax1_11 = 0; ax1_11 < 4; ++ax1_11) {
    for (int32_t ax2_11 = 0; ax2_11 < 4; ++ax2_11) {
      for (int32_t ax3_11 = 0; ax3_11 < 96; ++ax3_11) {
        int32_t cse_var_19 = (((ax1_11 * 384) + (ax2_11 * 96)) + ax3_11);
        ((float*)compute_let)[cse_var_19] = (((float*)compute_let)[cse_var_19] + -1.240000e+02f);
      }
    }
  }
  for (int32_t i1_4 = 0; i1_4 < 4; ++i1_4) {
    for (int32_t i2_4 = 0; i2_4 < 4; ++i2_4) {
      for (int32_t i3_4 = 0; i3_4 < 96; ++i3_4) {
        int32_t cse_var_20 = (((i1_4 * 384) + (i2_4 * 96)) + i3_4);
        float v__4 = ((float*)compute_let)[cse_var_20];
        float v__5 = (v__4) < (1.270000e+02f) ? (v__4) : (1.270000e+02f);
        ((float*)compute_let)[cse_var_20] = ((v__5) > (-1.280000e+02f) ? (v__5) : (-1.280000e+02f));
      }
    }
  }
  for (int32_t ax1_12 = 0; ax1_12 < 4; ++ax1_12) {
    for (int32_t ax2_12 = 0; ax2_12 < 4; ++ax2_12) {
      for (int32_t ax3_12 = 0; ax3_12 < 96; ++ax3_12) {
        int32_t cse_var_21 = (((ax1_12 * 384) + (ax2_12 * 96)) + ax3_12);
        T_cast[cse_var_21] = ((int32_t)((float*)compute_let)[cse_var_21]);
      }
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_subtract_cas_c93f40e30d1c190e__7(int8_t* p0, int8_t* T_cast, uint8_t* global_const_workspace_146_var, uint8_t* global_workspace_147_var) {
  void* fused_nn_conv2d_subtract_add_constant_92_let = (&(global_const_workspace_146_var[737600]));
  void* fused_nn_conv2d_subtract_add_constant_91_let = (&(global_const_workspace_146_var[738080]));
  void* fused_nn_conv2d_subtract_add_constant_90_let = (&(global_const_workspace_146_var[738560]));
  void* fused_nn_conv2d_constant_32_let = (&(global_const_workspace_146_var[740960]));
  void* fused_nn_conv2d_subtract_constant_30_let = (&(global_const_workspace_146_var[735200]));
  void* fused_constant_45_let = (&(global_const_workspace_146_var[545616]));
  void* pad_temp_let = (&(global_workspace_147_var[33280]));
  for (int32_t i0_i1_fused = 0; i0_i1_fused < 4; ++i0_i1_fused) {
    for (int32_t i2 = 0; i2 < 4; ++i2) {
      for (int32_t i3 = 0; i3 < 40; ++i3) {
        int32_t cse_var_1 = (((i0_i1_fused * 160) + (i2 * 40)) + i3);
        ((int8_t*)pad_temp_let)[cse_var_1] = p0[cse_var_1];
      }
    }
  }
  for (int32_t ax0_ax1_fused_ax2_fused = 0; ax0_ax1_fused_ax2_fused < 16; ++ax0_ax1_fused_ax2_fused) {
    void* conv2d_nhwc_let = (&(global_workspace_147_var[52736]));
    for (int32_t ax3 = 0; ax3 < 120; ++ax3) {
      ((int32_t*)conv2d_nhwc_let)[0] = 0;
      for (int32_t rc = 0; rc < 40; ++rc) {
        ((int32_t*)conv2d_nhwc_let)[0] = (((int32_t*)conv2d_nhwc_let)[0] + (((int32_t)((int8_t*)pad_temp_let)[((ax0_ax1_fused_ax2_fused * 40) + rc)]) * ((int32_t)((int8_t*)fused_constant_45_let)[((rc * 120) + ax3)])));
      }
      int32_t v_ = ((int32_t)(((((int64_t)((((int32_t*)conv2d_nhwc_let)[0] + ((int32_t*)fused_nn_conv2d_subtract_constant_30_let)[ax3]) - ((int32_t*)fused_nn_conv2d_constant_32_let)[ax3])) * ((int64_t)((int32_t*)fused_nn_conv2d_subtract_add_constant_90_let)[ax3])) + ((int64_t)1 << ((int64_t)((((int32_t*)fused_nn_conv2d_subtract_add_constant_92_let)[ax3] + 31) - 1)))) >> ((int64_t)(((int32_t*)fused_nn_conv2d_subtract_add_constant_92_let)[ax3] + 31)))) - 2;
      int32_t v__1 = (v_) < (127) ? (v_) : (127);
      int32_t v__2 = ((int32_t)(((((int64_t)((((int32_t*)conv2d_nhwc_let)[0] + ((int32_t*)fused_nn_conv2d_subtract_constant_30_let)[ax3]) - ((int32_t*)fused_nn_conv2d_constant_32_let)[ax3])) * ((int64_t)((int32_t*)fused_nn_conv2d_subtract_add_constant_90_let)[ax3])) + ((int64_t)1 << ((int64_t)((((int32_t*)fused_nn_conv2d_subtract_add_constant_92_let)[ax3] + 31) - 1)))) >> ((int64_t)(((int32_t*)fused_nn_conv2d_subtract_add_constant_92_let)[ax3] + 31)))) - 2;
      int32_t v__3 = (v__2) < (127) ? (v__2) : (127);
      float v__4 = (((float)(((v__3) > (-128) ? (v__3) : (-128)) + 2)) * 1.223695e-01f) + 3.000000e+00f;
      float v__5 = (v__4) < (6.000000e+00f) ? (v__4) : (6.000000e+00f);
      float v__6 = roundf(((((((float)(((v__1) > (-128) ? (v__1) : (-128)) + 2)) * 1.223695e-01f) * ((v__5) > (0.000000e+00f) ? (v__5) : (0.000000e+00f))) * 1.666667e-01f) * 1.574001e+01f)) + -1.220000e+02f;
      float v__7 = (v__6) < (1.270000e+02f) ? (v__6) : (1.270000e+02f);
      T_cast[((ax0_ax1_fused_ax2_fused * 120) + ax3)] = ((int8_t)((v__7) > (-1.280000e+02f) ? (v__7) : (-1.280000e+02f)));
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_subtract_cas_c93f40e30d1c190e__8(int8_t* p0, int32_t* T_cast, uint8_t* global_const_workspace_150_var, uint8_t* global_workspace_151_var) {
  void* fused_nn_conv2d_subtract_add_constant_95_let = (&(global_const_workspace_150_var[736160]));
  void* fused_nn_conv2d_subtract_add_constant_94_let = (&(global_const_workspace_150_var[736640]));
  void* fused_nn_conv2d_subtract_add_constant_93_let = (&(global_const_workspace_150_var[737120]));
  void* fused_nn_conv2d_subtract_constant_31_let = (&(global_const_workspace_150_var[734720]));
  void* fused_nn_conv2d_constant_33_let = (&(global_const_workspace_150_var[740480]));
  void* fused_constant_46_let = (&(global_const_workspace_150_var[600112]));
  void* PaddedInput_let = (&(global_workspace_151_var[15360]));
  void* DepthwiseConv2d_let = (&(global_workspace_151_var[23040]));
  void* compute_let = (&(global_workspace_151_var[7680]));
  for (int32_t i1 = 0; i1 < 8; ++i1) {
    for (int32_t i2 = 0; i2 < 8; ++i2) {
      for (int32_t i3 = 0; i3 < 120; ++i3) {
        int32_t cse_var_1 = (((i1 * 960) + (i2 * 120)) + i3);
        ((int8_t*)PaddedInput_let)[cse_var_1] = p0[cse_var_1];
      }
    }
  }
  for (int32_t i = 0; i < 4; ++i) {
    for (int32_t j = 0; j < 4; ++j) {
      for (int32_t c = 0; c < 120; ++c) {
        ((int32_t*)DepthwiseConv2d_let)[(((i * 480) + (j * 120)) + c)] = 0;
        for (int32_t di = 0; di < 5; ++di) {
          for (int32_t dj = 0; dj < 5; ++dj) {
            int32_t cse_var_4 = (j * 120);
            int32_t cse_var_3 = (dj * 120);
            int32_t cse_var_2 = (((i * 480) + cse_var_4) + c);
            ((int32_t*)DepthwiseConv2d_let)[cse_var_2] = (((int32_t*)DepthwiseConv2d_let)[cse_var_2] + (((int32_t)((int8_t*)PaddedInput_let)[(((((i * 960) + (di * 960)) + cse_var_4) + cse_var_3) + c)]) * ((int32_t)((int8_t*)fused_constant_46_let)[(((di * 600) + cse_var_3) + c)])));
          }
        }
      }
    }
  }
  for (int32_t ax1 = 0; ax1 < 4; ++ax1) {
    for (int32_t ax2 = 0; ax2 < 4; ++ax2) {
      for (int32_t ax3 = 0; ax3 < 120; ++ax3) {
        int32_t cse_var_5 = (((ax1 * 480) + (ax2 * 120)) + ax3);
        ((int32_t*)DepthwiseConv2d_let)[cse_var_5] = (((int32_t*)DepthwiseConv2d_let)[cse_var_5] - ((int32_t*)fused_nn_conv2d_constant_33_let)[ax3]);
      }
    }
  }
  for (int32_t ax1_1 = 0; ax1_1 < 4; ++ax1_1) {
    for (int32_t ax2_1 = 0; ax2_1 < 4; ++ax2_1) {
      for (int32_t ax3_1 = 0; ax3_1 < 120; ++ax3_1) {
        int32_t cse_var_6 = (((ax1_1 * 480) + (ax2_1 * 120)) + ax3_1);
        ((int32_t*)DepthwiseConv2d_let)[cse_var_6] = (((int32_t*)DepthwiseConv2d_let)[cse_var_6] + ((int32_t*)fused_nn_conv2d_subtract_constant_31_let)[ax3_1]);
      }
    }
  }
  for (int32_t i1_1 = 0; i1_1 < 4; ++i1_1) {
    for (int32_t i2_1 = 0; i2_1 < 4; ++i2_1) {
      for (int32_t i3_1 = 0; i3_1 < 120; ++i3_1) {
        int32_t cse_var_7 = (((i1_1 * 480) + (i2_1 * 120)) + i3_1);
        ((int32_t*)DepthwiseConv2d_let)[cse_var_7] = ((int32_t)(((((int64_t)((int32_t*)DepthwiseConv2d_let)[cse_var_7]) * ((int64_t)((int32_t*)fused_nn_conv2d_subtract_add_constant_93_let)[i3_1])) + ((int64_t)1 << ((int64_t)((((int32_t*)fused_nn_conv2d_subtract_add_constant_95_let)[i3_1] + 31) - 1)))) >> ((int64_t)(((int32_t*)fused_nn_conv2d_subtract_add_constant_95_let)[i3_1] + 31))));
      }
    }
  }
  for (int32_t ax1_2 = 0; ax1_2 < 4; ++ax1_2) {
    for (int32_t ax2_2 = 0; ax2_2 < 4; ++ax2_2) {
      for (int32_t ax3_2 = 0; ax3_2 < 120; ++ax3_2) {
        int32_t cse_var_8 = (((ax1_2 * 480) + (ax2_2 * 120)) + ax3_2);
        ((int32_t*)DepthwiseConv2d_let)[cse_var_8] = (((int32_t*)DepthwiseConv2d_let)[cse_var_8] - 57);
      }
    }
  }
  for (int32_t i1_2 = 0; i1_2 < 4; ++i1_2) {
    for (int32_t i2_2 = 0; i2_2 < 4; ++i2_2) {
      for (int32_t i3_2 = 0; i3_2 < 120; ++i3_2) {
        int32_t cse_var_9 = (((i1_2 * 480) + (i2_2 * 120)) + i3_2);
        int32_t v_ = ((int32_t*)DepthwiseConv2d_let)[cse_var_9];
        int32_t v__1 = (v_) < (127) ? (v_) : (127);
        ((int32_t*)DepthwiseConv2d_let)[cse_var_9] = ((v__1) > (-128) ? (v__1) : (-128));
      }
    }
  }
  for (int32_t ax1_3 = 0; ax1_3 < 4; ++ax1_3) {
    for (int32_t ax2_3 = 0; ax2_3 < 4; ++ax2_3) {
      for (int32_t ax3_3 = 0; ax3_3 < 120; ++ax3_3) {
        int32_t cse_var_10 = (((ax1_3 * 480) + (ax2_3 * 120)) + ax3_3);
        ((int32_t*)DepthwiseConv2d_let)[cse_var_10] = (((int32_t*)DepthwiseConv2d_let)[cse_var_10] + 57);
      }
    }
  }
  for (int32_t ax1_4 = 0; ax1_4 < 4; ++ax1_4) {
    for (int32_t ax2_4 = 0; ax2_4 < 4; ++ax2_4) {
      for (int32_t ax3_4 = 0; ax3_4 < 120; ++ax3_4) {
        int32_t cse_var_11 = (((ax1_4 * 480) + (ax2_4 * 120)) + ax3_4);
        ((float*)PaddedInput_let)[cse_var_11] = ((float)((int32_t*)DepthwiseConv2d_let)[cse_var_11]);
      }
    }
  }
  for (int32_t ax1_5 = 0; ax1_5 < 4; ++ax1_5) {
    for (int32_t ax2_5 = 0; ax2_5 < 4; ++ax2_5) {
      for (int32_t ax3_5 = 0; ax3_5 < 120; ++ax3_5) {
        int32_t cse_var_12 = (((ax1_5 * 480) + (ax2_5 * 120)) + ax3_5);
        ((float*)DepthwiseConv2d_let)[cse_var_12] = (((float*)PaddedInput_let)[cse_var_12] * 3.359595e-01f);
      }
    }
  }
  for (int32_t ax1_6 = 0; ax1_6 < 4; ++ax1_6) {
    for (int32_t ax2_6 = 0; ax2_6 < 4; ++ax2_6) {
      for (int32_t ax3_6 = 0; ax3_6 < 120; ++ax3_6) {
        int32_t cse_var_13 = (((ax1_6 * 480) + (ax2_6 * 120)) + ax3_6);
        ((float*)PaddedInput_let)[cse_var_13] = (((float*)DepthwiseConv2d_let)[cse_var_13] + 3.000000e+00f);
      }
    }
  }
  for (int32_t i1_3 = 0; i1_3 < 4; ++i1_3) {
    for (int32_t i2_3 = 0; i2_3 < 4; ++i2_3) {
      for (int32_t i3_3 = 0; i3_3 < 120; ++i3_3) {
        int32_t cse_var_14 = (((i1_3 * 480) + (i2_3 * 120)) + i3_3);
        float v__2 = ((float*)PaddedInput_let)[cse_var_14];
        float v__3 = (v__2) < (6.000000e+00f) ? (v__2) : (6.000000e+00f);
        ((float*)compute_let)[cse_var_14] = ((v__3) > (0.000000e+00f) ? (v__3) : (0.000000e+00f));
      }
    }
  }
  for (int32_t ax1_7 = 0; ax1_7 < 4; ++ax1_7) {
    for (int32_t ax2_7 = 0; ax2_7 < 4; ++ax2_7) {
      for (int32_t ax3_7 = 0; ax3_7 < 120; ++ax3_7) {
        int32_t cse_var_15 = (((ax1_7 * 480) + (ax2_7 * 120)) + ax3_7);
        ((float*)compute_let)[cse_var_15] = (((float*)DepthwiseConv2d_let)[cse_var_15] * ((float*)compute_let)[cse_var_15]);
      }
    }
  }
  for (int32_t ax1_8 = 0; ax1_8 < 4; ++ax1_8) {
    for (int32_t ax2_8 = 0; ax2_8 < 4; ++ax2_8) {
      for (int32_t ax3_8 = 0; ax3_8 < 120; ++ax3_8) {
        int32_t cse_var_16 = (((ax1_8 * 480) + (ax2_8 * 120)) + ax3_8);
        ((float*)compute_let)[cse_var_16] = (((float*)compute_let)[cse_var_16] * 1.666667e-01f);
      }
    }
  }
  for (int32_t ax1_9 = 0; ax1_9 < 4; ++ax1_9) {
    for (int32_t ax2_9 = 0; ax2_9 < 4; ++ax2_9) {
      for (int32_t ax3_9 = 0; ax3_9 < 120; ++ax3_9) {
        int32_t cse_var_17 = (((ax1_9 * 480) + (ax2_9 * 120)) + ax3_9);
        ((float*)compute_let)[cse_var_17] = (((float*)compute_let)[cse_var_17] * 4.090191e+00f);
      }
    }
  }
  for (int32_t ax1_10 = 0; ax1_10 < 4; ++ax1_10) {
    for (int32_t ax2_10 = 0; ax2_10 < 4; ++ax2_10) {
      for (int32_t ax3_10 = 0; ax3_10 < 120; ++ax3_10) {
        int32_t cse_var_18 = (((ax1_10 * 480) + (ax2_10 * 120)) + ax3_10);
        ((float*)compute_let)[cse_var_18] = roundf(((float*)compute_let)[cse_var_18]);
      }
    }
  }
  for (int32_t ax1_11 = 0; ax1_11 < 4; ++ax1_11) {
    for (int32_t ax2_11 = 0; ax2_11 < 4; ++ax2_11) {
      for (int32_t ax3_11 = 0; ax3_11 < 120; ++ax3_11) {
        int32_t cse_var_19 = (((ax1_11 * 480) + (ax2_11 * 120)) + ax3_11);
        ((float*)compute_let)[cse_var_19] = (((float*)compute_let)[cse_var_19] + -1.260000e+02f);
      }
    }
  }
  for (int32_t i1_4 = 0; i1_4 < 4; ++i1_4) {
    for (int32_t i2_4 = 0; i2_4 < 4; ++i2_4) {
      for (int32_t i3_4 = 0; i3_4 < 120; ++i3_4) {
        int32_t cse_var_20 = (((i1_4 * 480) + (i2_4 * 120)) + i3_4);
        float v__4 = ((float*)compute_let)[cse_var_20];
        float v__5 = (v__4) < (1.270000e+02f) ? (v__4) : (1.270000e+02f);
        ((float*)compute_let)[cse_var_20] = ((v__5) > (-1.280000e+02f) ? (v__5) : (-1.280000e+02f));
      }
    }
  }
  for (int32_t ax1_12 = 0; ax1_12 < 4; ++ax1_12) {
    for (int32_t ax2_12 = 0; ax2_12 < 4; ++ax2_12) {
      for (int32_t ax3_12 = 0; ax3_12 < 120; ++ax3_12) {
        int32_t cse_var_21 = (((ax1_12 * 480) + (ax2_12 * 120)) + ax3_12);
        T_cast[cse_var_21] = ((int32_t)((float*)compute_let)[cse_var_21]);
      }
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_subtract_cas_c93f40e30d1c190e__9(int8_t* p0, int8_t* T_cast, uint8_t* global_const_workspace_164_var, uint8_t* global_workspace_165_var) {
  void* fused_nn_conv2d_subtract_add_constant_104_let = (&(global_const_workspace_164_var[699760]));
  void* fused_nn_conv2d_subtract_add_constant_103_let = (&(global_const_workspace_164_var[700720]));
  void* fused_nn_conv2d_subtract_add_constant_102_let = (&(global_const_workspace_164_var[701680]));
  void* fused_nn_conv2d_constant_36_let = (&(global_const_workspace_164_var[704560]));
  void* fused_nn_conv2d_subtract_constant_34_let = (&(global_const_workspace_164_var[693040]));
  void* fused_constant_50_let = (&(global_const_workspace_164_var[418656]));
  void* pad_temp_let = (&(global_workspace_165_var[33920]));
  for (int32_t i0_i1_fused = 0; i0_i1_fused < 4; ++i0_i1_fused) {
    for (int32_t i2 = 0; i2 < 4; ++i2) {
      for (int32_t i3 = 0; i3 < 40; ++i3) {
        int32_t cse_var_1 = (((i0_i1_fused * 160) + (i2 * 40)) + i3);
        ((int8_t*)pad_temp_let)[cse_var_1] = p0[cse_var_1];
      }
    }
  }
  for (int32_t ax0_ax1_fused_ax2_fused = 0; ax0_ax1_fused_ax2_fused < 16; ++ax0_ax1_fused_ax2_fused) {
    void* conv2d_nhwc_let = (&(global_workspace_165_var[52736]));
    for (int32_t ax3 = 0; ax3 < 240; ++ax3) {
      ((int32_t*)conv2d_nhwc_let)[0] = 0;
      for (int32_t rc = 0; rc < 40; ++rc) {
        ((int32_t*)conv2d_nhwc_let)[0] = (((int32_t*)conv2d_nhwc_let)[0] + (((int32_t)((int8_t*)pad_temp_let)[((ax0_ax1_fused_ax2_fused * 40) + rc)]) * ((int32_t)((int8_t*)fused_constant_50_let)[((rc * 240) + ax3)])));
      }
      int32_t v_ = ((int32_t)(((((int64_t)((((int32_t*)conv2d_nhwc_let)[0] + ((int32_t*)fused_nn_conv2d_subtract_constant_34_let)[ax3]) - ((int32_t*)fused_nn_conv2d_constant_36_let)[ax3])) * ((int64_t)((int32_t*)fused_nn_conv2d_subtract_add_constant_102_let)[ax3])) + ((int64_t)1 << ((int64_t)((((int32_t*)fused_nn_conv2d_subtract_add_constant_104_let)[ax3] + 31) - 1)))) >> ((int64_t)(((int32_t*)fused_nn_conv2d_subtract_add_constant_104_let)[ax3] + 31)))) + 11;
      int32_t v__1 = (v_) < (127) ? (v_) : (127);
      int32_t v__2 = ((int32_t)(((((int64_t)((((int32_t*)conv2d_nhwc_let)[0] + ((int32_t*)fused_nn_conv2d_subtract_constant_34_let)[ax3]) - ((int32_t*)fused_nn_conv2d_constant_36_let)[ax3])) * ((int64_t)((int32_t*)fused_nn_conv2d_subtract_add_constant_102_let)[ax3])) + ((int64_t)1 << ((int64_t)((((int32_t*)fused_nn_conv2d_subtract_add_constant_104_let)[ax3] + 31) - 1)))) >> ((int64_t)(((int32_t*)fused_nn_conv2d_subtract_add_constant_104_let)[ax3] + 31)))) + 11;
      int32_t v__3 = (v__2) < (127) ? (v__2) : (127);
      float v__4 = (((float)(((v__3) > (-128) ? (v__3) : (-128)) - 11)) * 1.429008e-01f) + 3.000000e+00f;
      float v__5 = (v__4) < (6.000000e+00f) ? (v__4) : (6.000000e+00f);
      float v__6 = roundf(((((((float)(((v__1) > (-128) ? (v__1) : (-128)) - 11)) * 1.429008e-01f) * ((v__5) > (0.000000e+00f) ? (v__5) : (0.000000e+00f))) * 1.666667e-01f) * 1.506020e+01f)) + -1.220000e+02f;
      float v__7 = (v__6) < (1.270000e+02f) ? (v__6) : (1.270000e+02f);
      T_cast[((ax0_ax1_fused_ax2_fused * 240) + ax3)] = ((int8_t)((v__7) > (-1.280000e+02f) ? (v__7) : (-1.280000e+02f)));
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_subtract_mul_add8c47b972ae6c2_(int8_t* p0, int32_t* T_subtract, uint8_t* global_const_workspace_16_var, uint8_t* global_workspace_17_var) {
  void* fused_nn_conv2d_subtract_add_constant_11_let = (&(global_const_workspace_16_var[782752]));
  void* fused_nn_conv2d_subtract_add_constant_10_let = (&(global_const_workspace_16_var[782816]));
  void* fused_nn_conv2d_subtract_add_constant_9_let = (&(global_const_workspace_16_var[781856]));
  void* fused_nn_conv2d_constant_3_let = (&(global_const_workspace_16_var[783136]));
  void* fused_nn_conv2d_subtract_constant_3_let = (&(global_const_workspace_16_var[781600]));
  void* fused_constant_4_let = (&(global_const_workspace_16_var[778016]));
  void* pad_temp_let = (&(global_workspace_17_var[20544]));
  void* conv2d_nhwc_let = (&(global_workspace_17_var[20552]));
  for (int32_t i3 = 0; i3 < 8; ++i3) {
    ((int8_t*)pad_temp_let)[i3] = p0[i3];
  }
  for (int32_t ax3 = 0; ax3 < 16; ++ax3) {
    ((int32_t*)conv2d_nhwc_let)[0] = 0;
    for (int32_t rc = 0; rc < 8; ++rc) {
      ((int32_t*)conv2d_nhwc_let)[0] = (((int32_t*)conv2d_nhwc_let)[0] + (((int32_t)((int8_t*)pad_temp_let)[rc]) * ((int32_t)((int8_t*)fused_constant_4_let)[((rc * 16) + ax3)])));
    }
    int32_t v_ = ((int32_t)(((((int64_t)((((int32_t*)conv2d_nhwc_let)[0] + ((int32_t*)fused_nn_conv2d_subtract_constant_3_let)[ax3]) - ((int32_t*)fused_nn_conv2d_constant_3_let)[ax3])) * ((int64_t)((int32_t*)fused_nn_conv2d_subtract_add_constant_9_let)[ax3])) + ((int64_t)1 << ((int64_t)((((int32_t*)fused_nn_conv2d_subtract_add_constant_11_let)[ax3] + 31) - 1)))) >> ((int64_t)(((int32_t*)fused_nn_conv2d_subtract_add_constant_11_let)[ax3] + 31)))) - 128;
    int32_t v__1 = (v_) < (127) ? (v_) : (127);
    int32_t v__2 = ((int32_t)(((((int64_t)((((int32_t*)conv2d_nhwc_let)[0] + ((int32_t*)fused_nn_conv2d_subtract_constant_3_let)[ax3]) - ((int32_t*)fused_nn_conv2d_constant_3_let)[ax3])) * ((int64_t)((int32_t*)fused_nn_conv2d_subtract_add_constant_9_let)[ax3])) + ((int64_t)1 << ((int64_t)((((int32_t*)fused_nn_conv2d_subtract_add_constant_11_let)[ax3] + 31) - 1)))) >> ((int64_t)(((int32_t*)fused_nn_conv2d_subtract_add_constant_11_let)[ax3] + 31)))) - 128;
    int32_t v__3 = (v__2) < (127) ? (v__2) : (127);
    int32_t v__4 = ((int32_t)(((((0 != 0) ? (((int64_t)((((v__1) > (-128) ? (v__1) : (-128)) * 255) + 32640)) << ((int64_t)0)) : ((int64_t)((((v__3) > (-128) ? (v__3) : (-128)) * 255) + 32640))) * (int64_t)1077952511) + ((int64_t)1 << ((int64_t)((7 + 31) - 1)))) >> ((int64_t)(7 + 31)))) - 128;
    int32_t v__5 = (v__4) < (127) ? (v__4) : (127);
    T_subtract[ax3] = (((v__5) > (-128) ? (v__5) : (-128)) + 128);
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_subtract_mul_add8c47b972ae6c2__1(int8_t* p0, int32_t* T_subtract, uint8_t* global_const_workspace_68_var, uint8_t* global_workspace_69_var) {
  void* fused_nn_conv2d_subtract_add_constant_47_let = (&(global_const_workspace_68_var[750576]));
  void* fused_nn_conv2d_subtract_add_constant_46_let = (&(global_const_workspace_68_var[750960]));
  void* fused_nn_conv2d_subtract_add_constant_45_let = (&(global_const_workspace_68_var[751344]));
  void* fused_nn_conv2d_constant_15_let = (&(global_const_workspace_68_var[755184]));
  void* fused_nn_conv2d_subtract_constant_15_let = (&(global_const_workspace_68_var[747120]));
  void* fused_constant_21_let = (&(global_const_workspace_68_var[612528]));
  void* pad_temp_let = (&(global_workspace_69_var[8064]));
  void* conv2d_nhwc_let = (&(global_workspace_69_var[8088]));
  for (int32_t i3 = 0; i3 < 24; ++i3) {
    ((int8_t*)pad_temp_let)[i3] = p0[i3];
  }
  for (int32_t ax3 = 0; ax3 < 96; ++ax3) {
    ((int32_t*)conv2d_nhwc_let)[0] = 0;
    for (int32_t rc = 0; rc < 24; ++rc) {
      ((int32_t*)conv2d_nhwc_let)[0] = (((int32_t*)conv2d_nhwc_let)[0] + (((int32_t)((int8_t*)pad_temp_let)[rc]) * ((int32_t)((int8_t*)fused_constant_21_let)[((rc * 96) + ax3)])));
    }
    int32_t v_ = ((int32_t)(((((int64_t)((((int32_t*)conv2d_nhwc_let)[0] + ((int32_t*)fused_nn_conv2d_subtract_constant_15_let)[ax3]) - ((int32_t*)fused_nn_conv2d_constant_15_let)[ax3])) * ((int64_t)((int32_t*)fused_nn_conv2d_subtract_add_constant_45_let)[ax3])) + ((int64_t)1 << ((int64_t)((((int32_t*)fused_nn_conv2d_subtract_add_constant_47_let)[ax3] + 31) - 1)))) >> ((int64_t)(((int32_t*)fused_nn_conv2d_subtract_add_constant_47_let)[ax3] + 31)))) - 128;
    int32_t v__1 = (v_) < (127) ? (v_) : (127);
    int32_t v__2 = ((int32_t)(((((int64_t)((((int32_t*)conv2d_nhwc_let)[0] + ((int32_t*)fused_nn_conv2d_subtract_constant_15_let)[ax3]) - ((int32_t*)fused_nn_conv2d_constant_15_let)[ax3])) * ((int64_t)((int32_t*)fused_nn_conv2d_subtract_add_constant_45_let)[ax3])) + ((int64_t)1 << ((int64_t)((((int32_t*)fused_nn_conv2d_subtract_add_constant_47_let)[ax3] + 31) - 1)))) >> ((int64_t)(((int32_t*)fused_nn_conv2d_subtract_add_constant_47_let)[ax3] + 31)))) - 128;
    int32_t v__3 = (v__2) < (127) ? (v__2) : (127);
    int32_t v__4 = ((int32_t)(((((0 != 0) ? (((int64_t)((((v__1) > (-128) ? (v__1) : (-128)) * 255) + 32640)) << ((int64_t)0)) : ((int64_t)((((v__3) > (-128) ? (v__3) : (-128)) * 255) + 32640))) * (int64_t)1077952511) + ((int64_t)1 << ((int64_t)((7 + 31) - 1)))) >> ((int64_t)(7 + 31)))) - 128;
    int32_t v__5 = (v__4) < (127) ? (v__4) : (127);
    T_subtract[ax3] = (((v__5) > (-128) ? (v__5) : (-128)) + 128);
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_subtract_mul_add8c47b972ae6c2__2(int8_t* p0, int32_t* T_subtract, uint8_t* global_const_workspace_106_var, uint8_t* global_workspace_107_var) {
  void* fused_nn_conv2d_subtract_add_constant_68_let = (&(global_const_workspace_106_var[714768]));
  void* fused_nn_conv2d_subtract_add_constant_67_let = (&(global_const_workspace_106_var[715536]));
  void* fused_nn_conv2d_subtract_add_constant_66_let = (&(global_const_workspace_106_var[716304]));
  void* fused_nn_conv2d_constant_22_let = (&(global_const_workspace_106_var[723984]));
  void* fused_nn_conv2d_subtract_constant_22_let = (&(global_const_workspace_106_var[707856]));
  void* fused_constant_33_let = (&(global_const_workspace_106_var[455904]));
  void* pad_temp_let = (&(global_workspace_107_var[53504]));
  void* conv2d_nhwc_let = (&(global_workspace_107_var[53248]));
  for (int32_t i3 = 0; i3 < 48; ++i3) {
    ((int8_t*)pad_temp_let)[i3] = p0[i3];
  }
  for (int32_t ax3_outer = 0; ax3_outer < 3; ++ax3_outer) {
    for (int32_t ff = 0; ff < 64; ++ff) {
      ((int32_t*)conv2d_nhwc_let)[ff] = 0;
      for (int32_t rc = 0; rc < 48; ++rc) {
        ((int32_t*)conv2d_nhwc_let)[ff] = (((int32_t*)conv2d_nhwc_let)[ff] + (((int32_t)((int8_t*)pad_temp_let)[rc]) * ((int32_t)((int8_t*)fused_constant_33_let)[(((rc * 192) + (ax3_outer * 64)) + ff)])));
      }
    }
    for (int32_t ax3_inner = 0; ax3_inner < 64; ++ax3_inner) {
      int32_t cse_var_1 = ((ax3_outer * 64) + ax3_inner);
      int32_t v_ = ((int32_t)(((((int64_t)((((int32_t*)conv2d_nhwc_let)[ax3_inner] + ((int32_t*)fused_nn_conv2d_subtract_constant_22_let)[cse_var_1]) - ((int32_t*)fused_nn_conv2d_constant_22_let)[cse_var_1])) * ((int64_t)((int32_t*)fused_nn_conv2d_subtract_add_constant_66_let)[cse_var_1])) + ((int64_t)1 << ((int64_t)((((int32_t*)fused_nn_conv2d_subtract_add_constant_68_let)[cse_var_1] + 31) - 1)))) >> ((int64_t)(((int32_t*)fused_nn_conv2d_subtract_add_constant_68_let)[cse_var_1] + 31)))) - 128;
      int32_t v__1 = (v_) < (127) ? (v_) : (127);
      int32_t v__2 = ((int32_t)(((((0 != 0) ? (((int64_t)((((v__1) > (-128) ? (v__1) : (-128)) * 255) + 32640)) << ((int64_t)0)) : ((int64_t)((((v__1) > (-128) ? (v__1) : (-128)) * 255) + 32640))) * (int64_t)1077952511) + ((int64_t)1 << ((int64_t)((7 + 31) - 1)))) >> ((int64_t)(7 + 31)))) - 128;
      int32_t v__3 = (v__2) < (127) ? (v__2) : (127);
      T_subtract[cse_var_1] = (((v__3) > (-128) ? (v__3) : (-128)) + 128);
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_subtract_mul_add8c47b972ae6c2__3(int8_t* p0, int32_t* T_subtract, uint8_t* global_const_workspace_122_var, uint8_t* global_workspace_123_var) {
  void* fused_nn_conv2d_subtract_add_constant_77_let = (&(global_const_workspace_122_var[710160]));
  void* fused_nn_conv2d_subtract_add_constant_76_let = (&(global_const_workspace_122_var[710928]));
  void* fused_nn_conv2d_subtract_add_constant_75_let = (&(global_const_workspace_122_var[711696]));
  void* fused_nn_conv2d_constant_26_let = (&(global_const_workspace_122_var[721680]));
  void* fused_nn_conv2d_subtract_constant_25_let = (&(global_const_workspace_122_var[706320]));
  void* fused_constant_38_let = (&(global_const_workspace_122_var[437472]));
  void* pad_temp_let = (&(global_workspace_123_var[52992]));
  void* conv2d_nhwc_let = (&(global_workspace_123_var[52736]));
  for (int32_t i3 = 0; i3 < 48; ++i3) {
    ((int8_t*)pad_temp_let)[i3] = p0[i3];
  }
  for (int32_t ax3_outer = 0; ax3_outer < 3; ++ax3_outer) {
    for (int32_t ff = 0; ff < 64; ++ff) {
      ((int32_t*)conv2d_nhwc_let)[ff] = 0;
      for (int32_t rc = 0; rc < 48; ++rc) {
        ((int32_t*)conv2d_nhwc_let)[ff] = (((int32_t*)conv2d_nhwc_let)[ff] + (((int32_t)((int8_t*)pad_temp_let)[rc]) * ((int32_t)((int8_t*)fused_constant_38_let)[(((rc * 192) + (ax3_outer * 64)) + ff)])));
      }
    }
    for (int32_t ax3_inner = 0; ax3_inner < 64; ++ax3_inner) {
      int32_t cse_var_1 = ((ax3_outer * 64) + ax3_inner);
      int32_t v_ = ((int32_t)(((((int64_t)((((int32_t*)conv2d_nhwc_let)[ax3_inner] + ((int32_t*)fused_nn_conv2d_subtract_constant_25_let)[cse_var_1]) - ((int32_t*)fused_nn_conv2d_constant_26_let)[cse_var_1])) * ((int64_t)((int32_t*)fused_nn_conv2d_subtract_add_constant_75_let)[cse_var_1])) + ((int64_t)1 << ((int64_t)((((int32_t*)fused_nn_conv2d_subtract_add_constant_77_let)[cse_var_1] + 31) - 1)))) >> ((int64_t)(((int32_t*)fused_nn_conv2d_subtract_add_constant_77_let)[cse_var_1] + 31)))) - 128;
      int32_t v__1 = (v_) < (127) ? (v_) : (127);
      int32_t v__2 = ((int32_t)(((((0 != 0) ? (((int64_t)((((v__1) > (-128) ? (v__1) : (-128)) * 255) + 32640)) << ((int64_t)0)) : ((int64_t)((((v__1) > (-128) ? (v__1) : (-128)) * 255) + 32640))) * (int64_t)1077952511) + ((int64_t)1 << ((int64_t)((7 + 31) - 1)))) >> ((int64_t)(7 + 31)))) - 128;
      int32_t v__3 = (v__2) < (127) ? (v__2) : (127);
      T_subtract[cse_var_1] = (((v__3) > (-128) ? (v__3) : (-128)) + 128);
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_subtract_mul_add8c47b972ae6c2__4(int8_t* p0, int32_t* T_subtract, uint8_t* global_const_workspace_158_var, uint8_t* global_workspace_159_var) {
  void* fused_nn_conv2d_subtract_add_constant_101_let = (&(global_const_workspace_158_var[739040]));
  void* fused_nn_conv2d_subtract_add_constant_100_let = (&(global_const_workspace_158_var[739520]));
  void* fused_nn_conv2d_subtract_add_constant_99_let = (&(global_const_workspace_158_var[735680]));
  void* fused_nn_conv2d_constant_35_let = (&(global_const_workspace_158_var[740000]));
  void* fused_nn_conv2d_subtract_constant_33_let = (&(global_const_workspace_158_var[734240]));
  void* fused_constant_49_let = (&(global_const_workspace_158_var[582448]));
  void* pad_temp_let = (&(global_workspace_159_var[53216]));
  void* conv2d_nhwc_let = (&(global_workspace_159_var[53248]));
  for (int32_t i3 = 0; i3 < 32; ++i3) {
    ((int8_t*)pad_temp_let)[i3] = p0[i3];
  }
  for (int32_t ax3 = 0; ax3 < 120; ++ax3) {
    ((int32_t*)conv2d_nhwc_let)[0] = 0;
    for (int32_t rc = 0; rc < 32; ++rc) {
      ((int32_t*)conv2d_nhwc_let)[0] = (((int32_t*)conv2d_nhwc_let)[0] + (((int32_t)((int8_t*)pad_temp_let)[rc]) * ((int32_t)((int8_t*)fused_constant_49_let)[((rc * 120) + ax3)])));
    }
    int32_t v_ = ((int32_t)(((((int64_t)((((int32_t*)conv2d_nhwc_let)[0] + ((int32_t*)fused_nn_conv2d_subtract_constant_33_let)[ax3]) - ((int32_t*)fused_nn_conv2d_constant_35_let)[ax3])) * ((int64_t)((int32_t*)fused_nn_conv2d_subtract_add_constant_99_let)[ax3])) + ((int64_t)1 << ((int64_t)((((int32_t*)fused_nn_conv2d_subtract_add_constant_101_let)[ax3] + 31) - 1)))) >> ((int64_t)(((int32_t*)fused_nn_conv2d_subtract_add_constant_101_let)[ax3] + 31)))) - 128;
    int32_t v__1 = (v_) < (127) ? (v_) : (127);
    int32_t v__2 = ((int32_t)(((((int64_t)((((int32_t*)conv2d_nhwc_let)[0] + ((int32_t*)fused_nn_conv2d_subtract_constant_33_let)[ax3]) - ((int32_t*)fused_nn_conv2d_constant_35_let)[ax3])) * ((int64_t)((int32_t*)fused_nn_conv2d_subtract_add_constant_99_let)[ax3])) + ((int64_t)1 << ((int64_t)((((int32_t*)fused_nn_conv2d_subtract_add_constant_101_let)[ax3] + 31) - 1)))) >> ((int64_t)(((int32_t*)fused_nn_conv2d_subtract_add_constant_101_let)[ax3] + 31)))) - 128;
    int32_t v__3 = (v__2) < (127) ? (v__2) : (127);
    int32_t v__4 = ((int32_t)(((((0 != 0) ? (((int64_t)((((v__1) > (-128) ? (v__1) : (-128)) * 255) + 32640)) << ((int64_t)0)) : ((int64_t)((((v__3) > (-128) ? (v__3) : (-128)) * 255) + 32640))) * (int64_t)1077952511) + ((int64_t)1 << ((int64_t)((7 + 31) - 1)))) >> ((int64_t)(7 + 31)))) - 128;
    int32_t v__5 = (v__4) < (127) ? (v__4) : (127);
    T_subtract[ax3] = (((v__5) > (-128) ? (v__5) : (-128)) + 128);
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_subtract_mul_add8c47b972ae6c2__5(int8_t* p0, int32_t* T_subtract, uint8_t* global_const_workspace_176_var, uint8_t* global_workspace_177_var) {
  void* fused_nn_conv2d_subtract_add_constant_113_let = (&(global_const_workspace_176_var[694000]));
  void* fused_nn_conv2d_subtract_add_constant_112_let = (&(global_const_workspace_176_var[694960]));
  void* fused_nn_conv2d_subtract_add_constant_111_let = (&(global_const_workspace_176_var[695920]));
  void* fused_nn_conv2d_constant_39_let = (&(global_const_workspace_176_var[702640]));
  void* fused_nn_conv2d_subtract_constant_37_let = (&(global_const_workspace_176_var[691120]));
  void* fused_constant_54_let = (&(global_const_workspace_176_var[366336]));
  void* pad_temp_let = (&(global_workspace_177_var[52736]));
  void* conv2d_nhwc_let = (&(global_workspace_177_var[52800]));
  for (int32_t i3 = 0; i3 < 64; ++i3) {
    ((int8_t*)pad_temp_let)[i3] = p0[i3];
  }
  for (int32_t ax3 = 0; ax3 < 240; ++ax3) {
    ((int32_t*)conv2d_nhwc_let)[0] = 0;
    for (int32_t rc = 0; rc < 64; ++rc) {
      ((int32_t*)conv2d_nhwc_let)[0] = (((int32_t*)conv2d_nhwc_let)[0] + (((int32_t)((int8_t*)pad_temp_let)[rc]) * ((int32_t)((int8_t*)fused_constant_54_let)[((rc * 240) + ax3)])));
    }
    int32_t v_ = ((int32_t)(((((int64_t)((((int32_t*)conv2d_nhwc_let)[0] + ((int32_t*)fused_nn_conv2d_subtract_constant_37_let)[ax3]) - ((int32_t*)fused_nn_conv2d_constant_39_let)[ax3])) * ((int64_t)((int32_t*)fused_nn_conv2d_subtract_add_constant_111_let)[ax3])) + ((int64_t)1 << ((int64_t)((((int32_t*)fused_nn_conv2d_subtract_add_constant_113_let)[ax3] + 31) - 1)))) >> ((int64_t)(((int32_t*)fused_nn_conv2d_subtract_add_constant_113_let)[ax3] + 31)))) - 128;
    int32_t v__1 = (v_) < (127) ? (v_) : (127);
    int32_t v__2 = ((int32_t)(((((int64_t)((((int32_t*)conv2d_nhwc_let)[0] + ((int32_t*)fused_nn_conv2d_subtract_constant_37_let)[ax3]) - ((int32_t*)fused_nn_conv2d_constant_39_let)[ax3])) * ((int64_t)((int32_t*)fused_nn_conv2d_subtract_add_constant_111_let)[ax3])) + ((int64_t)1 << ((int64_t)((((int32_t*)fused_nn_conv2d_subtract_add_constant_113_let)[ax3] + 31) - 1)))) >> ((int64_t)(((int32_t*)fused_nn_conv2d_subtract_add_constant_113_let)[ax3] + 31)))) - 128;
    int32_t v__3 = (v__2) < (127) ? (v__2) : (127);
    int32_t v__4 = ((int32_t)(((((0 != 0) ? (((int64_t)((((v__1) > (-128) ? (v__1) : (-128)) * 255) + 32640)) << ((int64_t)0)) : ((int64_t)((((v__3) > (-128) ? (v__3) : (-128)) * 255) + 32640))) * (int64_t)1077952511) + ((int64_t)1 << ((int64_t)((7 + 31) - 1)))) >> ((int64_t)(7 + 31)))) - 128;
    int32_t v__5 = (v__4) < (127) ? (v__4) : (127);
    T_subtract[ax3] = (((v__5) > (-128) ? (v__5) : (-128)) + 128);
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_subtract_mul_add8c47b972ae6c2__6(int8_t* p0, int32_t* T_subtract, uint8_t* global_const_workspace_194_var, uint8_t* global_workspace_195_var) {
  void* fused_nn_conv2d_subtract_add_constant_128_let = (&(global_const_workspace_194_var[660592]));
  void* fused_nn_conv2d_subtract_add_constant_127_let = (&(global_const_workspace_194_var[662320]));
  void* fused_nn_conv2d_subtract_add_constant_126_let = (&(global_const_workspace_194_var[664048]));
  void* fused_nn_conv2d_constant_44_let = (&(global_const_workspace_194_var[683056]));
  void* fused_nn_conv2d_subtract_constant_42_let = (&(global_const_workspace_194_var[634672]));
  void* fused_constant_60_let = (&(global_const_workspace_194_var[96768]));
  void* pad_temp_let = (&(global_workspace_195_var[54288]));
  void* conv2d_nhwc_let = (&(global_workspace_195_var[54400]));
  for (int32_t i3 = 0; i3 < 112; ++i3) {
    ((int8_t*)pad_temp_let)[i3] = p0[i3];
  }
  for (int32_t ax3 = 0; ax3 < 432; ++ax3) {
    ((int32_t*)conv2d_nhwc_let)[0] = 0;
    for (int32_t rc = 0; rc < 112; ++rc) {
      ((int32_t*)conv2d_nhwc_let)[0] = (((int32_t*)conv2d_nhwc_let)[0] + (((int32_t)((int8_t*)pad_temp_let)[rc]) * ((int32_t)((int8_t*)fused_constant_60_let)[((rc * 432) + ax3)])));
    }
    int32_t v_ = ((int32_t)(((((int64_t)((((int32_t*)conv2d_nhwc_let)[0] + ((int32_t*)fused_nn_conv2d_subtract_constant_42_let)[ax3]) - ((int32_t*)fused_nn_conv2d_constant_44_let)[ax3])) * ((int64_t)((int32_t*)fused_nn_conv2d_subtract_add_constant_126_let)[ax3])) + ((int64_t)1 << ((int64_t)((((int32_t*)fused_nn_conv2d_subtract_add_constant_128_let)[ax3] + 31) - 1)))) >> ((int64_t)(((int32_t*)fused_nn_conv2d_subtract_add_constant_128_let)[ax3] + 31)))) - 128;
    int32_t v__1 = (v_) < (127) ? (v_) : (127);
    int32_t v__2 = ((int32_t)(((((int64_t)((((int32_t*)conv2d_nhwc_let)[0] + ((int32_t*)fused_nn_conv2d_subtract_constant_42_let)[ax3]) - ((int32_t*)fused_nn_conv2d_constant_44_let)[ax3])) * ((int64_t)((int32_t*)fused_nn_conv2d_subtract_add_constant_126_let)[ax3])) + ((int64_t)1 << ((int64_t)((((int32_t*)fused_nn_conv2d_subtract_add_constant_128_let)[ax3] + 31) - 1)))) >> ((int64_t)(((int32_t*)fused_nn_conv2d_subtract_add_constant_128_let)[ax3] + 31)))) - 128;
    int32_t v__3 = (v__2) < (127) ? (v__2) : (127);
    int32_t v__4 = ((int32_t)(((((0 != 0) ? (((int64_t)((((v__1) > (-128) ? (v__1) : (-128)) * 255) + 32640)) << ((int64_t)0)) : ((int64_t)((((v__3) > (-128) ? (v__3) : (-128)) * 255) + 32640))) * (int64_t)1077952511) + ((int64_t)1 << ((int64_t)((7 + 31) - 1)))) >> ((int64_t)(7 + 31)))) - 128;
    int32_t v__5 = (v__4) < (127) ? (v__4) : (127);
    T_subtract[ax3] = (((v__5) > (-128) ? (v__5) : (-128)) + 128);
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_subtract_mul_add8c47b972ae6c2__7(int8_t* p0, int32_t* T_subtract, uint8_t* global_const_workspace_210_var, uint8_t* global_workspace_211_var) {
  void* fused_nn_conv2d_subtract_add_constant_140_let = (&(global_const_workspace_210_var[645040]));
  void* fused_nn_conv2d_subtract_add_constant_139_let = (&(global_const_workspace_210_var[646768]));
  void* fused_nn_conv2d_subtract_add_constant_138_let = (&(global_const_workspace_210_var[648496]));
  void* fused_nn_conv2d_constant_48_let = (&(global_const_workspace_210_var[677872]));
  void* fused_nn_conv2d_subtract_constant_46_let = (&(global_const_workspace_210_var[629488]));
  void* fused_constant_65_let = (&(global_const_workspace_210_var[0]));
  void* pad_temp_let = (&(global_workspace_211_var[54000]));
  void* conv2d_nhwc_let = (&(global_workspace_211_var[54112]));
  for (int32_t i3 = 0; i3 < 112; ++i3) {
    ((int8_t*)pad_temp_let)[i3] = p0[i3];
  }
  for (int32_t ax3 = 0; ax3 < 432; ++ax3) {
    ((int32_t*)conv2d_nhwc_let)[0] = 0;
    for (int32_t rc = 0; rc < 112; ++rc) {
      ((int32_t*)conv2d_nhwc_let)[0] = (((int32_t*)conv2d_nhwc_let)[0] + (((int32_t)((int8_t*)pad_temp_let)[rc]) * ((int32_t)((int8_t*)fused_constant_65_let)[((rc * 432) + ax3)])));
    }
    int32_t v_ = ((int32_t)(((((int64_t)((((int32_t*)conv2d_nhwc_let)[0] + ((int32_t*)fused_nn_conv2d_subtract_constant_46_let)[ax3]) - ((int32_t*)fused_nn_conv2d_constant_48_let)[ax3])) * ((int64_t)((int32_t*)fused_nn_conv2d_subtract_add_constant_138_let)[ax3])) + ((int64_t)1 << ((int64_t)((((int32_t*)fused_nn_conv2d_subtract_add_constant_140_let)[ax3] + 31) - 1)))) >> ((int64_t)(((int32_t*)fused_nn_conv2d_subtract_add_constant_140_let)[ax3] + 31)))) - 128;
    int32_t v__1 = (v_) < (127) ? (v_) : (127);
    int32_t v__2 = ((int32_t)(((((int64_t)((((int32_t*)conv2d_nhwc_let)[0] + ((int32_t*)fused_nn_conv2d_subtract_constant_46_let)[ax3]) - ((int32_t*)fused_nn_conv2d_constant_48_let)[ax3])) * ((int64_t)((int32_t*)fused_nn_conv2d_subtract_add_constant_138_let)[ax3])) + ((int64_t)1 << ((int64_t)((((int32_t*)fused_nn_conv2d_subtract_add_constant_140_let)[ax3] + 31) - 1)))) >> ((int64_t)(((int32_t*)fused_nn_conv2d_subtract_add_constant_140_let)[ax3] + 31)))) - 128;
    int32_t v__3 = (v__2) < (127) ? (v__2) : (127);
    int32_t v__4 = ((int32_t)(((((0 != 0) ? (((int64_t)((((v__1) > (-128) ? (v__1) : (-128)) * 255) + 32640)) << ((int64_t)0)) : ((int64_t)((((v__3) > (-128) ? (v__3) : (-128)) * 255) + 32640))) * (int64_t)1077952511) + ((int64_t)1 << ((int64_t)((7 + 31) - 1)))) >> ((int64_t)(7 + 31)))) - 128;
    int32_t v__5 = (v__4) < (127) ? (v__4) : (127);
    T_subtract[ax3] = (((v__5) > (-128) ? (v__5) : (-128)) + 128);
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_clip_cast_clip(int8_t* p0, int8_t* compute, uint8_t* global_const_workspace_138_var, uint8_t* global_workspace_139_var) {
  void* fused_nn_conv2d_subtract_add_constant_86_let = (&(global_const_workspace_138_var[779936]));
  void* fused_nn_conv2d_subtract_add_constant_85_let = (&(global_const_workspace_138_var[780032]));
  void* fused_nn_conv2d_subtract_add_constant_84_let = (&(global_const_workspace_138_var[780128]));
  void* fused_nn_conv2d_constant_29_let = (&(global_const_workspace_138_var[781184]));
  void* fused_nn_conv2d_subtract_constant_28_let = (&(global_const_workspace_138_var[779648]));
  void* fused_constant_42_let = (&(global_const_workspace_138_var[610224]));
  void* pad_temp_let = (&(global_workspace_139_var[52736]));
  void* conv2d_nhwc_let = (&(global_workspace_139_var[52856]));
  for (int32_t i3 = 0; i3 < 96; ++i3) {
    ((int8_t*)pad_temp_let)[i3] = p0[i3];
  }
  for (int32_t i3_1 = 0; i3_1 < 24; ++i3_1) {
    ((int32_t*)conv2d_nhwc_let)[0] = 0;
    for (int32_t rc = 0; rc < 96; ++rc) {
      ((int32_t*)conv2d_nhwc_let)[0] = (((int32_t*)conv2d_nhwc_let)[0] + (((int32_t)((int8_t*)pad_temp_let)[rc]) * ((int32_t)((int8_t*)fused_constant_42_let)[((rc * 24) + i3_1)])));
    }
    int32_t v_ = (int32_t)((((((int64_t)((((int32_t*)conv2d_nhwc_let)[0] + ((int32_t*)fused_nn_conv2d_subtract_constant_28_let)[i3_1]) - ((int32_t*)fused_nn_conv2d_constant_29_let)[i3_1])) << ((int64_t)((int32_t*)fused_nn_conv2d_subtract_add_constant_85_let)[i3_1])) * ((int64_t)((int32_t*)fused_nn_conv2d_subtract_add_constant_84_let)[i3_1])) + ((int64_t)1 << ((int64_t)((((int32_t*)fused_nn_conv2d_subtract_add_constant_86_let)[i3_1] + 31) - 1)))) >> ((int64_t)(((int32_t*)fused_nn_conv2d_subtract_add_constant_86_let)[i3_1] + 31)));
    int32_t v__1 = (v_) < (127) ? (v_) : (127);
    int8_t v__2 = (int8_t)((v__1) > (-128) ? (v__1) : (-128));
    int8_t v__3 = (int8_t)127;
    int8_t v__4 = (v__2) < (v__3) ? (v__2) : (v__3);
    int8_t v__5 = (int8_t)0;
    compute[i3_1] = ((v__4) > (v__5) ? (v__4) : (v__5));
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_clip_cast_multiply_ad_b57e37aeb09540e8_(int8_t* p0, int32_t* T_cast, uint8_t* global_const_workspace_116_var, uint8_t* global_workspace_117_var) {
  void* fused_nn_conv2d_subtract_add_constant_71_let = (&(global_const_workspace_116_var[712464]));
  void* fused_nn_conv2d_subtract_add_constant_70_let = (&(global_const_workspace_116_var[713232]));
  void* fused_nn_conv2d_subtract_add_constant_69_let = (&(global_const_workspace_116_var[714000]));
  void* fused_nn_conv2d_subtract_constant_23_let = (&(global_const_workspace_116_var[707088]));
  void* fused_nn_conv2d_constant_24_let = (&(global_const_workspace_116_var[722448]));
  void* fused_constant_35_let = (&(global_const_workspace_116_var[550416]));
  void* PaddedInput_let = (&(global_workspace_117_var[24576]));
  void* DepthwiseConv2d_let = (&(global_workspace_117_var[36864]));
  void* compute_let = (&(global_workspace_117_var[12288]));
  for (int32_t i1 = 0; i1 < 8; ++i1) {
    for (int32_t i2 = 0; i2 < 8; ++i2) {
      for (int32_t i3 = 0; i3 < 192; ++i3) {
        int32_t cse_var_1 = (((i1 * 1536) + (i2 * 192)) + i3);
        ((int8_t*)PaddedInput_let)[cse_var_1] = p0[cse_var_1];
      }
    }
  }
  for (int32_t i = 0; i < 4; ++i) {
    for (int32_t j = 0; j < 4; ++j) {
      for (int32_t c = 0; c < 192; ++c) {
        ((int32_t*)DepthwiseConv2d_let)[(((i * 768) + (j * 192)) + c)] = 0;
        for (int32_t di = 0; di < 5; ++di) {
          for (int32_t dj = 0; dj < 5; ++dj) {
            int32_t cse_var_4 = (j * 192);
            int32_t cse_var_3 = (dj * 192);
            int32_t cse_var_2 = (((i * 768) + cse_var_4) + c);
            ((int32_t*)DepthwiseConv2d_let)[cse_var_2] = (((int32_t*)DepthwiseConv2d_let)[cse_var_2] + (((int32_t)((int8_t*)PaddedInput_let)[(((((i * 1536) + (di * 1536)) + cse_var_4) + cse_var_3) + c)]) * ((int32_t)((int8_t*)fused_constant_35_let)[(((di * 960) + cse_var_3) + c)])));
          }
        }
      }
    }
  }
  for (int32_t ax1 = 0; ax1 < 4; ++ax1) {
    for (int32_t ax2 = 0; ax2 < 4; ++ax2) {
      for (int32_t ax3 = 0; ax3 < 192; ++ax3) {
        int32_t cse_var_5 = (((ax1 * 768) + (ax2 * 192)) + ax3);
        ((int32_t*)DepthwiseConv2d_let)[cse_var_5] = (((int32_t*)DepthwiseConv2d_let)[cse_var_5] - ((int32_t*)fused_nn_conv2d_constant_24_let)[ax3]);
      }
    }
  }
  for (int32_t ax1_1 = 0; ax1_1 < 4; ++ax1_1) {
    for (int32_t ax2_1 = 0; ax2_1 < 4; ++ax2_1) {
      for (int32_t ax3_1 = 0; ax3_1 < 192; ++ax3_1) {
        int32_t cse_var_6 = (((ax1_1 * 768) + (ax2_1 * 192)) + ax3_1);
        ((int32_t*)DepthwiseConv2d_let)[cse_var_6] = (((int32_t*)DepthwiseConv2d_let)[cse_var_6] + ((int32_t*)fused_nn_conv2d_subtract_constant_23_let)[ax3_1]);
      }
    }
  }
  for (int32_t i1_1 = 0; i1_1 < 4; ++i1_1) {
    for (int32_t i2_1 = 0; i2_1 < 4; ++i2_1) {
      for (int32_t i3_1 = 0; i3_1 < 192; ++i3_1) {
        int32_t cse_var_7 = (((i1_1 * 768) + (i2_1 * 192)) + i3_1);
        ((int32_t*)DepthwiseConv2d_let)[cse_var_7] = ((int32_t)(((((int64_t)((int32_t*)DepthwiseConv2d_let)[cse_var_7]) * ((int64_t)((int32_t*)fused_nn_conv2d_subtract_add_constant_69_let)[i3_1])) + ((int64_t)1 << ((int64_t)((((int32_t*)fused_nn_conv2d_subtract_add_constant_71_let)[i3_1] + 31) - 1)))) >> ((int64_t)(((int32_t*)fused_nn_conv2d_subtract_add_constant_71_let)[i3_1] + 31))));
      }
    }
  }
  for (int32_t i1_2 = 0; i1_2 < 4; ++i1_2) {
    for (int32_t i2_2 = 0; i2_2 < 4; ++i2_2) {
      for (int32_t i3_2 = 0; i3_2 < 192; ++i3_2) {
        int32_t cse_var_8 = (((i1_2 * 768) + (i2_2 * 192)) + i3_2);
        int32_t v_ = ((int32_t*)DepthwiseConv2d_let)[cse_var_8];
        int32_t v__1 = (v_) < (127) ? (v_) : (127);
        ((int32_t*)DepthwiseConv2d_let)[cse_var_8] = ((v__1) > (-128) ? (v__1) : (-128));
      }
    }
  }
  for (int32_t ax1_2 = 0; ax1_2 < 4; ++ax1_2) {
    for (int32_t ax2_2 = 0; ax2_2 < 4; ++ax2_2) {
      for (int32_t ax3_2 = 0; ax3_2 < 192; ++ax3_2) {
        int32_t cse_var_9 = (((ax1_2 * 768) + (ax2_2 * 192)) + ax3_2);
        ((float*)PaddedInput_let)[cse_var_9] = ((float)((int32_t*)DepthwiseConv2d_let)[cse_var_9]);
      }
    }
  }
  for (int32_t ax1_3 = 0; ax1_3 < 4; ++ax1_3) {
    for (int32_t ax2_3 = 0; ax2_3 < 4; ++ax2_3) {
      for (int32_t ax3_3 = 0; ax3_3 < 192; ++ax3_3) {
        int32_t cse_var_10 = (((ax1_3 * 768) + (ax2_3 * 192)) + ax3_3);
        ((float*)DepthwiseConv2d_let)[cse_var_10] = (((float*)PaddedInput_let)[cse_var_10] * 2.720976e-01f);
      }
    }
  }
  for (int32_t ax1_4 = 0; ax1_4 < 4; ++ax1_4) {
    for (int32_t ax2_4 = 0; ax2_4 < 4; ++ax2_4) {
      for (int32_t ax3_4 = 0; ax3_4 < 192; ++ax3_4) {
        int32_t cse_var_11 = (((ax1_4 * 768) + (ax2_4 * 192)) + ax3_4);
        ((float*)PaddedInput_let)[cse_var_11] = (((float*)DepthwiseConv2d_let)[cse_var_11] + 3.000000e+00f);
      }
    }
  }
  for (int32_t i1_3 = 0; i1_3 < 4; ++i1_3) {
    for (int32_t i2_3 = 0; i2_3 < 4; ++i2_3) {
      for (int32_t i3_3 = 0; i3_3 < 192; ++i3_3) {
        int32_t cse_var_12 = (((i1_3 * 768) + (i2_3 * 192)) + i3_3);
        float v__2 = ((float*)PaddedInput_let)[cse_var_12];
        float v__3 = (v__2) < (6.000000e+00f) ? (v__2) : (6.000000e+00f);
        ((float*)compute_let)[cse_var_12] = ((v__3) > (0.000000e+00f) ? (v__3) : (0.000000e+00f));
      }
    }
  }
  for (int32_t ax1_5 = 0; ax1_5 < 4; ++ax1_5) {
    for (int32_t ax2_5 = 0; ax2_5 < 4; ++ax2_5) {
      for (int32_t ax3_5 = 0; ax3_5 < 192; ++ax3_5) {
        int32_t cse_var_13 = (((ax1_5 * 768) + (ax2_5 * 192)) + ax3_5);
        ((float*)compute_let)[cse_var_13] = (((float*)DepthwiseConv2d_let)[cse_var_13] * ((float*)compute_let)[cse_var_13]);
      }
    }
  }
  for (int32_t ax1_6 = 0; ax1_6 < 4; ++ax1_6) {
    for (int32_t ax2_6 = 0; ax2_6 < 4; ++ax2_6) {
      for (int32_t ax3_6 = 0; ax3_6 < 192; ++ax3_6) {
        int32_t cse_var_14 = (((ax1_6 * 768) + (ax2_6 * 192)) + ax3_6);
        ((float*)compute_let)[cse_var_14] = (((float*)compute_let)[cse_var_14] * 1.666667e-01f);
      }
    }
  }
  for (int32_t ax1_7 = 0; ax1_7 < 4; ++ax1_7) {
    for (int32_t ax2_7 = 0; ax2_7 < 4; ++ax2_7) {
      for (int32_t ax3_7 = 0; ax3_7 < 192; ++ax3_7) {
        int32_t cse_var_15 = (((ax1_7 * 768) + (ax2_7 * 192)) + ax3_7);
        ((float*)compute_let)[cse_var_15] = (((float*)compute_let)[cse_var_15] * 7.312656e+00f);
      }
    }
  }
  for (int32_t ax1_8 = 0; ax1_8 < 4; ++ax1_8) {
    for (int32_t ax2_8 = 0; ax2_8 < 4; ++ax2_8) {
      for (int32_t ax3_8 = 0; ax3_8 < 192; ++ax3_8) {
        int32_t cse_var_16 = (((ax1_8 * 768) + (ax2_8 * 192)) + ax3_8);
        ((float*)compute_let)[cse_var_16] = roundf(((float*)compute_let)[cse_var_16]);
      }
    }
  }
  for (int32_t ax1_9 = 0; ax1_9 < 4; ++ax1_9) {
    for (int32_t ax2_9 = 0; ax2_9 < 4; ++ax2_9) {
      for (int32_t ax3_9 = 0; ax3_9 < 192; ++ax3_9) {
        int32_t cse_var_17 = (((ax1_9 * 768) + (ax2_9 * 192)) + ax3_9);
        ((float*)compute_let)[cse_var_17] = (((float*)compute_let)[cse_var_17] + -1.250000e+02f);
      }
    }
  }
  for (int32_t i1_4 = 0; i1_4 < 4; ++i1_4) {
    for (int32_t i2_4 = 0; i2_4 < 4; ++i2_4) {
      for (int32_t i3_4 = 0; i3_4 < 192; ++i3_4) {
        int32_t cse_var_18 = (((i1_4 * 768) + (i2_4 * 192)) + i3_4);
        float v__4 = ((float*)compute_let)[cse_var_18];
        float v__5 = (v__4) < (1.270000e+02f) ? (v__4) : (1.270000e+02f);
        ((float*)compute_let)[cse_var_18] = ((v__5) > (-1.280000e+02f) ? (v__5) : (-1.280000e+02f));
      }
    }
  }
  for (int32_t ax1_10 = 0; ax1_10 < 4; ++ax1_10) {
    for (int32_t ax2_10 = 0; ax2_10 < 4; ++ax2_10) {
      for (int32_t ax3_10 = 0; ax3_10 < 192; ++ax3_10) {
        int32_t cse_var_19 = (((ax1_10 * 768) + (ax2_10 * 192)) + ax3_10);
        T_cast[cse_var_19] = ((int32_t)((float*)compute_let)[cse_var_19]);
      }
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_pad(int8_t* p0, int8_t* T_pad, uint8_t* global_const_workspace_6_var, uint8_t* global_workspace_7_var) {
  for (int32_t ax0_ax1_fused = 0; ax0_ax1_fused < 33; ++ax0_ax1_fused) {
    for (int32_t ax2 = 0; ax2 < 33; ++ax2) {
      for (int32_t ax3_inner = 0; ax3_inner < 16; ++ax3_inner) {
        int32_t cse_var_1 = (ax2 * 16);
        T_pad[(((ax0_ax1_fused * 528) + cse_var_1) + ax3_inner)] = (((ax0_ax1_fused < 32) && (ax2 < 32)) ? p0[(((ax0_ax1_fused * 512) + cse_var_1) + ax3_inner)] : (int8_t)-125);
      }
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_pad_1(int8_t* p0, int8_t* T_pad, uint8_t* global_const_workspace_24_var, uint8_t* global_workspace_25_var) {
  for (int32_t ax0_ax1_fused = 0; ax0_ax1_fused < 17; ++ax0_ax1_fused) {
    for (int32_t ax2 = 0; ax2 < 17; ++ax2) {
      for (int32_t ax3_outer = 0; ax3_outer < 5; ++ax3_outer) {
        for (int32_t ax3_inner = 0; ax3_inner < 16; ++ax3_inner) {
          if (((ax3_outer * 2) + (ax3_inner >> 3)) < 9) {
            int32_t cse_var_2 = (ax2 * 72);
            int32_t cse_var_1 = (ax3_outer * 16);
            T_pad[((((ax0_ax1_fused * 1224) + cse_var_2) + cse_var_1) + ax3_inner)] = (((ax0_ax1_fused < 16) && (ax2 < 16)) ? p0[((((ax0_ax1_fused * 1152) + cse_var_2) + cse_var_1) + ax3_inner)] : (int8_t)-128);
          }
        }
      }
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_pad_10(int8_t* p0, int8_t* T_pad, uint8_t* global_const_workspace_148_var, uint8_t* global_workspace_149_var) {
  for (int32_t ax0_ax1_fused = 0; ax0_ax1_fused < 8; ++ax0_ax1_fused) {
    for (int32_t ax2 = 0; ax2 < 8; ++ax2) {
      for (int32_t ax3_outer = 0; ax3_outer < 8; ++ax3_outer) {
        for (int32_t ax3_inner = 0; ax3_inner < 16; ++ax3_inner) {
          if (((ax3_outer * 2) + (ax3_inner >> 3)) < 15) {
            int32_t cse_var_2 = (ax2 * 120);
            int32_t cse_var_1 = (ax3_outer * 16);
            T_pad[((((ax0_ax1_fused * 960) + cse_var_2) + cse_var_1) + ax3_inner)] = (((((2 <= ax0_ax1_fused) && (ax0_ax1_fused < 6)) && (2 <= ax2)) && (ax2 < 6)) ? p0[(((((ax0_ax1_fused * 480) + cse_var_2) + cse_var_1) + ax3_inner) - 1200)] : (int8_t)-122);
          }
        }
      }
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_pad_11(int8_t* p0, int8_t* T_pad, uint8_t* global_const_workspace_166_var, uint8_t* global_workspace_167_var) {
  for (int32_t ax0_ax1_fused = 0; ax0_ax1_fused < 7; ++ax0_ax1_fused) {
    for (int32_t ax2 = 0; ax2 < 7; ++ax2) {
      for (int32_t ax3_outer = 0; ax3_outer < 15; ++ax3_outer) {
        for (int32_t ax3_inner = 0; ax3_inner < 16; ++ax3_inner) {
          int32_t cse_var_2 = (ax2 * 240);
          int32_t cse_var_1 = (ax3_outer * 16);
          T_pad[((((ax0_ax1_fused * 1680) + cse_var_2) + cse_var_1) + ax3_inner)] = (((((1 <= ax0_ax1_fused) && (ax0_ax1_fused < 5)) && (1 <= ax2)) && (ax2 < 5)) ? p0[(((((ax0_ax1_fused * 960) + cse_var_2) + cse_var_1) + ax3_inner) - 1200)] : (int8_t)-122);
        }
      }
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_pad_12(int8_t* p0, int8_t* T_pad, uint8_t* global_const_workspace_184_var, uint8_t* global_workspace_185_var) {
  for (int32_t ax0_ax1_fused = 0; ax0_ax1_fused < 6; ++ax0_ax1_fused) {
    for (int32_t ax2 = 0; ax2 < 6; ++ax2) {
      for (int32_t ax3_outer = 0; ax3_outer < 27; ++ax3_outer) {
        for (int32_t ax3_inner = 0; ax3_inner < 16; ++ax3_inner) {
          int32_t cse_var_2 = (ax2 * 432);
          int32_t cse_var_1 = (ax3_outer * 16);
          T_pad[((((ax0_ax1_fused * 2592) + cse_var_2) + cse_var_1) + ax3_inner)] = (((((2 <= ax0_ax1_fused) && (ax0_ax1_fused < 4)) && (2 <= ax2)) && (ax2 < 4)) ? p0[(((((ax0_ax1_fused * 864) + cse_var_2) + cse_var_1) + ax3_inner) - 2592)] : (int8_t)-123);
        }
      }
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_pad_13(int8_t* p0, int8_t* T_pad, uint8_t* global_const_workspace_202_var, uint8_t* global_workspace_203_var) {
  for (int32_t ax0_ax1_fused = 0; ax0_ax1_fused < 6; ++ax0_ax1_fused) {
    for (int32_t ax2 = 0; ax2 < 6; ++ax2) {
      for (int32_t ax3_outer = 0; ax3_outer < 27; ++ax3_outer) {
        for (int32_t ax3_inner = 0; ax3_inner < 16; ++ax3_inner) {
          int32_t cse_var_2 = (ax2 * 432);
          int32_t cse_var_1 = (ax3_outer * 16);
          T_pad[((((ax0_ax1_fused * 2592) + cse_var_2) + cse_var_1) + ax3_inner)] = (((((2 <= ax0_ax1_fused) && (ax0_ax1_fused < 4)) && (2 <= ax2)) && (ax2 < 4)) ? p0[(((((ax0_ax1_fused * 864) + cse_var_2) + cse_var_1) + ax3_inner) - 2592)] : (int8_t)-127);
        }
      }
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_pad_14(int8_t* p0, int8_t* T_pad, uint8_t* global_const_workspace_226_var, uint8_t* global_workspace_227_var) {
  for (int32_t ax0_ax1_fused = 0; ax0_ax1_fused < 6; ++ax0_ax1_fused) {
    for (int32_t ax2 = 0; ax2 < 6; ++ax2) {
      for (int32_t ax3_outer = 0; ax3_outer < 2; ++ax3_outer) {
        for (int32_t ax3_inner = 0; ax3_inner < 16; ++ax3_inner) {
          int32_t cse_var_2 = (ax2 * 32);
          int32_t cse_var_1 = (ax3_outer * 16);
          T_pad[((((ax0_ax1_fused * 192) + cse_var_2) + cse_var_1) + ax3_inner)] = (((((1 <= ax0_ax1_fused) && (ax0_ax1_fused < 5)) && (1 <= ax2)) && (ax2 < 5)) ? p0[(((((ax0_ax1_fused * 128) + cse_var_2) + cse_var_1) + ax3_inner) - 160)] : (int8_t)0);
        }
      }
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_pad_15(int8_t* p0, int8_t* T_pad, uint8_t* global_const_workspace_230_var, uint8_t* global_workspace_231_var) {
  for (int32_t ax0_ax1_fused = 0; ax0_ax1_fused < 6; ++ax0_ax1_fused) {
    for (int32_t ax2 = 0; ax2 < 6; ++ax2) {
      for (int32_t ax3_outer = 0; ax3_outer < 2; ++ax3_outer) {
        for (int32_t ax3_inner = 0; ax3_inner < 16; ++ax3_inner) {
          int32_t cse_var_2 = (ax2 * 32);
          int32_t cse_var_1 = (ax3_outer * 16);
          T_pad[((((ax0_ax1_fused * 192) + cse_var_2) + cse_var_1) + ax3_inner)] = (((((1 <= ax0_ax1_fused) && (ax0_ax1_fused < 5)) && (1 <= ax2)) && (ax2 < 5)) ? p0[(((((ax0_ax1_fused * 128) + cse_var_2) + cse_var_1) + ax3_inner) - 160)] : (int8_t)-128);
        }
      }
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_pad_2(int8_t* p0, int8_t* T_pad, uint8_t* global_const_workspace_32_var, uint8_t* global_workspace_33_var) {
  for (int32_t ax0_ax1_fused = 0; ax0_ax1_fused < 10; ++ax0_ax1_fused) {
    for (int32_t ax2 = 0; ax2 < 10; ++ax2) {
      for (int32_t ax3_outer = 0; ax3_outer < 6; ++ax3_outer) {
        for (int32_t ax3_inner = 0; ax3_inner < 16; ++ax3_inner) {
          if (((ax3_outer * 2) + (ax3_inner >> 3)) < 11) {
            int32_t cse_var_2 = (ax2 * 88);
            int32_t cse_var_1 = (ax3_outer * 16);
            T_pad[((((ax0_ax1_fused * 880) + cse_var_2) + cse_var_1) + ax3_inner)] = (((((1 <= ax0_ax1_fused) && (ax0_ax1_fused < 9)) && (1 <= ax2)) && (ax2 < 9)) ? p0[(((((ax0_ax1_fused * 704) + cse_var_2) + cse_var_1) + ax3_inner) - 792)] : (int8_t)-128);
          }
        }
      }
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_pad_3(int8_t* p0, int8_t* T_pad, uint8_t* global_const_workspace_38_var, uint8_t* global_workspace_39_var) {
  for (int32_t ax0_ax1_fused = 0; ax0_ax1_fused < 10; ++ax0_ax1_fused) {
    for (int32_t ax2 = 0; ax2 < 10; ++ax2) {
      for (int32_t ax3_outer = 0; ax3_outer < 2; ++ax3_outer) {
        for (int32_t ax3_inner = 0; ax3_inner < 16; ++ax3_inner) {
          if (((ax3_outer * 2) + (ax3_inner >> 3)) < 3) {
            int32_t cse_var_2 = (ax2 * 24);
            int32_t cse_var_1 = (ax3_outer * 16);
            T_pad[((((ax0_ax1_fused * 240) + cse_var_2) + cse_var_1) + ax3_inner)] = (((((1 <= ax0_ax1_fused) && (ax0_ax1_fused < 9)) && (1 <= ax2)) && (ax2 < 9)) ? p0[(((((ax0_ax1_fused * 192) + cse_var_2) + cse_var_1) + ax3_inner) - 216)] : (int8_t)-5);
          }
        }
      }
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_pad_4(int8_t* p0, int8_t* T_pad, uint8_t* global_const_workspace_58_var, uint8_t* global_workspace_59_var) {
  for (int32_t ax0_ax1_fused = 0; ax0_ax1_fused < 11; ++ax0_ax1_fused) {
    for (int32_t ax2 = 0; ax2 < 11; ++ax2) {
      for (int32_t ax3_outer = 0; ax3_outer < 6; ++ax3_outer) {
        for (int32_t ax3_inner = 0; ax3_inner < 16; ++ax3_inner) {
          int32_t cse_var_2 = (ax2 * 96);
          int32_t cse_var_1 = (ax3_outer * 16);
          T_pad[((((ax0_ax1_fused * 1056) + cse_var_2) + cse_var_1) + ax3_inner)] = (((((1 <= ax0_ax1_fused) && (ax0_ax1_fused < 9)) && (1 <= ax2)) && (ax2 < 9)) ? p0[(((((ax0_ax1_fused * 768) + cse_var_2) + cse_var_1) + ax3_inner) - 864)] : (int8_t)-126);
        }
      }
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_pad_5(int8_t* p0, int8_t* T_pad, uint8_t* global_const_workspace_74_var, uint8_t* global_workspace_75_var) {
  for (int32_t ax0_ax1_fused = 0; ax0_ax1_fused < 6; ++ax0_ax1_fused) {
    for (int32_t ax2 = 0; ax2 < 6; ++ax2) {
      for (int32_t ax3_outer = 0; ax3_outer < 2; ++ax3_outer) {
        for (int32_t ax3_inner = 0; ax3_inner < 16; ++ax3_inner) {
          int32_t cse_var_2 = (ax2 * 32);
          int32_t cse_var_1 = (ax3_outer * 16);
          T_pad[((((ax0_ax1_fused * 192) + cse_var_2) + cse_var_1) + ax3_inner)] = (((((1 <= ax0_ax1_fused) && (ax0_ax1_fused < 5)) && (1 <= ax2)) && (ax2 < 5)) ? p0[(((((ax0_ax1_fused * 128) + cse_var_2) + cse_var_1) + ax3_inner) - 160)] : (int8_t)-1);
        }
      }
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_pad_6(int8_t* p0, int8_t* T_pad, uint8_t* global_const_workspace_78_var, uint8_t* global_workspace_79_var) {
  for (int32_t ax0_ax1_fused = 0; ax0_ax1_fused < 6; ++ax0_ax1_fused) {
    for (int32_t ax2 = 0; ax2 < 6; ++ax2) {
      for (int32_t ax3_outer = 0; ax3_outer < 2; ++ax3_outer) {
        for (int32_t ax3_inner = 0; ax3_inner < 16; ++ax3_inner) {
          int32_t cse_var_2 = (ax2 * 32);
          int32_t cse_var_1 = (ax3_outer * 16);
          T_pad[((((ax0_ax1_fused * 192) + cse_var_2) + cse_var_1) + ax3_inner)] = (((((1 <= ax0_ax1_fused) && (ax0_ax1_fused < 5)) && (1 <= ax2)) && (ax2 < 5)) ? p0[(((((ax0_ax1_fused * 128) + cse_var_2) + cse_var_1) + ax3_inner) - 160)] : (int8_t)-128);
        }
      }
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_pad_7(int8_t* p0, int8_t* T_pad, uint8_t* global_const_workspace_96_var, uint8_t* global_workspace_97_var) {
  for (int32_t ax0_ax1_fused = 0; ax0_ax1_fused < 8; ++ax0_ax1_fused) {
    for (int32_t ax2 = 0; ax2 < 8; ++ax2) {
      for (int32_t ax3_outer = 0; ax3_outer < 12; ++ax3_outer) {
        for (int32_t ax3_inner = 0; ax3_inner < 16; ++ax3_inner) {
          int32_t cse_var_2 = (ax2 * 192);
          int32_t cse_var_1 = (ax3_outer * 16);
          T_pad[((((ax0_ax1_fused * 1536) + cse_var_2) + cse_var_1) + ax3_inner)] = (((((2 <= ax0_ax1_fused) && (ax0_ax1_fused < 6)) && (2 <= ax2)) && (ax2 < 6)) ? p0[(((((ax0_ax1_fused * 768) + cse_var_2) + cse_var_1) + ax3_inner) - 1920)] : (int8_t)-125);
        }
      }
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_pad_8(int8_t* p0, int8_t* T_pad, uint8_t* global_const_workspace_114_var, uint8_t* global_workspace_115_var) {
  for (int32_t ax0_ax1_fused = 0; ax0_ax1_fused < 8; ++ax0_ax1_fused) {
    for (int32_t ax2 = 0; ax2 < 8; ++ax2) {
      for (int32_t ax3_outer = 0; ax3_outer < 12; ++ax3_outer) {
        for (int32_t ax3_inner = 0; ax3_inner < 16; ++ax3_inner) {
          int32_t cse_var_2 = (ax2 * 192);
          int32_t cse_var_1 = (ax3_outer * 16);
          T_pad[((((ax0_ax1_fused * 1536) + cse_var_2) + cse_var_1) + ax3_inner)] = (((((2 <= ax0_ax1_fused) && (ax0_ax1_fused < 6)) && (2 <= ax2)) && (ax2 < 6)) ? p0[(((((ax0_ax1_fused * 768) + cse_var_2) + cse_var_1) + ax3_inner) - 1920)] : (int8_t)-122);
        }
      }
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_pad_9(int8_t* p0, int8_t* T_pad, uint8_t* global_const_workspace_130_var, uint8_t* global_workspace_131_var) {
  for (int32_t ax0_ax1_fused = 0; ax0_ax1_fused < 8; ++ax0_ax1_fused) {
    for (int32_t ax2 = 0; ax2 < 8; ++ax2) {
      for (int32_t ax3_outer = 0; ax3_outer < 6; ++ax3_outer) {
        for (int32_t ax3_inner = 0; ax3_inner < 16; ++ax3_inner) {
          int32_t cse_var_2 = (ax2 * 96);
          int32_t cse_var_1 = (ax3_outer * 16);
          T_pad[((((ax0_ax1_fused * 768) + cse_var_2) + cse_var_1) + ax3_inner)] = (((((2 <= ax0_ax1_fused) && (ax0_ax1_fused < 6)) && (2 <= ax2)) && (ax2 < 6)) ? p0[(((((ax0_ax1_fused * 384) + cse_var_2) + cse_var_1) + ax3_inner) - 960)] : (int8_t)-122);
        }
      }
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_softmax_divide_round_add_clip_cast_subtract_cast_multiply(float* p0, float* T_multiply, uint8_t* global_const_workspace_52_var, uint8_t* global_workspace_53_var) {
  void* T_softmax_maxelem_let = (&(global_workspace_53_var[34672]));
  void* T_softmax_exp_let = (&(global_workspace_53_var[34632]));
  void* T_softmax_expsum_let = (&(global_workspace_53_var[34672]));
  ((float*)T_softmax_maxelem_let)[0] = -3.402823e+38f;
  for (int32_t k = 0; k < 10; ++k) {
    float v_ = ((float*)T_softmax_maxelem_let)[0];
    float v__1 = p0[k];
    ((float*)T_softmax_maxelem_let)[0] = ((v_) > (v__1) ? (v_) : (v__1));
  }
  for (int32_t i1 = 0; i1 < 10; ++i1) {
    ((float*)T_softmax_exp_let)[i1] = expf((p0[i1] - ((float*)T_softmax_maxelem_let)[0]));
  }
  ((float*)T_softmax_expsum_let)[0] = 0.000000e+00f;
  for (int32_t k_1 = 0; k_1 < 10; ++k_1) {
    ((float*)T_softmax_expsum_let)[0] = (((float*)T_softmax_expsum_let)[0] + ((float*)T_softmax_exp_let)[k_1]);
  }
  for (int32_t i1_1 = 0; i1_1 < 10; ++i1_1) {
    ((float*)T_softmax_exp_let)[i1_1] = (((float*)T_softmax_exp_let)[i1_1] / ((float*)T_softmax_expsum_let)[0]);
  }
  for (int32_t ax1 = 0; ax1 < 10; ++ax1) {
    float v__2 = roundf((((float*)T_softmax_exp_let)[ax1] * 2.560000e+02f)) + -1.280000e+02f;
    float v__3 = (v__2) < (1.270000e+02f) ? (v__2) : (1.270000e+02f);
    T_multiply[ax1] = (((float)(((int32_t)((v__3) > (-1.280000e+02f) ? (v__3) : (-1.280000e+02f))) + 128)) * 3.906250e-03f);
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_softmax_divide_round_add_clip_cast_subtract_cast_multiply_1(float* p0, float* T_multiply, uint8_t* global_const_workspace_92_var, uint8_t* global_workspace_93_var) {
  void* T_softmax_maxelem_let = (&(global_workspace_93_var[53520]));
  void* T_softmax_exp_let = (&(global_workspace_93_var[53480]));
  void* T_softmax_expsum_let = (&(global_workspace_93_var[53520]));
  ((float*)T_softmax_maxelem_let)[0] = -3.402823e+38f;
  for (int32_t k = 0; k < 10; ++k) {
    float v_ = ((float*)T_softmax_maxelem_let)[0];
    float v__1 = p0[k];
    ((float*)T_softmax_maxelem_let)[0] = ((v_) > (v__1) ? (v_) : (v__1));
  }
  for (int32_t i1 = 0; i1 < 10; ++i1) {
    ((float*)T_softmax_exp_let)[i1] = expf((p0[i1] - ((float*)T_softmax_maxelem_let)[0]));
  }
  ((float*)T_softmax_expsum_let)[0] = 0.000000e+00f;
  for (int32_t k_1 = 0; k_1 < 10; ++k_1) {
    ((float*)T_softmax_expsum_let)[0] = (((float*)T_softmax_expsum_let)[0] + ((float*)T_softmax_exp_let)[k_1]);
  }
  for (int32_t i1_1 = 0; i1_1 < 10; ++i1_1) {
    ((float*)T_softmax_exp_let)[i1_1] = (((float*)T_softmax_exp_let)[i1_1] / ((float*)T_softmax_expsum_let)[0]);
  }
  for (int32_t ax1 = 0; ax1 < 10; ++ax1) {
    float v__2 = roundf((((float*)T_softmax_exp_let)[ax1] * 2.560000e+02f)) + -1.280000e+02f;
    float v__3 = (v__2) < (1.270000e+02f) ? (v__2) : (1.270000e+02f);
    T_multiply[ax1] = (((float)(((int32_t)((v__3) > (-1.280000e+02f) ? (v__3) : (-1.280000e+02f))) + 128)) * 3.906250e-03f);
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_softmax_divide_round_add_clip_cast_subtract_cast_multiply_2(float* p0, float* T_multiply, uint8_t* global_const_workspace_224_var, uint8_t* global_workspace_225_var) {
  void* T_softmax_maxelem_let = (&(global_workspace_225_var[53248]));
  void* T_softmax_exp_let = (&(global_workspace_225_var[53208]));
  void* T_softmax_expsum_let = (&(global_workspace_225_var[53248]));
  ((float*)T_softmax_maxelem_let)[0] = -3.402823e+38f;
  for (int32_t k = 0; k < 10; ++k) {
    float v_ = ((float*)T_softmax_maxelem_let)[0];
    float v__1 = p0[k];
    ((float*)T_softmax_maxelem_let)[0] = ((v_) > (v__1) ? (v_) : (v__1));
  }
  for (int32_t i1 = 0; i1 < 10; ++i1) {
    ((float*)T_softmax_exp_let)[i1] = expf((p0[i1] - ((float*)T_softmax_maxelem_let)[0]));
  }
  ((float*)T_softmax_expsum_let)[0] = 0.000000e+00f;
  for (int32_t k_1 = 0; k_1 < 10; ++k_1) {
    ((float*)T_softmax_expsum_let)[0] = (((float*)T_softmax_expsum_let)[0] + ((float*)T_softmax_exp_let)[k_1]);
  }
  for (int32_t i1_1 = 0; i1_1 < 10; ++i1_1) {
    ((float*)T_softmax_exp_let)[i1_1] = (((float*)T_softmax_exp_let)[i1_1] / ((float*)T_softmax_expsum_let)[0]);
  }
  for (int32_t ax1 = 0; ax1 < 10; ++ax1) {
    float v__2 = roundf((((float*)T_softmax_exp_let)[ax1] * 2.560000e+02f)) + -1.280000e+02f;
    float v__3 = (v__2) < (1.270000e+02f) ? (v__2) : (1.270000e+02f);
    T_multiply[ax1] = (((float)(((int32_t)((v__3) > (-1.280000e+02f) ? (v__3) : (-1.280000e+02f))) + 128)) * 3.906250e-03f);
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_softmax_divide_round_add_clip_cast_subtract_cast_multiply_3(float* p0, float* T_multiply, uint8_t* global_const_workspace_244_var, uint8_t* global_workspace_245_var) {
  void* T_softmax_maxelem_let = (&(global_workspace_245_var[272]));
  void* T_softmax_exp_let = (&(global_workspace_245_var[232]));
  void* T_softmax_expsum_let = (&(global_workspace_245_var[272]));
  ((float*)T_softmax_maxelem_let)[0] = -3.402823e+38f;
  for (int32_t k = 0; k < 10; ++k) {
    float v_ = ((float*)T_softmax_maxelem_let)[0];
    float v__1 = p0[k];
    ((float*)T_softmax_maxelem_let)[0] = ((v_) > (v__1) ? (v_) : (v__1));
  }
  for (int32_t i1 = 0; i1 < 10; ++i1) {
    ((float*)T_softmax_exp_let)[i1] = expf((p0[i1] - ((float*)T_softmax_maxelem_let)[0]));
  }
  ((float*)T_softmax_expsum_let)[0] = 0.000000e+00f;
  for (int32_t k_1 = 0; k_1 < 10; ++k_1) {
    ((float*)T_softmax_expsum_let)[0] = (((float*)T_softmax_expsum_let)[0] + ((float*)T_softmax_exp_let)[k_1]);
  }
  for (int32_t i1_1 = 0; i1_1 < 10; ++i1_1) {
    ((float*)T_softmax_exp_let)[i1_1] = (((float*)T_softmax_exp_let)[i1_1] / ((float*)T_softmax_expsum_let)[0]);
  }
  for (int32_t ax1 = 0; ax1 < 10; ++ax1) {
    float v__2 = roundf((((float*)T_softmax_exp_let)[ax1] * 2.560000e+02f)) + -1.280000e+02f;
    float v__3 = (v__2) < (1.270000e+02f) ? (v__2) : (1.270000e+02f);
    T_multiply[ax1] = (((float)(((int32_t)((v__3) > (-1.280000e+02f) ? (v__3) : (-1.280000e+02f))) + 128)) * 3.906250e-03f);
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_subtract_fixed_point_multiply_add_clip_cast(int32_t* p0, int8_t* T_cast, uint8_t* global_const_workspace_12_var, uint8_t* global_workspace_13_var) {
  void* fused_constant_2_let = (&(global_const_workspace_12_var[784096]));
  for (int32_t ax3_inner = 0; ax3_inner < 16; ++ax3_inner) {
    int32_t v_ = ((int32_t)(((((3 != 0) ? (((int64_t)(p0[ax3_inner] - ((int32_t*)fused_constant_2_let)[0])) << ((int64_t)3)) : ((int64_t)(p0[ax3_inner] - ((int32_t*)fused_constant_2_let)[0]))) * (int64_t)1669148971) + ((int64_t)1 << ((int64_t)((0 + 31) - 1)))) >> ((int64_t)(0 + 31)))) - 128;
    int32_t v__1 = (v_) < (127) ? (v_) : (127);
    T_cast[ax3_inner] = ((int8_t)((v__1) > (-128) ? (v__1) : (-128)));
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_subtract_fixed_point_multiply_add_clip_cast_1(int32_t* p0, int8_t* T_cast, uint8_t* global_const_workspace_64_var, uint8_t* global_workspace_65_var) {
  void* fused_constant_19_let = (&(global_const_workspace_64_var[784112]));
  for (int32_t ax3_outer = 0; ax3_outer < 6; ++ax3_outer) {
    for (int32_t ax3_inner = 0; ax3_inner < 16; ++ax3_inner) {
      int32_t cse_var_1 = ((ax3_outer * 16) + ax3_inner);
      int32_t v_ = ((int32_t)(((((2 != 0) ? (((int64_t)(p0[cse_var_1] - ((int32_t*)fused_constant_19_let)[0])) << ((int64_t)2)) : ((int64_t)(p0[cse_var_1] - ((int32_t*)fused_constant_19_let)[0]))) * (int64_t)1075121010) + ((int64_t)1 << ((int64_t)((0 + 31) - 1)))) >> ((int64_t)(0 + 31)))) - 121;
      int32_t v__1 = (v_) < (127) ? (v_) : (127);
      T_cast[cse_var_1] = ((int8_t)((v__1) > (-128) ? (v__1) : (-128)));
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_subtract_fixed_point_multiply_add_clip_cast_2(int32_t* p0, int8_t* T_cast, uint8_t* global_const_workspace_102_var, uint8_t* global_workspace_103_var) {
  void* fused_constant_31_let = (&(global_const_workspace_102_var[784064]));
  for (int32_t ax3_outer = 0; ax3_outer < 12; ++ax3_outer) {
    for (int32_t ax3_inner = 0; ax3_inner < 16; ++ax3_inner) {
      int32_t cse_var_1 = ((ax3_outer * 16) + ax3_inner);
      int32_t v_ = ((int32_t)(((((3 != 0) ? (((int64_t)(p0[cse_var_1] - ((int32_t*)fused_constant_31_let)[0])) << ((int64_t)3)) : ((int64_t)(p0[cse_var_1] - ((int32_t*)fused_constant_31_let)[0]))) * (int64_t)1300295728) + ((int64_t)1 << ((int64_t)((0 + 31) - 1)))) >> ((int64_t)(0 + 31)))) - 114;
      int32_t v__1 = (v_) < (127) ? (v_) : (127);
      T_cast[cse_var_1] = ((int8_t)((v__1) > (-128) ? (v__1) : (-128)));
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_subtract_fixed_point_multiply_add_clip_cast_3(int32_t* p0, int8_t* T_cast, uint8_t* global_const_workspace_118_var, uint8_t* global_workspace_119_var) {
  void* fused_constant_36_let = (&(global_const_workspace_118_var[784048]));
  for (int32_t ax3_outer = 0; ax3_outer < 12; ++ax3_outer) {
    for (int32_t ax3_inner = 0; ax3_inner < 16; ++ax3_inner) {
      int32_t cse_var_1 = ((ax3_outer * 16) + ax3_inner);
      int32_t v_ = ((int32_t)(((((3 != 0) ? (((int64_t)(p0[cse_var_1] - ((int32_t*)fused_constant_36_let)[0])) << ((int64_t)3)) : ((int64_t)(p0[cse_var_1] - ((int32_t*)fused_constant_36_let)[0]))) * (int64_t)1109891016) + ((int64_t)1 << ((int64_t)((0 + 31) - 1)))) >> ((int64_t)(0 + 31)))) - 117;
      int32_t v__1 = (v_) < (127) ? (v_) : (127);
      T_cast[cse_var_1] = ((int8_t)((v__1) > (-128) ? (v__1) : (-128)));
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_subtract_fixed_point_multiply_add_clip_cast_4(int32_t* p0, int8_t* T_cast, uint8_t* global_const_workspace_136_var, uint8_t* global_workspace_137_var) {
  void* fused_constant_41_let = (&(global_const_workspace_136_var[784032]));
  for (int32_t ax3_outer = 0; ax3_outer < 6; ++ax3_outer) {
    for (int32_t ax3_inner = 0; ax3_inner < 16; ++ax3_inner) {
      int32_t cse_var_1 = ((ax3_outer * 16) + ax3_inner);
      int32_t v_ = ((int32_t)(((((2 != 0) ? (((int64_t)(p0[cse_var_1] - ((int32_t*)fused_constant_41_let)[0])) << ((int64_t)2)) : ((int64_t)(p0[cse_var_1] - ((int32_t*)fused_constant_41_let)[0]))) * (int64_t)1235411175) + ((int64_t)1 << ((int64_t)((0 + 31) - 1)))) >> ((int64_t)(0 + 31)))) - 120;
      int32_t v__1 = (v_) < (127) ? (v_) : (127);
      T_cast[cse_var_1] = ((int8_t)((v__1) > (-128) ? (v__1) : (-128)));
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_subtract_fixed_point_multiply_add_clip_cast_5(int32_t* p0, int8_t* T_cast, uint8_t* global_const_workspace_154_var, uint8_t* global_workspace_155_var) {
  void* fused_constant_47_let = (&(global_const_workspace_154_var[784016]));
  for (int32_t ax3_outer = 0; ax3_outer < 8; ++ax3_outer) {
    for (int32_t ax3_inner = 0; ax3_inner < 16; ++ax3_inner) {
      if (((ax3_outer * 2) + (ax3_inner >> 3)) < 15) {
        int32_t cse_var_1 = ((ax3_outer * 16) + ax3_inner);
        int32_t v_ = ((int32_t)(((((3 != 0) ? (((int64_t)(p0[cse_var_1] - ((int32_t*)fused_constant_47_let)[0])) << ((int64_t)3)) : ((int64_t)(p0[cse_var_1] - ((int32_t*)fused_constant_47_let)[0]))) * (int64_t)1801125321) + ((int64_t)1 << ((int64_t)((0 + 31) - 1)))) >> ((int64_t)(0 + 31)))) - 118;
        int32_t v__1 = (v_) < (127) ? (v_) : (127);
        T_cast[cse_var_1] = ((int8_t)((v__1) > (-128) ? (v__1) : (-128)));
      }
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_subtract_fixed_point_multiply_add_clip_cast_6(int32_t* p0, int8_t* T_cast, uint8_t* global_const_workspace_172_var, uint8_t* global_workspace_173_var) {
  void* fused_constant_52_let = (&(global_const_workspace_172_var[784000]));
  for (int32_t ax3_outer = 0; ax3_outer < 15; ++ax3_outer) {
    for (int32_t ax3_inner = 0; ax3_inner < 16; ++ax3_inner) {
      int32_t cse_var_1 = ((ax3_outer * 16) + ax3_inner);
      int32_t v_ = ((int32_t)(((((1 != 0) ? (((int64_t)(p0[cse_var_1] - ((int32_t*)fused_constant_52_let)[0])) << ((int64_t)1)) : ((int64_t)(p0[cse_var_1] - ((int32_t*)fused_constant_52_let)[0]))) * (int64_t)1688293339) + ((int64_t)1 << ((int64_t)((0 + 31) - 1)))) >> ((int64_t)(0 + 31)))) - 120;
      int32_t v__1 = (v_) < (127) ? (v_) : (127);
      T_cast[cse_var_1] = ((int8_t)((v__1) > (-128) ? (v__1) : (-128)));
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_subtract_fixed_point_multiply_add_clip_cast_7(int32_t* p0, int8_t* T_cast, uint8_t* global_const_workspace_190_var, uint8_t* global_workspace_191_var) {
  void* fused_constant_58_let = (&(global_const_workspace_190_var[783984]));
  for (int32_t ax3_outer = 0; ax3_outer < 27; ++ax3_outer) {
    for (int32_t ax3_inner = 0; ax3_inner < 16; ++ax3_inner) {
      int32_t cse_var_1 = ((ax3_outer * 16) + ax3_inner);
      int32_t v_ = ((int32_t)(((((1 != 0) ? (((int64_t)(p0[cse_var_1] - ((int32_t*)fused_constant_58_let)[0])) << ((int64_t)1)) : ((int64_t)(p0[cse_var_1] - ((int32_t*)fused_constant_58_let)[0]))) * (int64_t)2084386315) + ((int64_t)1 << ((int64_t)((0 + 31) - 1)))) >> ((int64_t)(0 + 31)))) - 121;
      int32_t v__1 = (v_) < (127) ? (v_) : (127);
      T_cast[cse_var_1] = ((int8_t)((v__1) > (-128) ? (v__1) : (-128)));
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_subtract_fixed_point_multiply_add_clip_cast_8(int32_t* p0, int8_t* T_cast, uint8_t* global_const_workspace_206_var, uint8_t* global_workspace_207_var) {
  void* fused_constant_63_let = (&(global_const_workspace_206_var[783968]));
  for (int32_t ax3_outer = 0; ax3_outer < 27; ++ax3_outer) {
    for (int32_t ax3_inner = 0; ax3_inner < 16; ++ax3_inner) {
      int32_t cse_var_1 = ((ax3_outer * 16) + ax3_inner);
      int32_t v_ = ((int32_t)(((((1 != 0) ? (((int64_t)(p0[cse_var_1] - ((int32_t*)fused_constant_63_let)[0])) << ((int64_t)1)) : ((int64_t)(p0[cse_var_1] - ((int32_t*)fused_constant_63_let)[0]))) * (int64_t)1888425996) + ((int64_t)1 << ((int64_t)((0 + 31) - 1)))) >> ((int64_t)(0 + 31)))) - 125;
      int32_t v__1 = (v_) < (127) ? (v_) : (127);
      T_cast[cse_var_1] = ((int8_t)((v__1) > (-128) ? (v__1) : (-128)));
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_subtract_fixed_point_multiply_add_clip_cast_reshape(int32_t* p0, int8_t* T_reshape, uint8_t* global_const_workspace_44_var, uint8_t* global_workspace_45_var) {
  void* fused_constant_13_let = (&(global_const_workspace_44_var[784128]));
  for (int32_t ax1_outer = 0; ax1_outer < 2; ++ax1_outer) {
    for (int32_t ax1_inner = 0; ax1_inner < 16; ++ax1_inner) {
      int32_t cse_var_1 = ((ax1_outer * 16) + ax1_inner);
      int32_t v_ = ((int32_t)(((((3 != 0) ? (((int64_t)(p0[cse_var_1] - ((int32_t*)fused_constant_13_let)[0])) << ((int64_t)3)) : ((int64_t)(p0[cse_var_1] - ((int32_t*)fused_constant_13_let)[0]))) * (int64_t)1514088781) + ((int64_t)1 << ((int64_t)((0 + 31) - 1)))) >> ((int64_t)(0 + 31)))) - 128;
      int32_t v__1 = (v_) < (127) ? (v_) : (127);
      T_reshape[cse_var_1] = ((int8_t)((v__1) > (-128) ? (v__1) : (-128)));
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_subtract_fixed_point_multiply_add_clip_cast_reshape_1(int32_t* p0, int8_t* T_reshape, uint8_t* global_const_workspace_84_var, uint8_t* global_workspace_85_var) {
  void* fused_constant_25_let = (&(global_const_workspace_84_var[784080]));
  for (int32_t ax1_inner = 0; ax1_inner < 16; ++ax1_inner) {
    int32_t v_ = ((int32_t)(((((2 != 0) ? (((int64_t)(p0[ax1_inner] - ((int32_t*)fused_constant_25_let)[0])) << ((int64_t)2)) : ((int64_t)(p0[ax1_inner] - ((int32_t*)fused_constant_25_let)[0]))) * (int64_t)1507587824) + ((int64_t)1 << ((int64_t)((0 + 31) - 1)))) >> ((int64_t)(0 + 31)))) - 128;
    int32_t v__1 = (v_) < (127) ? (v_) : (127);
    T_reshape[ax1_inner] = ((int8_t)((v__1) > (-128) ? (v__1) : (-128)));
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_subtract_fixed_point_multiply_add_clip_cast_reshape_2(int32_t* p0, int8_t* T_reshape, uint8_t* global_const_workspace_220_var, uint8_t* global_workspace_221_var) {
  void* fused_constant_67_let = (&(global_const_workspace_220_var[783952]));
  for (int32_t ax1_outer = 0; ax1_outer < 27; ++ax1_outer) {
    for (int32_t ax1_inner = 0; ax1_inner < 16; ++ax1_inner) {
      int32_t cse_var_1 = ((ax1_outer * 16) + ax1_inner);
      int32_t v_ = ((int32_t)(((((2 != 0) ? (((int64_t)(p0[cse_var_1] - ((int32_t*)fused_constant_67_let)[0])) << ((int64_t)2)) : ((int64_t)(p0[cse_var_1] - ((int32_t*)fused_constant_67_let)[0]))) * (int64_t)1280805107) + ((int64_t)1 << ((int64_t)((0 + 31) - 1)))) >> ((int64_t)(0 + 31)))) - 125;
      int32_t v__1 = (v_) < (127) ? (v_) : (127);
      T_reshape[cse_var_1] = ((int8_t)((v__1) > (-128) ? (v__1) : (-128)));
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_subtract_fixed_point_multiply_add_clip_cast_reshape_3(int32_t* p0, int8_t* T_reshape, uint8_t* global_const_workspace_236_var, uint8_t* global_workspace_237_var) {
  void* fused_constant_71_let = (&(global_const_workspace_236_var[783936]));
  for (int32_t ax1_inner = 0; ax1_inner < 16; ++ax1_inner) {
    int32_t v_ = ((int32_t)(((((2 != 0) ? (((int64_t)(p0[ax1_inner] - ((int32_t*)fused_constant_71_let)[0])) << ((int64_t)2)) : ((int64_t)(p0[ax1_inner] - ((int32_t*)fused_constant_71_let)[0]))) * (int64_t)1716705525) + ((int64_t)1 << ((int64_t)((0 + 31) - 1)))) >> ((int64_t)(0 + 31)))) - 128;
    int32_t v__1 = (v_) < (127) ? (v_) : (127);
    T_reshape[ax1_inner] = ((int8_t)((v__1) > (-128) ? (v__1) : (-128)));
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_subtract_multiply_fixed_point_multiply_add_clip_cast(int32_t* p0, int32_t* p1, int8_t* T_cast, uint8_t* global_const_workspace_18_var, uint8_t* global_workspace_19_var) {
  for (int32_t ax0_ax1_fused = 0; ax0_ax1_fused < 16; ++ax0_ax1_fused) {
    for (int32_t ax2 = 0; ax2 < 16; ++ax2) {
      for (int32_t ax3_inner = 0; ax3_inner < 16; ++ax3_inner) {
        int32_t cse_var_1 = (((ax0_ax1_fused * 256) + (ax2 * 16)) + ax3_inner);
        int32_t v_ = ((int32_t)(((((0 != 0) ? (((int64_t)((p0[cse_var_1] + 128) * p1[ax3_inner])) << ((int64_t)0)) : ((int64_t)((p0[cse_var_1] + 128) * p1[ax3_inner]))) * (int64_t)1077952621) + ((int64_t)1 << ((int64_t)((7 + 31) - 1)))) >> ((int64_t)(7 + 31)))) - 128;
        int32_t v__1 = (v_) < (127) ? (v_) : (127);
        T_cast[cse_var_1] = ((int8_t)((v__1) > (-128) ? (v__1) : (-128)));
      }
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_subtract_multiply_fixed_point_multiply_add_clip_cast_1(int32_t* p0, int32_t* p1, int8_t* T_cast, uint8_t* global_const_workspace_70_var, uint8_t* global_workspace_71_var) {
  for (int32_t ax0_ax1_fused = 0; ax0_ax1_fused < 4; ++ax0_ax1_fused) {
    for (int32_t ax2 = 0; ax2 < 4; ++ax2) {
      for (int32_t ax3_outer = 0; ax3_outer < 6; ++ax3_outer) {
        for (int32_t ax3_inner = 0; ax3_inner < 16; ++ax3_inner) {
          int32_t cse_var_2 = (ax3_outer * 16);
          int32_t cse_var_1 = ((((ax0_ax1_fused * 384) + (ax2 * 96)) + cse_var_2) + ax3_inner);
          int32_t v_ = ((int32_t)(((((0 != 0) ? (((int64_t)((p0[cse_var_1] + 125) * p1[(cse_var_2 + ax3_inner)])) << ((int64_t)0)) : ((int64_t)((p0[cse_var_1] + 125) * p1[(cse_var_2 + ax3_inner)]))) * (int64_t)1121647417) + ((int64_t)1 << ((int64_t)((6 + 31) - 1)))) >> ((int64_t)(6 + 31)))) - 121;
          int32_t v__1 = (v_) < (127) ? (v_) : (127);
          T_cast[cse_var_1] = ((int8_t)((v__1) > (-128) ? (v__1) : (-128)));
        }
      }
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_subtract_multiply_fixed_point_multiply_add_clip_cast_2(int32_t* p0, int32_t* p1, int8_t* T_cast, uint8_t* global_const_workspace_108_var, uint8_t* global_workspace_109_var) {
  for (int32_t ax0_ax1_fused = 0; ax0_ax1_fused < 4; ++ax0_ax1_fused) {
    for (int32_t ax2 = 0; ax2 < 4; ++ax2) {
      for (int32_t ax3_outer = 0; ax3_outer < 12; ++ax3_outer) {
        for (int32_t ax3_inner = 0; ax3_inner < 16; ++ax3_inner) {
          int32_t cse_var_2 = (ax3_outer * 16);
          int32_t cse_var_1 = ((((ax0_ax1_fused * 768) + (ax2 * 192)) + cse_var_2) + ax3_inner);
          int32_t v_ = ((int32_t)(((((0 != 0) ? (((int64_t)((p0[cse_var_1] + 125) * p1[(cse_var_2 + ax3_inner)])) << ((int64_t)0)) : ((int64_t)((p0[cse_var_1] + 125) * p1[(cse_var_2 + ax3_inner)]))) * (int64_t)1528818567) + ((int64_t)1 << ((int64_t)((5 + 31) - 1)))) >> ((int64_t)(5 + 31)))) - 112;
          int32_t v__1 = (v_) < (127) ? (v_) : (127);
          T_cast[cse_var_1] = ((int8_t)((v__1) > (-128) ? (v__1) : (-128)));
        }
      }
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_subtract_multiply_fixed_point_multiply_add_clip_cast_3(int32_t* p0, int32_t* p1, int8_t* T_cast, uint8_t* global_const_workspace_124_var, uint8_t* global_workspace_125_var) {
  for (int32_t ax0_ax1_fused = 0; ax0_ax1_fused < 4; ++ax0_ax1_fused) {
    for (int32_t ax2 = 0; ax2 < 4; ++ax2) {
      for (int32_t ax3_outer = 0; ax3_outer < 12; ++ax3_outer) {
        for (int32_t ax3_inner = 0; ax3_inner < 16; ++ax3_inner) {
          int32_t cse_var_2 = (ax3_outer * 16);
          int32_t cse_var_1 = ((((ax0_ax1_fused * 768) + (ax2 * 192)) + cse_var_2) + ax3_inner);
          int32_t v_ = ((int32_t)(((((0 != 0) ? (((int64_t)((p0[cse_var_1] + 125) * p1[(cse_var_2 + ax3_inner)])) << ((int64_t)0)) : ((int64_t)((p0[cse_var_1] + 125) * p1[(cse_var_2 + ax3_inner)]))) * (int64_t)2037754974) + ((int64_t)1 << ((int64_t)((5 + 31) - 1)))) >> ((int64_t)(5 + 31)))) - 107;
          int32_t v__1 = (v_) < (127) ? (v_) : (127);
          T_cast[cse_var_1] = ((int8_t)((v__1) > (-128) ? (v__1) : (-128)));
        }
      }
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_subtract_multiply_fixed_point_multiply_add_clip_cast_4(int32_t* p0, int32_t* p1, int8_t* T_cast, uint8_t* global_const_workspace_142_var, uint8_t* global_workspace_143_var) {
  for (int32_t ax0_ax1_fused = 0; ax0_ax1_fused < 4; ++ax0_ax1_fused) {
    for (int32_t ax2 = 0; ax2 < 4; ++ax2) {
      for (int32_t ax3_outer = 0; ax3_outer < 6; ++ax3_outer) {
        for (int32_t ax3_inner = 0; ax3_inner < 16; ++ax3_inner) {
          int32_t cse_var_2 = (ax3_outer * 16);
          int32_t cse_var_1 = ((((ax0_ax1_fused * 384) + (ax2 * 96)) + cse_var_2) + ax3_inner);
          int32_t v_ = ((int32_t)(((((0 != 0) ? (((int64_t)((p0[cse_var_1] + 124) * p1[(cse_var_2 + ax3_inner)])) << ((int64_t)0)) : ((int64_t)((p0[cse_var_1] + 124) * p1[(cse_var_2 + ax3_inner)]))) * (int64_t)1195609191) + ((int64_t)1 << ((int64_t)((6 + 31) - 1)))) >> ((int64_t)(6 + 31)))) - 120;
          int32_t v__1 = (v_) < (127) ? (v_) : (127);
          T_cast[cse_var_1] = ((int8_t)((v__1) > (-128) ? (v__1) : (-128)));
        }
      }
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_subtract_multiply_fixed_point_multiply_add_clip_cast_5(int32_t* p0, int32_t* p1, int8_t* T_cast, uint8_t* global_const_workspace_160_var, uint8_t* global_workspace_161_var) {
  for (int32_t ax0_ax1_fused = 0; ax0_ax1_fused < 4; ++ax0_ax1_fused) {
    for (int32_t ax2 = 0; ax2 < 4; ++ax2) {
      for (int32_t ax3_outer = 0; ax3_outer < 8; ++ax3_outer) {
        for (int32_t ax3_inner = 0; ax3_inner < 16; ++ax3_inner) {
          if (((ax3_outer * 2) + (ax3_inner >> 3)) < 15) {
            int32_t cse_var_2 = (ax3_outer * 16);
            int32_t cse_var_1 = ((((ax0_ax1_fused * 480) + (ax2 * 120)) + cse_var_2) + ax3_inner);
            int32_t v_ = ((int32_t)(((((0 != 0) ? (((int64_t)((p0[cse_var_1] + 126) * p1[(cse_var_2 + ax3_inner)])) << ((int64_t)0)) : ((int64_t)((p0[cse_var_1] + 126) * p1[(cse_var_2 + ax3_inner)]))) * (int64_t)1201673225) + ((int64_t)1 << ((int64_t)((4 + 31) - 1)))) >> ((int64_t)(4 + 31)))) - 114;
            int32_t v__1 = (v_) < (127) ? (v_) : (127);
            T_cast[cse_var_1] = ((int8_t)((v__1) > (-128) ? (v__1) : (-128)));
          }
        }
      }
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_subtract_multiply_fixed_point_multiply_add_clip_cast_6(int32_t* p0, int32_t* p1, int8_t* T_cast, uint8_t* global_const_workspace_178_var, uint8_t* global_workspace_179_var) {
  for (int32_t ax0_ax1_fused = 0; ax0_ax1_fused < 2; ++ax0_ax1_fused) {
    for (int32_t ax2 = 0; ax2 < 2; ++ax2) {
      for (int32_t ax3_outer = 0; ax3_outer < 15; ++ax3_outer) {
        for (int32_t ax3_inner = 0; ax3_inner < 16; ++ax3_inner) {
          int32_t cse_var_2 = (ax3_outer * 16);
          int32_t cse_var_1 = ((((ax0_ax1_fused * 480) + (ax2 * 240)) + cse_var_2) + ax3_inner);
          int32_t v_ = ((int32_t)(((((0 != 0) ? (((int64_t)((p0[cse_var_1] + 123) * p1[(cse_var_2 + ax3_inner)])) << ((int64_t)0)) : ((int64_t)((p0[cse_var_1] + 123) * p1[(cse_var_2 + ax3_inner)]))) * (int64_t)2059315547) + ((int64_t)1 << ((int64_t)((7 + 31) - 1)))) >> ((int64_t)(7 + 31)))) - 118;
          int32_t v__1 = (v_) < (127) ? (v_) : (127);
          T_cast[cse_var_1] = ((int8_t)((v__1) > (-128) ? (v__1) : (-128)));
        }
      }
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_subtract_multiply_fixed_point_multiply_add_clip_cast_7(int32_t* p0, int32_t* p1, int8_t* T_cast, uint8_t* global_const_workspace_196_var, uint8_t* global_workspace_197_var) {
  for (int32_t ax0_ax1_fused = 0; ax0_ax1_fused < 2; ++ax0_ax1_fused) {
    for (int32_t ax2 = 0; ax2 < 2; ++ax2) {
      for (int32_t ax3_outer = 0; ax3_outer < 27; ++ax3_outer) {
        for (int32_t ax3_inner = 0; ax3_inner < 16; ++ax3_inner) {
          int32_t cse_var_2 = (ax3_outer * 16);
          int32_t cse_var_1 = ((((ax0_ax1_fused * 864) + (ax2 * 432)) + cse_var_2) + ax3_inner);
          int32_t v_ = ((int32_t)(((((0 != 0) ? (((int64_t)((p0[cse_var_1] + 125) * p1[(cse_var_2 + ax3_inner)])) << ((int64_t)0)) : ((int64_t)((p0[cse_var_1] + 125) * p1[(cse_var_2 + ax3_inner)]))) * (int64_t)1523045038) + ((int64_t)1 << ((int64_t)((7 + 31) - 1)))) >> ((int64_t)(7 + 31)))) - 123;
          int32_t v__1 = (v_) < (127) ? (v_) : (127);
          T_cast[cse_var_1] = ((int8_t)((v__1) > (-128) ? (v__1) : (-128)));
        }
      }
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_subtract_multiply_fixed_point_multiply_add_clip_cast_8(int32_t* p0, int32_t* p1, int8_t* T_cast, uint8_t* global_const_workspace_212_var, uint8_t* global_workspace_213_var) {
  for (int32_t ax0_ax1_fused = 0; ax0_ax1_fused < 2; ++ax0_ax1_fused) {
    for (int32_t ax2 = 0; ax2 < 2; ++ax2) {
      for (int32_t ax3_outer = 0; ax3_outer < 27; ++ax3_outer) {
        for (int32_t ax3_inner = 0; ax3_inner < 16; ++ax3_inner) {
          int32_t cse_var_2 = (ax3_outer * 16);
          int32_t cse_var_1 = ((((ax0_ax1_fused * 864) + (ax2 * 432)) + cse_var_2) + ax3_inner);
          int32_t v_ = ((int32_t)(((((0 != 0) ? (((int64_t)((p0[cse_var_1] + 126) * p1[(cse_var_2 + ax3_inner)])) << ((int64_t)0)) : ((int64_t)((p0[cse_var_1] + 126) * p1[(cse_var_2 + ax3_inner)]))) * (int64_t)1125964115) + ((int64_t)1 << ((int64_t)((7 + 31) - 1)))) >> ((int64_t)(7 + 31)))) - 126;
          int32_t v__1 = (v_) < (127) ? (v_) : (127);
          T_cast[cse_var_1] = ((int8_t)((v__1) > (-128) ? (v__1) : (-128)));
        }
      }
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default___tvm_main__(float* serving_default_input_0_buffer_var, float* StatefulPartitionedCall_1_buffer_var, float* StatefulPartitionedCall_2_buffer_var, float* StatefulPartitionedCall_0_buffer_var, float* StatefulPartitionedCall_3_buffer_var, uint8_t* global_const_workspace_0_var, uint8_t* global_workspace_1_var) {
  void* sid_86_let = (&(global_workspace_1_var[3840]));
  void* sid_80_let = (&(global_workspace_1_var[52736]));
  void* sid_74_let = (&(global_workspace_1_var[30720]));
  void* sid_93_let = (&(global_workspace_1_var[15552]));
  void* sid_73_let = (&(global_workspace_1_var[32640]));
  void* sid_14_let = (&(global_workspace_1_var[31328]));
  void* sid_91_let = (&(global_workspace_1_var[53888]));
  void* sid_62_let = (&(global_workspace_1_var[15360]));
  void* sid_75_let = (&(global_workspace_1_var[23040]));
  void* sid_60_let = (&(global_workspace_1_var[52928]));
  void* sid_68_let = (&(global_workspace_1_var[52736]));
  void* sid_59_let = (&(global_workspace_1_var[13056]));
  void* sid_58_let = (&(global_workspace_1_var[0]));
  void* sid_63_let = (&(global_workspace_1_var[12288]));
  void* sid_66_let = (&(global_workspace_1_var[18432]));
  void* sid_57_let = (&(global_workspace_1_var[36864]));
  void* sid_72_let = (&(global_workspace_1_var[6144]));
  void* sid_56_let = (&(global_workspace_1_var[49152]));
  void* sid_64_let = (&(global_workspace_1_var[52736]));
  void* sid_55_let = (&(global_workspace_1_var[52224]));
  void* sid_52_let = (&(global_workspace_1_var[53440]));
  void* sid_70_let = (&(global_workspace_1_var[52832]));
  void* sid_69_let = (&(global_workspace_1_var[53120]));
  void* sid_48_let = (&(global_workspace_1_var[36864]));
  void* sid_107_let = (&(global_workspace_1_var[6912]));
  void* sid_97_let = (&(global_workspace_1_var[54176]));
  void* sid_65_let = (&(global_workspace_1_var[24576]));
  void* sid_85_let = (&(global_workspace_1_var[0]));
  void* sid_3_let = (&(global_workspace_1_var[0]));
  void* sid_35_let = (&(global_workspace_1_var[6144]));
  void* sid_92_let = (&(global_workspace_1_var[31104]));
  void* sid_90_let = (&(global_workspace_1_var[4800]));
  void* sid_19_let = (&(global_workspace_1_var[10592]));
  void* sid_50_let = (&(global_workspace_1_var[13056]));
  void* sid_96_let = (&(global_workspace_1_var[53168]));
  void* sid_5_let = (&(global_workspace_1_var[16384]));
  void* sid_76_let = (&(global_workspace_1_var[0]));
  void* sid_83_let = (&(global_workspace_1_var[23520]));
  void* sid_77_let = (&(global_workspace_1_var[52736]));
  void* sid_95_let = (&(global_workspace_1_var[8640]));
  void* sid_47_let = (&(global_workspace_1_var[49152]));
  void* sid_4_let = (&(global_workspace_1_var[0]));
  void* sid_18_let = (&(global_workspace_1_var[32864]));
  void* sid_88_let = (&(global_workspace_1_var[52992]));
  void* sid_32_let = (&(global_workspace_1_var[6528]));
  void* sid_25_let = (&(global_workspace_1_var[34592]));
  void* sid_89_let = (&(global_workspace_1_var[3840]));
  void* sid_22_let = (&(global_workspace_1_var[34656]));
  void* sid_6_let = (&(global_workspace_1_var[16448]));
  void* sid_87_let = (&(global_workspace_1_var[52736]));
  void* sid_7_let = (&(global_workspace_1_var[16400]));
  void* sid_16_let = (&(global_workspace_1_var[0]));
  void* sid_84_let = (&(global_workspace_1_var[11760]));
  void* sid_61_let = (&(global_workspace_1_var[52928]));
  void* sid_12_let = (&(global_workspace_1_var[0]));
  void* sid_79_let = (&(global_workspace_1_var[52856]));
  void* sid_17_let = (&(global_workspace_1_var[22528]));
  void* sid_99_let = (&(global_workspace_1_var[8640]));
  void* sid_1_let = (&(global_workspace_1_var[46488]));
  void* sid_2_let = (&(global_workspace_1_var[17424]));
  void* sid_8_let = (&(global_workspace_1_var[20480]));
  void* sid_51_let = (&(global_workspace_1_var[53440]));
  void* sid_15_let = (&(global_workspace_1_var[8800]));
  void* sid_9_let = (&(global_workspace_1_var[16384]));
  void* sid_71_let = (&(global_workspace_1_var[52736]));
  void* sid_34_let = (&(global_workspace_1_var[7680]));
  void* sid_11_let = (&(global_workspace_1_var[20808]));
  void* sid_23_let = (&(global_workspace_1_var[34400]));
  void* sid_54_let = (&(global_workspace_1_var[12288]));
  void* sid_37_let = (&(global_workspace_1_var[1152]));
  void* sid_10_let = (&(global_workspace_1_var[0]));
  void* sid_94_let = (&(global_workspace_1_var[0]));
  void* sid_21_let = (&(global_workspace_1_var[34400]));
  void* sid_39_let = (&(global_workspace_1_var[1152]));
  void* sid_82_let = (&(global_workspace_1_var[33280]));
  void* sid_27_let = (&(global_workspace_1_var[34400]));
  void* sid_30_let = (&(global_workspace_1_var[0]));
  void* sid_28_let = (&(global_workspace_1_var[23232]));
  void* sid_31_let = (&(global_workspace_1_var[6144]));
  void* sid_33_let = (&(global_workspace_1_var[6240]));
  void* sid_36_let = (&(global_workspace_1_var[52736]));
  void* sid_20_let = (&(global_workspace_1_var[0]));
  void* sid_38_let = (&(global_workspace_1_var[53248]));
  void* sid_78_let = (&(global_workspace_1_var[53216]));
  void* sid_29_let = (&(global_workspace_1_var[11616]));
  void* sid_40_let = (&(global_workspace_1_var[1152]));
  void* sid_67_let = (&(global_workspace_1_var[0]));
  void* sid_24_let = (&(global_workspace_1_var[34528]));
  void* sid_41_let = (&(global_workspace_1_var[53248]));
  void* sid_42_let = (&(global_workspace_1_var[53536]));
  void* sid_49_let = (&(global_workspace_1_var[0]));
  void* sid_43_let = (&(global_workspace_1_var[53248]));
  void* sid_81_let = (&(global_workspace_1_var[7680]));
  void* sid_13_let = (&(global_workspace_1_var[60048]));
  void* sid_53_let = (&(global_workspace_1_var[15360]));
  void* sid_44_let = (&(global_workspace_1_var[53376]));
  void* sid_45_let = (&(global_workspace_1_var[53440]));
  void* sid_106_let = (&(global_workspace_1_var[53888]));
  void* sid_98_let = (&(global_workspace_1_var[6912]));
  void* sid_100_let = (&(global_workspace_1_var[53600]));
  void* sid_121_let = (&(global_workspace_1_var[0]));
  void* sid_101_let = (&(global_workspace_1_var[31104]));
  void* sid_102_let = (&(global_workspace_1_var[15552]));
  void* sid_103_let = (&(global_workspace_1_var[0]));
  void* sid_104_let = (&(global_workspace_1_var[8640]));
  void* sid_105_let = (&(global_workspace_1_var[53168]));
  void* sid_108_let = (&(global_workspace_1_var[8640]));
  void* sid_109_let = (&(global_workspace_1_var[53888]));
  void* sid_110_let = (&(global_workspace_1_var[0]));
  void* sid_123_let = (&(global_workspace_1_var[192]));
  void* sid_111_let = (&(global_workspace_1_var[0]));
  void* sid_112_let = (&(global_workspace_1_var[52736]));
  void* sid_113_let = (&(global_workspace_1_var[53168]));
  void* sid_115_let = (&(global_workspace_1_var[1152]));
  void* sid_116_let = (&(global_workspace_1_var[2304]));
  void* sid_117_let = (&(global_workspace_1_var[1152]));
  void* sid_118_let = (&(global_workspace_1_var[1152]));
  void* sid_119_let = (&(global_workspace_1_var[0]));
  void* sid_120_let = (&(global_workspace_1_var[288]));
  void* sid_122_let = (&(global_workspace_1_var[128]));
  if (tvmgen_default_fused_divide_round_add_clip_cast_nn_pad(serving_default_input_0_buffer_var, sid_1_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_subtract_cas_c93f40e30d1c190e_(sid_1_let, sid_2_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_nn_pad(sid_2_let, sid_3_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip(sid_3_let, sid_4_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_mean(sid_4_let, sid_5_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_subtract_fixed_point_multiply_add_clip_cast(sid_5_let, sid_6_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_cast(sid_6_let, sid_7_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_subtract_mul_add8c47b972ae6c2_(sid_7_let, sid_8_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_subtract_multiply_fixed_point_multiply_add_clip_cast(sid_4_let, sid_8_let, sid_9_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_cast_1(sid_9_let, sid_10_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_cast_2(sid_10_let, sid_11_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_nn_pad_1(sid_11_let, sid_12_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_cast_3(sid_12_let, sid_13_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_cast_4(sid_13_let, sid_14_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_cast_5(sid_14_let, sid_15_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_nn_pad_2(sid_15_let, sid_16_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_cast_6(sid_16_let, sid_17_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_cast_7(sid_17_let, sid_18_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_nn_pad_3(sid_18_let, sid_19_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_1(sid_19_let, sid_20_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_mean_1(sid_20_let, sid_21_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_subtract_fixed_point_multiply_add_clip_cast_reshape(sid_21_let, sid_22_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_nn_contrib_dense_pack_subtract_add_fixed_point_multiply_add_clip_cast(sid_22_let, sid_23_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_nn_contrib_dense_pack_subtract_add_fixed_point_multiply_add_clip_cast_1(sid_23_let, sid_24_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_nn_contrib_dense_pack_subtract_add_fixed_point_multiply_add_clip_subtract__fa059688879ad8de_(sid_24_let, sid_25_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_nn_softmax_divide_round_add_clip_cast_subtract_cast_multiply(sid_25_let, StatefulPartitionedCall_1_buffer_var, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_cast_subtract_fixed_point_multiply_add_cast_subtract_fixed_point_multiply__ed64f25d07613c12_(sid_14_let, sid_18_let, sid_27_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_subtract_cas_c93f40e30d1c190e__1(sid_27_let, sid_28_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_nn_pad_4(sid_28_let, sid_29_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_subtract_cas_c93f40e30d1c190e__2(sid_29_let, sid_30_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_mean_2(sid_30_let, sid_31_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_subtract_fixed_point_multiply_add_clip_cast_1(sid_31_let, sid_32_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_cast_8(sid_32_let, sid_33_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_subtract_mul_add8c47b972ae6c2__1(sid_33_let, sid_34_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_subtract_multiply_fixed_point_multiply_add_clip_cast_1(sid_30_let, sid_34_let, sid_35_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_cast_9(sid_35_let, sid_36_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_nn_pad_5(sid_36_let, sid_37_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_cast_10(sid_37_let, sid_38_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_nn_pad_6(sid_38_let, sid_39_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_2(sid_39_let, sid_40_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_mean_3(sid_40_let, sid_41_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_subtract_fixed_point_multiply_add_clip_cast_reshape_1(sid_41_let, sid_42_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_nn_contrib_dense_pack_subtract_add_fixed_point_multiply_add_clip_cast_2(sid_42_let, sid_43_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_nn_contrib_dense_pack_subtract_add_fixed_point_multiply_add_clip_cast_3(sid_43_let, sid_44_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_nn_contrib_dense_pack_subtract_add_fixed_point_multiply_add_clip_subtract__fa059688879ad8de__1(sid_44_let, sid_45_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_nn_softmax_divide_round_add_clip_cast_subtract_cast_multiply_1(sid_45_let, StatefulPartitionedCall_2_buffer_var, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_subtract_cas_c93f40e30d1c190e__3(sid_36_let, sid_47_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_nn_pad_7(sid_47_let, sid_48_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_subtract_cas_c93f40e30d1c190e__4(sid_48_let, sid_49_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_mean_4(sid_49_let, sid_50_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_subtract_fixed_point_multiply_add_clip_cast_2(sid_50_let, sid_51_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_cast_11(sid_51_let, sid_52_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_subtract_mul_add8c47b972ae6c2__2(sid_52_let, sid_53_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_subtract_multiply_fixed_point_multiply_add_clip_cast_2(sid_49_let, sid_53_let, sid_54_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_cast_subtract_fixed_point_multiply_nn_conv2d_subtract_add_fixed_point_mult_6a0898f32fb5072b_(sid_36_let, sid_54_let, sid_55_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_nn_conv2d_add_fixed_point_multiply_per_axis_add_clip_subtract_cast_multipl_a0b6f984222e477_(sid_55_let, sid_56_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_nn_pad_8(sid_56_let, sid_57_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_clip_cast_multiply_ad_b57e37aeb09540e8_(sid_57_let, sid_58_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_mean_4(sid_58_let, sid_59_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_subtract_fixed_point_multiply_add_clip_cast_3(sid_59_let, sid_60_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_cast_12(sid_60_let, sid_61_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_subtract_mul_add8c47b972ae6c2__3(sid_61_let, sid_62_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_subtract_multiply_fixed_point_multiply_add_clip_cast_3(sid_58_let, sid_62_let, sid_63_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_cast_fixed_point_multiply_add_nn_conv2d_subtract_add_fixed_point_multiply__ad3cbdcd07b87e28_(sid_55_let, sid_63_let, sid_64_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_subtract_cas_c93f40e30d1c190e__5(sid_64_let, sid_65_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_nn_pad_9(sid_65_let, sid_66_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_subtract_cas_c93f40e30d1c190e__6(sid_66_let, sid_67_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_mean_5(sid_67_let, sid_68_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_subtract_fixed_point_multiply_add_clip_cast_4(sid_68_let, sid_69_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_clip_cast_clip(sid_69_let, sid_70_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_nn_conv2d_add_fixed_point_multiply_per_axis_add_clip_subtract_multiply_fix_52d6a4719dd81c1d_(sid_70_let, sid_71_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_subtract_multiply_fixed_point_multiply_add_clip_cast_4(sid_67_let, sid_71_let, sid_72_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_cast_13(sid_72_let, sid_73_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_subtract_cas_c93f40e30d1c190e__7(sid_73_let, sid_74_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_nn_pad_10(sid_74_let, sid_75_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_subtract_cas_c93f40e30d1c190e__8(sid_75_let, sid_76_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_mean_6(sid_76_let, sid_77_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_subtract_fixed_point_multiply_add_clip_cast_5(sid_77_let, sid_78_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_cast_14(sid_78_let, sid_79_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_subtract_mul_add8c47b972ae6c2__4(sid_79_let, sid_80_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_subtract_multiply_fixed_point_multiply_add_clip_cast_5(sid_76_let, sid_80_let, sid_81_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_cast_subtract_fixed_point_multiply_add_nn_conv2d_subtract_add_fixed_point__7462b0c1d1f4a4f5_(sid_73_let, sid_81_let, sid_82_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_subtract_cas_c93f40e30d1c190e__9(sid_82_let, sid_83_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_nn_pad_11(sid_83_let, sid_84_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_subtract_cas_c93f40e30d1c190e__10(sid_84_let, sid_85_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_mean_7(sid_85_let, sid_86_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_subtract_fixed_point_multiply_add_clip_cast_6(sid_86_let, sid_87_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_cast_15(sid_87_let, sid_88_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_subtract_mul_add8c47b972ae6c2__5(sid_88_let, sid_89_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_subtract_multiply_fixed_point_multiply_add_clip_cast_6(sid_85_let, sid_89_let, sid_90_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_cast_16(sid_90_let, sid_91_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_subtract_cas_c93f40e30d1c190e__11(sid_91_let, sid_92_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_nn_pad_12(sid_92_let, sid_93_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_subtract_cas_c93f40e30d1c190e__12(sid_93_let, sid_94_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_mean_8(sid_94_let, sid_95_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_subtract_fixed_point_multiply_add_clip_cast_7(sid_95_let, sid_96_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_cast_17(sid_96_let, sid_97_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_subtract_mul_add8c47b972ae6c2__6(sid_97_let, sid_98_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_subtract_multiply_fixed_point_multiply_add_clip_cast_7(sid_94_let, sid_98_let, sid_99_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_cast_subtract_fixed_point_multiply_add_nn_conv2d_subtract_add_fixed_point__7462b0c1d1f4a4f5__1(sid_91_let, sid_99_let, sid_100_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_subtract_cas_c93f40e30d1c190e__13(sid_100_let, sid_101_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_nn_pad_13(sid_101_let, sid_102_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_subtract_cas_c93f40e30d1c190e__14(sid_102_let, sid_103_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_mean_8(sid_103_let, sid_104_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_subtract_fixed_point_multiply_add_clip_cast_8(sid_104_let, sid_105_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_cast_18(sid_105_let, sid_106_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_subtract_mul_add8c47b972ae6c2__7(sid_106_let, sid_107_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_subtract_multiply_fixed_point_multiply_add_clip_cast_8(sid_103_let, sid_107_let, sid_108_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_cast_subtract_fixed_point_multiply_add_nn_conv2d_subtract_add_fixed_point__7462b0c1d1f4a4f5__2(sid_100_let, sid_108_let, sid_109_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_subtract_cas_c93f40e30d1c190e__15(sid_109_let, sid_110_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_mean_9(sid_110_let, sid_111_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_subtract_fixed_point_multiply_add_clip_cast_reshape_2(sid_111_let, sid_112_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_nn_contrib_dense_pack_subtract_add_fixed_point_multiply_add_clip_subtract__fa059688879ad8de__2(sid_112_let, sid_113_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_nn_softmax_divide_round_add_clip_cast_subtract_cast_multiply_2(sid_113_let, StatefulPartitionedCall_0_buffer_var, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_nn_pad_14(sid_55_let, sid_115_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_nn_conv2d_add_fixed_point_multiply_per_axis_add_clip_cast(sid_115_let, sid_116_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_nn_pad_15(sid_116_let, sid_117_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_per_axis_add_clip_3(sid_117_let, sid_118_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_mean_10(sid_118_let, sid_119_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_subtract_fixed_point_multiply_add_clip_cast_reshape_3(sid_119_let, sid_120_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_nn_contrib_dense_pack_subtract_add_fixed_point_multiply_add_clip_cast_4(sid_120_let, sid_121_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_nn_contrib_dense_pack_subtract_add_fixed_point_multiply_add_clip_cast_5(sid_121_let, sid_122_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_nn_contrib_dense_pack_subtract_add_fixed_point_multiply_add_clip_subtract__fa059688879ad8de__3(sid_122_let, sid_123_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_nn_softmax_divide_round_add_clip_cast_subtract_cast_multiply_3(sid_123_let, StatefulPartitionedCall_3_buffer_var, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  return 0;
}

